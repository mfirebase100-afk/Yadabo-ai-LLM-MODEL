#!/usr/bin/env python3
"""
Yadabo AI - Data Upload Script
Upload training data to Supabase

Usage:
    python supabase/upload_data.py --file data/train.txt --source my_data
"""

import os
import sys
import argparse
import logging
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from supabase import get_supabase_client, DataStorage

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Upload training data to Supabase"
    )

    parser.add_argument(
        "--file",
        type=str,
        help="Path to text file"
    )

    parser.add_argument(
        "--directory",
        type=str,
        help="Path to directory containing text files"
    )

    parser.add_argument(
        "--jsonl",
        type=str,
        help="Path to JSONL file"
    )

    parser.add_argument(
        "--source",
        type=str,
        default="manual_upload",
        help="Source identifier"
    )

    parser.add_argument(
        "--format",
        type=str,
        choices=["txt", "jsonl", "auto"],
        default="auto",
        help="File format"
    )

    return parser.parse_args()


def upload_file(file_path: str, source: str):
    """Upload a single file."""
    storage = DataStorage(get_supabase_client())

    if not storage.client.is_connected():
        logger.error("Not connected to Supabase. Check credentials.")
        return False

    if file_path.endswith('.jsonl'):
        result = storage.upload_jsonl(file_path, source_name=source)
    else:
        result = storage.upload_text_file(file_path, source_name=source)

    if "error" in result:
        logger.error(f"Upload failed: {result['error']}")
        return False

    logger.info(f"Upload successful!")
    logger.info(f"  File: {file_path}")
    logger.info(f"  Lines: {result.get('lines_uploaded', 'N/A')}")
    logger.info(f"  Source: {source}")

    return True


def upload_directory(directory_path: str, source: str):
    """Upload all files in a directory."""
    storage = DataStorage(get_supabase_client())

    if not storage.client.is_connected():
        logger.error("Not connected to Supabase. Check credentials.")
        return False

    results = storage.upload_directory(
        directory_path,
        file_pattern="*.txt",
        source_name=source
    )

    if "error" in results:
        logger.error(f"Upload failed: {results['error']}")
        return False

    logger.info(f"Directory upload complete!")
    logger.info(f"  Files processed: {results['files_processed']}")
    logger.info(f"  Files failed: {results['files_failed']}")
    logger.info(f"  Total lines: {results['total_lines']}")

    if results['errors']:
        logger.warning("Some files had errors:")
        for err in results['errors'][:5]:  # Show first 5 errors
            logger.warning(f"  {err['file']}: {err['error']}")

    return True


def main():
    """Main upload function."""
    args = parse_args()

    print("="*60)
    print("Yadabo AI - Data Upload to Supabase")
    print("="*60)

    # Initialize Supabase client
    client = get_supabase_client()

    if not client.is_connected():
        print("\n❌ Error: Not connected to Supabase")
        print("\nPlease set these environment variables:")
        print("  export SUPABASE_URL=your_project_url")
        print("  export SUPABASE_KEY=your_api_key")
        print("\nOr create a .env file in the project root.")
        return

    print(f"\n✅ Connected to Supabase")
    print(f"   URL: {client.url[:50]}...")

    # Get stats
    stats = client.get_dataset_stats()
    if "total_samples" in stats:
        print(f"\n📊 Current database stats:")
        print(f"   Total samples: {stats['total_samples']:,}")
        if "estimated_size_gb" in stats:
            print(f"   Estimated size: {stats['estimated_size_gb']:.2f} GB")

    # Upload files
    if args.file:
        print(f"\n📤 Uploading file: {args.file}")
        upload_file(args.file, args.source)

    elif args.directory:
        print(f"\n📤 Uploading directory: {args.directory}")
        upload_directory(args.directory, args.source)

    elif args.jsonl:
        print(f"\n📤 Uploading JSONL: {args.jsonl}")
        storage = DataStorage(client)
        result = storage.upload_jsonl(args.jsonl, source_name=args.source)
        if "error" in result:
            print(f"❌ Error: {result['error']}")
        else:
            print(f"✅ Uploaded {result['lines_uploaded']} lines")

    else:
        print("\n❌ Error: No file or directory specified")
        print("Use --file, --directory, or --jsonl")

    # Final stats
    print("\n" + "="*60)
    stats = client.get_dataset_stats()
    if "total_samples" in stats:
        print(f"📊 Final database stats:")
        print(f"   Total samples: {stats['total_samples']:,}")
    print("="*60)


if __name__ == "__main__":
    main()
