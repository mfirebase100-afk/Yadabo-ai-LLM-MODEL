#!/usr/bin/env python3
"""
Yadabo AI - Load Data from Supabase for Training
Load training data from Supabase and prepare for model training

Usage:
    python supabase/load_data.py --output data/train_supabase.txt
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Iterator, List

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from supabase import get_supabase_client, DataStorage

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Load training data from Supabase"
    )

    parser.add_argument(
        "--output",
        type=str,
        default="data/train_supabase.txt",
        help="Output file path"
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=100000,
        help="Maximum number of samples to load"
    )

    parser.add_argument(
        "--min-length",
        type=int,
        default=50,
        help="Minimum text length"
    )

    parser.add_argument(
        "--max-length",
        type=int,
        default=10000,
        help="Maximum text length"
    )

    parser.add_argument(
        "--source",
        type=str,
        help="Filter by source"
    )

    parser.add_argument(
        "--language",
        type=str,
        help="Filter by language (arabic, english)"
    )

    return parser.parse_args()


def load_data_streaming(
    client,
    min_length: int = 50,
    max_length: int = 10000,
    language: str = None
) -> Iterator[str]:
    """
    Generator that yields training texts one by one.

    Memory efficient for large datasets.
    """
    batch_size = 1000
    offset = 0

    while True:
        batch = client.get_training_data(
            limit=batch_size,
            offset=offset,
            min_length=min_length,
            max_length=max_length,
            source=language
        )

        if not batch:
            break

        for record in batch:
            yield record['text']

        offset += batch_size

        if offset % 10000 == 0:
            logger.info(f"Loaded {offset} samples...")


def main():
    """Main loading function."""
    args = parse_args()

    print("="*60)
    print("Yadabo AI - Load Training Data from Supabase")
    print("="*60)

    # Initialize Supabase client
    client = get_supabase_client()

    if not client.is_connected():
        print("\n❌ Error: Not connected to Supabase")
        print("\nPlease set environment variables:")
        print("  export SUPABASE_URL=your_project_url")
        print("  export SUPABASE_KEY=your_api_key")
        return

    print(f"\n✅ Connected to Supabase")

    # Get database stats
    stats = client.get_dataset_stats()
    if "total_samples" in stats:
        print(f"\n📊 Database contains: {stats['total_samples']:,} samples")

    # Create output directory
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Load and save data
    print(f"\n📥 Loading data...")
    print(f"   Min length: {args.min_length}")
    print(f"   Max length: {args.max_length}")
    if args.source:
        print(f"   Source: {args.source}")
    if args.language:
        print(f"   Language: {args.language}")

    texts_loaded = 0
    texts_skipped = 0

    with open(output_path, 'w', encoding='utf-8') as f:
        for text in load_data_streaming(
            client,
            min_length=args.min_length,
            max_length=args.max_length,
            language=args.source or args.language
        ):
            if texts_loaded >= args.limit:
                break

            # Write text (one per line)
            f.write(text.strip() + '\n')
            texts_loaded += 1

            if texts_loaded % 10000 == 0:
                print(f"   Loaded: {texts_loaded:,} samples...")

    print(f"\n✅ Load complete!")
    print(f"   Output: {output_path}")
    print(f"   Samples loaded: {texts_loaded:,}")

    # Estimate file size
    file_size = output_path.stat().st_size
    file_size_mb = file_size / (1024 * 1024)
    print(f"   File size: {file_size_mb:.2f} MB")

    # Estimate tokens
    est_tokens = texts_loaded * 250  # Average ~250 tokens per text
    print(f"   Estimated tokens: {est_tokens:,}")

    print("\n" + "="*60)
    print("Next steps:")
    print("="*60)
    print(f"1. Train tokenizer:")
    print(f"   python scripts/train_tokenizer.py --data {args.output} --output data/tokenizer.json")
    print(f"\n2. Train model:")
    print(f"   python scripts/train.py --data_path {args.output} --config config/gpu_training.yaml")
    print("="*60)


if __name__ == "__main__":
    main()
