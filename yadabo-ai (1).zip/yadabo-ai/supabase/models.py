"""
Yadabo AI - Supabase Data Models
Data models for training data storage
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any
from datetime import datetime
import json


@dataclass
class TrainingData:
    """
    Training data record.

    Represents a single text sample for model training.
    """

    id: Optional[int] = None
    text: str = ""
    source: str = "unknown"
    language: Optional[str] = None
    category: Optional[str] = None

    # Metadata
    length: int = 0
    tokens_estimate: int = 0
    created_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    # Quality indicators
    quality_score: Optional[float] = None
    is_filtered: bool = False

    def __post_init__(self):
        """Calculate estimates if not provided."""
        if not self.length and self.text:
            self.length = len(self.text)
        if not self.tokens_estimate and self.text:
            # Rough estimate: ~4 chars per token
            self.tokens_estimate = self.length // 4

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        if self.metadata:
            data["metadata"] = json.dumps(self.metadata)
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrainingData":
        """Create from dictionary."""
        if "metadata" in data and isinstance(data["metadata"], str):
            try:
                data["metadata"] = json.loads(data["metadata"])
            except:
                data["metadata"] = None

        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class DatasetMetadata:
    """
    Metadata for a dataset.

    Tracks information about a collection of training data.
    """

    id: Optional[int] = None
    name: str = ""
    description: str = ""

    # Statistics
    total_samples: int = 0
    total_size_bytes: int = 0
    total_tokens: int = 0

    # Content breakdown
    languages: Dict[str, int] = field(default_factory=dict)
    categories: Dict[str, int] = field(default_factory=dict)

    # Quality
    avg_quality_score: float = 0.0
    avg_length: float = 0.0

    # Timestamps
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_trained_at: Optional[str] = None

    # Training status
    is_ready: bool = False
    training_steps: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        if self.languages:
            data["languages"] = json.dumps(self.languages)
        if self.categories:
            data["categories"] = json.dumps(self.categories)
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DatasetMetadata":
        """Create from dictionary."""
        if "languages" in data and isinstance(data["languages"], str):
            try:
                data["languages"] = json.loads(data["languages"])
            except:
                data["languages"] = {}

        if "categories" in data and isinstance(data["categories"], str):
            try:
                data["categories"] = json.loads(data["categories"])
            except:
                data["categories"] = {}

        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ModelCheckpoint:
    """
    Model checkpoint metadata.

    Tracks information about saved model checkpoints.
    """

    id: Optional[int] = None
    version: str = "v1.0"
    description: str = ""

    # Model info
    config: Dict[str, Any] = field(default_factory=dict)
    total_parameters: int = 0

    # Training info
    training_steps: int = 0
    epochs_completed: int = 0
    last_loss: float = 0.0
    best_loss: float = float('inf')

    # Performance metrics
    perplexity: float = 0.0
    accuracy: float = 0.0

    # File info
    file_path: str = ""
    file_size_bytes: int = 0

    # Status
    is_best: bool = False
    is_published: bool = False

    # Timestamps
    created_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        if self.config:
            data["config"] = json.dumps(self.config)
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelCheckpoint":
        """Create from dictionary."""
        if "config" in data and isinstance(data["config"], str):
            try:
                data["config"] = json.loads(data["config"])
            except:
                data["config"] = {}

        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# Sample data types
class DataCategory:
    """Data category constants."""
    CODE = "code"
    TEXT = "text"
    MATH = "math"
    CONVERSATION = "conversation"
    ARABIC = "arabic"
    ENGLISH = "english"
    MIXED = "mixed"


class DataSource:
    """Data source constants."""
    MANUAL = "manual"
    WEB_SCRAPING = "web_scraping"
    BOOKS = "books"
    WIKIPEDIA = "wikipedia"
    CODE_REPOS = "code_repositories"
    CONVERSATIONS = "conversations"
    SYNTHETIC = "synthetic"
