-- Yadabo AI - Supabase Database Schema
-- Run this SQL in Supabase SQL Editor to create required tables

-- ============================================
-- Training Data Table
-- ============================================
CREATE TABLE IF NOT EXISTS training_data (
    id BIGSERIAL PRIMARY KEY,

    -- Core content
    text TEXT NOT NULL,
    source VARCHAR(255) DEFAULT 'unknown',

    -- Language and category
    language VARCHAR(50),
    category VARCHAR(100),

    -- Metadata
    length INTEGER,
    tokens_estimate INTEGER,
    metadata JSONB,

    -- Quality indicators
    quality_score FLOAT,
    is_filtered BOOLEAN DEFAULT FALSE,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for fast retrieval
CREATE INDEX IF NOT EXISTS idx_training_data_source ON training_data(source);
CREATE INDEX IF NOT EXISTS idx_training_data_language ON training_data(language);
CREATE INDEX IF NOT EXISTS idx_training_data_length ON training_data(length);
CREATE INDEX IF NOT EXISTS idx_training_data_created_at ON training_data(created_at DESC);

-- Full text search
ALTER TABLE training_data ADD COLUMN IF NOT EXISTS text_search_vector TSVECTOR;
UPDATE training_data SET text_search_vector = to_tsvector('english', text);
CREATE INDEX IF NOT EXISTS idx_training_data_fts ON training_data USING GIN(text_search_vector);

-- ============================================
-- Dataset Metadata Table
-- ============================================
CREATE TABLE IF NOT EXISTS datasets (
    id BIGSERIAL PRIMARY KEY,

    -- Basic info
    name VARCHAR(255) NOT NULL,
    description TEXT,

    -- Statistics
    total_samples BIGINT DEFAULT 0,
    total_size_bytes BIGINT DEFAULT 0,
    total_tokens BIGINT DEFAULT 0,

    -- Content breakdown (JSON)
    languages JSONB DEFAULT '{}',
    categories JSONB DEFAULT '{}',

    -- Quality
    avg_quality_score FLOAT,
    avg_length FLOAT,

    -- Status
    is_ready BOOLEAN DEFAULT FALSE,
    training_steps INTEGER DEFAULT 0,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_trained_at TIMESTAMPTZ
);

-- ============================================
-- Model Checkpoints Table
-- ============================================
CREATE TABLE IF NOT EXISTS model_checkpoints (
    id BIGSERIAL PRIMARY KEY,

    -- Version info
    version VARCHAR(50) NOT NULL,
    description TEXT,

    -- Model config (JSON)
    config JSONB,

    -- Model info
    total_parameters BIGINT DEFAULT 0,

    -- Training info
    training_steps INTEGER DEFAULT 0,
    epochs_completed INTEGER DEFAULT 0,
    last_loss FLOAT,
    best_loss FLOAT,

    -- Performance metrics
    perplexity FLOAT,
    accuracy FLOAT,

    -- File storage (if using Supabase Storage)
    file_path VARCHAR(500),
    file_size_bytes BIGINT,

    -- Status
    is_best BOOLEAN DEFAULT FALSE,
    is_published BOOLEAN DEFAULT FALSE,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- Training Logs Table
-- ============================================
CREATE TABLE IF NOT EXISTS training_logs (
    id BIGSERIAL PRIMARY KEY,

    -- Training run info
    run_id UUID DEFAULT gen_random_uuid(),
    checkpoint_id BIGINT REFERENCES model_checkpoints(id),

    -- Metrics
    step INTEGER NOT NULL,
    epoch INTEGER,
    loss FLOAT,
    perplexity FLOAT,
    learning_rate FLOAT,
    batch_size INTEGER,

    -- GPU metrics
    gpu_memory_mb FLOAT,
    gpu_utilization FLOAT,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_training_logs_run_id ON training_logs(run_id);
CREATE INDEX IF NOT EXISTS idx_training_logs_checkpoint ON training_logs(checkpoint_id);

-- ============================================
-- Functions and Triggers
-- ============================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to tables with updated_at
DROP TRIGGER IF EXISTS update_training_data_updated_at ON training_data;
CREATE TRIGGER update_training_data_updated_at
    BEFORE UPDATE ON training_data
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_datasets_updated_at ON datasets;
CREATE TRIGGER update_datasets_updated_at
    BEFORE UPDATE ON datasets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================
-- Row Level Security (RLS)
-- ============================================

ALTER TABLE training_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE datasets ENABLE ROW LEVEL SECURITY;
ALTER TABLE model_checkpoints ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_logs ENABLE ROW LEVEL SECURITY;

-- Allow all operations for authenticated users (for now)
-- Adjust policies based on your security requirements

CREATE POLICY "Enable read access for authenticated users" ON training_data
    FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert access for authenticated users" ON training_data
    FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users" ON training_data
    FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Enable delete access for authenticated users" ON training_data
    FOR DELETE TO authenticated USING (true);

-- ============================================
-- Sample Data (Optional)
-- ============================================

-- Insert some sample training data
INSERT INTO training_data (text, source, language, length) VALUES
    ('Hello, world! This is a sample training text.', 'sample', 'english', 50),
    ('مرحباً بالعالم! هذا نص تدريب عربي.', 'sample', 'arabic', 35),
    ('def hello_world():\n    print("Hello, World!")', 'code', 'python', 50),
    ('function add(a, b) {\n    return a + b;\n}', 'code', 'javascript', 45)
ON CONFLICT DO NOTHING;

-- Insert sample dataset metadata
INSERT INTO datasets (name, description, total_samples, is_ready) VALUES
    ('Sample Dataset', 'A small sample dataset for testing', 4, TRUE)
ON CONFLICT DO NOTHING;

SELECT 'Schema created successfully!' as status;
