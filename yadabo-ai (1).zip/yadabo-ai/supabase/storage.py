"""
Yadabo AI - Supabase Data Storage
Utilities for storing and managing training data in Supabase
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Iterator
from pathlib import Path
import hashlib

logger = logging.getLogger(__name__)


class DataStorage:
    """
    Data storage manager for Supabase.

    Handles:
    - Uploading data files to Supabase Storage
    - Managing training data in database
    - Data quality filtering
    - Batch operations
    """

    def __init__(self, supabase_client):
        """
        Initialize data storage.

        Args:
            supabase_client: SupabaseClient instance
        """
        self.client = supabase_client
        self.batch_size = 1000

    def upload_text_file(
        self,
        file_path: str,
        source_name: str = "file_upload",
        encoding: str = "utf-8"
    ) -> Dict[str, Any]:
        """
        Upload a text file to training database.

        Args:
            file_path: Path to text file
            source_name: Source identifier
            encoding: Text encoding

        Returns:
            Upload result
        """
        if not os.path.exists(file_path):
            return {"error": f"File not found: {file_path}"}

        try:
            with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                texts = [line.strip() for line in f if line.strip()]

            # Calculate checksum
            with open(file_path, 'rb') as f:
                file_hash = hashlib.md5(f.read()).hexdigest()

            # Store metadata
            metadata = {
                "file_hash": file_hash,
                "file_name": os.path.basename(file_path),
                "total_lines": len(texts)
            }

            result = self.client.store_training_data(
                texts=texts,
                metadata=metadata,
                source=source_name
            )

            result["file_hash"] = file_hash
            result["lines_uploaded"] = len(texts)

            return result

        except Exception as e:
            logger.error(f"Error uploading file: {e}")
            return {"error": str(e)}

    def upload_jsonl(
        self,
        file_path: str,
        text_field: str = "text",
        source_name: str = "jsonl_upload"
    ) -> Dict[str, Any]:
        """
        Upload a JSONL file to training database.

        JSONL format: {"text": "...", "metadata": {...}}

        Args:
            file_path: Path to JSONL file
            text_field: Field name containing text
            source_name: Source identifier

        Returns:
            Upload result
        """
        if not os.path.exists(file_path):
            return {"error": f"File not found: {file_path}"}

        try:
            texts = []
            metadata_list = []

            with open(file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f):
                    try:
                        data = json.loads(line.strip())
                        text = data.get(text_field, "")

                        if text and len(text) > 10:  # Skip very short texts
                            texts.append(text)

                            # Store additional fields as metadata
                            meta = {k: v for k, v in data.items() if k != text_field}
                            if meta:
                                metadata_list.append(meta)

                    except json.JSONDecodeError:
                        continue

            # Upload in batches
            total_uploaded = 0
            for i in range(0, len(texts), self.batch_size):
                batch_texts = texts[i:i + self.batch_size]
                batch_meta = metadata_list[i:i + self.batch_size] if metadata_list else None

                result = self.client.store_training_data(
                    texts=batch_texts,
                    metadata=batch_meta,
                    source=source_name
                )

                if "error" in result:
                    logger.warning(f"Batch {i} had errors: {result['error']}")
                else:
                    total_uploaded += result.get("count", 0)

            return {
                "success": True,
                "lines_uploaded": total_uploaded,
                "total_lines": len(texts)
            }

        except Exception as e:
            logger.error(f"Error uploading JSONL: {e}")
            return {"error": str(e)}

    def upload_directory(
        self,
        directory_path: str,
        file_pattern: str = "*.txt",
        source_name: str = "directory_upload"
    ) -> Dict[str, Any]:
        """
        Upload all matching files in a directory.

        Args:
            directory_path: Path to directory
            file_pattern: Glob pattern for files
            source_name: Base source name

        Returns:
            Upload results summary
        """
        directory = Path(directory_path)
        if not directory.exists():
            return {"error": f"Directory not found: {directory_path}"}

        results = {
            "files_processed": 0,
            "files_failed": 0,
            "total_lines": 0,
            "errors": []
        }

        for file_path in directory.glob(file_pattern):
            source = f"{source_name}/{file_path.name}"

            result = self.upload_text_file(
                str(file_path),
                source_name=source
            )

            results["files_processed"] += 1

            if "error" in result:
                results["files_failed"] += 1
                results["errors"].append({
                    "file": str(file_path),
                    "error": result["error"]
                })
            else:
                results["total_lines"] += result.get("lines_uploaded", 0)

        return results

    def filter_data(
        self,
        min_length: int = 50,
        max_length: int = 50000,
        remove_duplicates: bool = True,
        remove_html: bool = True
    ) -> Dict[str, Any]:
        """
        Filter stored training data.

        Args:
            min_length: Minimum text length
            max_length: Maximum text length
            remove_duplicates: Remove duplicate texts
            remove_html: Remove HTML tags

        Returns:
            Filtering results
        """
        # This would typically involve:
        # 1. Fetching all data
        # 2. Applying filters
        # 3. Updating/deleting filtered records

        # For now, return placeholder
        return {
            "status": "not_implemented",
            "message": "Use SQL queries for filtering"
        }

    def get_training_batch(
        self,
        batch_size: int = 1000,
        shuffle: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get a random batch of training data.

        Args:
            batch_size: Number of samples
            shuffle: Whether to shuffle (randomize)

        Returns:
            List of training samples
        """
        if not shuffle:
            return self.client.get_training_data(limit=batch_size)

        # For random sampling, we'd need a more complex query
        # This is simplified
        return self.client.get_training_data(limit=batch_size)

    def export_to_file(
        self,
        output_path: str,
        format: str = "jsonl",
        limit: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Export training data to file.

        Args:
            output_path: Output file path
            format: Output format ('jsonl', 'txt', 'json')
            limit: Maximum samples to export

        Returns:
            Export results
        """
        try:
            texts = self.client.get_training_data(
                limit=limit or 100000,
                min_length=10
            )

            if not texts:
                return {"error": "No data to export"}

            with open(output_path, 'w', encoding='utf-8') as f:
                for record in texts:
                    if format == "jsonl":
                        json.dump({"text": record["text"]}, f)
                        f.write("\n")
                    elif format == "txt":
                        f.write(record["text"] + "\n")
                    elif format == "json":
                        json.dump(record, f)
                        f.write("\n")

            return {
                "success": True,
                "output_file": output_path,
                "records_exported": len(texts)
            }

        except Exception as e:
            logger.error(f"Error exporting data: {e}")
            return {"error": str(e)}


def create_storage_from_env() -> DataStorage:
    """
    Create DataStorage with Supabase client from environment.

    Returns:
        DataStorage instance
    """
    from .client import init_supabase_from_env

    client = init_supabase_from_env()
    return DataStorage(client)
