"""
Yadabo AI - Supabase Database Client
Connect to Supabase for training data storage and retrieval
"""

import os
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
import json

try:
    from supabase import create_client, Client
    HAS_SUPABASE = True
except ImportError:
    HAS_SUPABASE = False
    Client = None

logger = logging.getLogger(__name__)


@dataclass
class SupabaseConfig:
    """Supabase configuration."""
    url: str
    key: str
    anon_key: Optional[str] = None


class SupabaseClient:
    """
    Supabase client for Yadabo AI training data.

    Handles connection to Supabase database for:
    - Storing large training datasets
    - Retrieving training data for model training
    - Managing dataset metadata

    Args:
        url: Supabase project URL
        key: Supabase API key (service role or anon key)
        anon_key: Optional anon key for public access
    """

    def __init__(
        self,
        url: Optional[str] = None,
        key: Optional[str] = None,
        anon_key: Optional[str] = None,
    ):
        # Get from environment if not provided
        self.url = url or os.environ.get("SUPABASE_URL", "")
        self.key = key or os.environ.get("SUPABASE_KEY", "")
        self.anon_key = anon_key or os.environ.get("SUPABASE_ANON_KEY", "")

        if not self.url or not self.key:
            logger.warning("Supabase credentials not provided!")
            self.client = None
            return

        if not HAS_SUPABASE:
            logger.warning("supabase-py not installed. Run: pip install supabase")
            self.client = None
            return

        try:
            self.client: Client = create_client(self.url, self.key)
            logger.info(f"Connected to Supabase: {self.url}")
        except Exception as e:
            logger.error(f"Failed to connect to Supabase: {e}")
            self.client = None

    def is_connected(self) -> bool:
        """Check if connected to Supabase."""
        return self.client is not None

    # ========================================
    # Training Data Methods
    # ========================================

    def store_training_data(
        self,
        texts: List[str],
        metadata: Optional[Dict[str, Any]] = None,
        source: str = "manual"
    ) -> Dict[str, Any]:
        """
        Store training data in database.

        Args:
            texts: List of text samples
            metadata: Optional metadata for each sample
            source: Source of the data

        Returns:
            Storage result
        """
        if not self.is_connected():
            return {"error": "Not connected to Supabase"}

        try:
            table = self.client.table("training_data")

            records = []
            for i, text in enumerate(texts):
                record = {
                    "text": text,
                    "source": source,
                    "length": len(text),
                    "tokens_estimate": len(text) // 4,  # Rough estimate
                }

                if metadata and i < len(metadata):
                    record["metadata"] = json.dumps(metadata[i])

                records.append(record)

            result = table.insert(records).execute()
            logger.info(f"Stored {len(records)} training samples")
            return {"success": True, "count": len(records)}

        except Exception as e:
            logger.error(f"Error storing training data: {e}")
            return {"error": str(e)}

    def get_training_data(
        self,
        limit: int = 1000,
        offset: int = 0,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        source: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve training data from database.

        Args:
            limit: Maximum number of samples
            offset: Offset for pagination
            min_length: Minimum text length filter
            max_length: Maximum text length filter
            source: Filter by source

        Returns:
            List of training samples
        """
        if not self.is_connected():
            return []

        try:
            query = self.client.table("training_data").select("*")

            # Apply filters
            if min_length:
                query = query.gte("length", min_length)
            if max_length:
                query = query.lte("length", max_length)
            if source:
                query = query.eq("source", source)

            query = query.range(offset, offset + limit - 1)

            result = query.execute()
            return result.data or []

        except Exception as e:
            logger.error(f"Error retrieving training data: {e}")
            return []

    def get_training_data_streaming(
        self,
        batch_size: int = 1000,
        min_length: int = 100,
        max_length: int = 10000,
    ):
        """
        Generator for streaming training data.

        Args:
            batch_size: Number of samples per batch
            min_length: Minimum text length
            max_length: Maximum text length

        Yields:
            Batches of training data
        """
        offset = 0

        while True:
            batch = self.get_training_data(
                limit=batch_size,
                offset=offset,
                min_length=min_length,
                max_length=max_length,
            )

            if not batch:
                break

            yield batch
            offset += batch_size

    def get_dataset_stats(self) -> Dict[str, Any]:
        """Get statistics about stored training data."""
        if not self.is_connected():
            return {"error": "Not connected"}

        try:
            # Get total count
            result = self.client.table("training_data").select("*", count="exact").execute()

            stats = {
                "total_samples": result.count or 0,
                "connected": True,
            }

            # Get size estimate
            if result.count:
                stats["estimated_size_gb"] = (result.count * 1000) / (1024 ** 3)

            return stats

        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {"error": str(e)}

    def delete_training_data(
        self,
        ids: List[int]
    ) -> Dict[str, Any]:
        """Delete training data by IDs."""
        if not self.is_connected():
            return {"error": "Not connected"}

        try:
            table = self.client.table("training_data")
            result = table.delete().in_("id", ids).execute()

            return {"success": True, "deleted": len(ids)}

        except Exception as e:
            logger.error(f"Error deleting data: {e}")
            return {"error": str(e)}


# Global client instance
_supabase_client: Optional[SupabaseClient] = None


def get_supabase_client() -> SupabaseClient:
    """
    Get or create Supabase client singleton.

    Returns:
        SupabaseClient instance
    """
    global _supabase_client

    if _supabase_client is None:
        _supabase_client = SupabaseClient()

    return _supabase_client


def create_supabase_client(
    url: str,
    key: str,
    anon_key: Optional[str] = None
) -> SupabaseClient:
    """
    Create new Supabase client with given credentials.

    Args:
        url: Supabase project URL
        key: API key
        anon_key: Optional anon key

    Returns:
        SupabaseClient instance
    """
    global _supabase_client
    _supabase_client = SupabaseClient(url=url, key=key, anon_key=anon_key)
    return _supabase_client


def init_supabase_from_env() -> SupabaseClient:
    """
    Initialize Supabase client from environment variables.

    Environment variables:
        SUPABASE_URL: Project URL
        SUPABASE_KEY: API key
        SUPABASE_ANON_KEY: Optional anon key

    Returns:
        SupabaseClient instance
    """
    return get_supabase_client()
