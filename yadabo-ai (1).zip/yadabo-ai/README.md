# Yadabo AI

A complete Transformer-based language model built from scratch, optimized for programming and mathematical tasks. Supports both Arabic and English languages.

## Features

- **Custom Transformer Architecture**: Built from scratch using PyTorch
- **BPE Tokenizer**: Custom Byte Pair Encoding tokenizer supporting Arabic and English
- **Modular Design**: Clean separation of model, training, data, and utilities
- **Production-Ready**: Checkpointing, logging, and scalability support
- **GPU-Optimized**: Ready for Google Cloud A100 and similar GPUs

## Quick Start

### Installation

```bash
pip install torch numpy tqdm
```

### Training

```bash
python scripts/train.py --config config/default.yaml
```

### Text Generation

```bash
python scripts/generate.py --checkpoint checkpoints/yadabo_best.pt --prompt "def hello_world():"
```

## Project Structure

```
yadabo-ai/
├── model/              # Transformer architecture
├── training/           # Training loop and optimizer
├── data/              # Dataset and tokenizer
├── utils/             # Helper functions
├── scripts/           # Training and inference scripts
├── config/            # Configuration files
├── tests/             # Unit tests
└── docs/              # Documentation
```

## Architecture

The model implements a complete Transformer architecture:

- Token Embeddings with learned positional encodings
- Multi-head self-attention mechanism
- Feed-forward networks with GELU activation
- Layer normalization and dropout
- Custom BPE tokenizer for Arabic and English

## Configuration

Default configuration targets:
- Model: 6 layers, 8 attention heads, 512 hidden dimension
- Training: AdamW optimizer, cosine learning rate schedule
- Batch size: 32, Sequence length: 512

For production training on A100:
- Model: 12 layers, 16 heads, 1024 hidden dimension
- Batch size: 64, Sequence length: 2048

## License

MIT License
