#!/usr/bin/env python3
"""
Yadabo AI - GCS Data Transfer Script
Upload and download training data from Google Cloud Storage

Usage:
    # Upload data
    python gcs/transfer.py upload --file data/train.txt --category arabic

    # Download data
    python gcs/transfer.py download --output data/downloaded/

    # Sync directory
    python gcs/transfer.py sync --local data/train/ --remote data/backup/
"""

import os
import sys
import argparse
import logging
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from gcs import get_gcs_client, GCSStorage

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Transfer training data with Google Cloud Storage"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Upload command
    upload_parser = subparsers.add_parser("upload", help="Upload data to GCS")
    upload_parser.add_argument("--file", type=str, help="File to upload")
    upload_parser.add_argument("--directory", type=str, help="Directory to upload")
    upload_parser.add_argument("--category", type=str, default="general", help="Data category")
    upload_parser.add_argument("--public", action="store_true", help="Make publicly accessible")

    # Download command
    download_parser = subparsers.add_parser("download", help="Download data from GCS")
    download_parser.add_argument("--output", type=str, default="data/", help="Output directory")
    download_parser.add_argument("--category", type=str, help="Filter by category")
    download_parser.add_argument("--limit", type=int, help="Limit number of files")

    # Sync command
    sync_parser = subparsers.add_parser("sync", help="Sync local and remote directories")
    sync_parser.add_argument("--local", type=str, required=True, help="Local directory")
    sync_parser.add_argument("--remote", type=str, required=True, help="Remote prefix")
    sync_parser.add_argument("--mode", choices=["upload", "download"], default="upload", help="Sync direction")

    # List command
    list_parser = subparsers.add_parser("list", help="List files in GCS")
    list_parser.add_argument("--prefix", type=str, help="Filter by prefix")

    # Stats command
    subparsers.add_parser("stats", help="Get storage statistics")

    return parser.parse_args()


def cmd_upload(args):
    """Handle upload command."""
    gcs = GCSStorage(get_gcs_client())

    if not gcs.client.is_connected():
        logger.error("Not connected to GCS")
        return

    if args.file:
        result = gcs.upload_training_data(
            args.file,
            category=args.category,
            make_public=args.public
        )

        if result.get("success"):
            logger.info(f"✅ Uploaded: {result.get('gcs_path')}")
        else:
            logger.error(f"❌ Failed: {result.get('error')}")

    elif args.directory:
        results = gcs.upload_directory(
            args.directory,
            category=args.category
        )

        logger.info(f"✅ Uploaded {results['files_uploaded']} files")
        if results['files_failed']:
            logger.warning(f"⚠️ Failed: {results['files_failed']} files")

    else:
        logger.error("Specify --file or --directory")


def cmd_download(args):
    """Handle download command."""
    gcs = GCSStorage(get_gcs_client())

    if not gcs.client.is_connected():
        logger.error("Not connected to GCS")
        return

    results = gcs.download_training_data(
        category=args.category,
        output_dir=args.output,
        limit=args.limit
    )

    logger.info(f"✅ Downloaded {results['files_downloaded']} files")
    if results.get('total_size'):
        size_mb = results['total_size'] / (1024 ** 2)
        logger.info(f"   Total size: {size_mb:.2f} MB")


def cmd_sync(args):
    """Handle sync command."""
    gcs = GCSStorage(get_gcs_client())

    if not gcs.client.is_connected():
        logger.error("Not connected to GCS")
        return

    if args.mode == "upload":
        results = gcs.upload_directory(
            args.local,
            category=args.remote.split("/")[-1] if "/" in args.remote else args.remote
        )
        logger.info(f"✅ Synced {results['files_uploaded']} files to GCS")

    else:
        results = gcs.download_training_data(
            category=args.remote,
            output_dir=args.local
        )
        logger.info(f"✅ Synced {results['files_downloaded']} files from GCS")


def cmd_list(args):
    """Handle list command."""
    client = get_gcs_client()

    if not client.is_connected():
        logger.error("Not connected to GCS")
        return

    files = client.list_files(prefix=args.prefix or "")

    logger.info(f"📁 Found {len(files)} files:")
    for f in files[:20]:
        logger.info(f"   gs://{client.bucket_name}/{f}")

    if len(files) > 20:
        logger.info(f"   ... and {len(files) - 20} more")


def cmd_stats(args):
    """Handle stats command."""
    gcs = GCSStorage(get_gcs_client())

    if not gcs.client.is_connected():
        logger.error("Not connected to GCS")
        return

    stats = gcs.get_storage_stats()

    print("\n" + "="*60)
    print("📊 Google Cloud Storage Statistics")
    print("="*60)
    print(f"Bucket: {stats.get('bucket_name')}")
    print(f"Location: {stats.get('location')}")
    print(f"Total files: {stats.get('total_files', 0):,}")
    print(f"Total size: {stats.get('total_size_gb', 0):.2f} GB")
    print(f"\nCategories:")
    for cat in stats.get('categories', []):
        print(f"   - {cat}")
    print("="*60)


def main():
    """Main transfer function."""
    args = parse_args()

    print("="*60)
    print("📦 Yadabo AI - Google Cloud Storage Transfer")
    print("="*60)

    # Initialize GCS client
    client = get_gcs_client()

    if not client.is_connected():
        print("\n❌ Error: Not connected to GCS")
        print("\nPlease set these environment variables:")
        print("  export GCS_PROJECT_ID=your-project-id")
        print("  export GCS_BUCKET_NAME=your-bucket-name")
        print("  export GCS_CREDENTIALS=path/to/service-account.json")
        return

    print(f"\n✅ Connected to GCS")
    print(f"   Project: {client.project_id}")
    print(f"   Bucket: {client.bucket_name}")

    # Execute command
    if args.command == "upload":
        cmd_upload(args)
    elif args.command == "download":
        cmd_download(args)
    elif args.command == "sync":
        cmd_sync(args)
    elif args.command == "list":
        cmd_list(args)
    elif args.command == "stats":
        cmd_stats(args)
    else:
        print("\nUsage:")
        print("  python gcs/transfer.py upload --file data/train.txt --category arabic")
        print("  python gcs/transfer.py download --output data/")
        print("  python gcs/transfer.py sync --local data/ --remote backup/")
        print("  python gcs/transfer.py list --prefix data/")
        print("  python gcs/transfer.py stats")


if __name__ == "__main__":
    main()
