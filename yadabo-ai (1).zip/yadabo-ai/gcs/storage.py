"""
Yadabo AI - GCS Data Storage
Utilities for storing and managing training data in GCS
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Iterator
from pathlib import Path
import hashlib

logger = logging.getLogger(__name__)


class GCSStorage:
    """
    Google Cloud Storage manager for Yadabo AI.

    Handles:
    - Uploading large training datasets
    - Downloading data for training
    - Managing model checkpoints
    - Organizing data by category
    """

    def __init__(self, gcs_client):
        """
        Initialize GCS storage.

        Args:
            gcs_client: GCSClient instance
        """
        self.client = gcs_client

        # Base paths
        self.data_prefix = "data/"
        self.checkpoint_prefix = "checkpoints/"
        self.tokenizer_prefix = "tokenizer/"

    def upload_training_data(
        self,
        file_path: str,
        category: str = "general",
        make_public: bool = False,
    ) -> Dict[str, Any]:
        """
        Upload training data file to GCS.

        Args:
            file_path: Local file path
            category: Data category (e.g., 'arabic', 'code', 'math')
            make_public: Make file publicly accessible

        Returns:
            Upload result
        """
        filename = os.path.basename(file_path)
        destination = f"{self.data_prefix}{category}/{filename}"

        result = self.client.upload_file(
            source_path=file_path,
            destination_path=destination,
            make_public=make_public,
        )

        if result.get("success"):
            result["gcs_path"] = f"gs://{self.client.bucket_name}/{destination}"

        return result

    def upload_directory(
        self,
        directory_path: str,
        category: str = "general",
        file_pattern: str = "*.txt",
    ) -> Dict[str, Any]:
        """
        Upload all files in a directory.

        Args:
            directory_path: Local directory path
            category: Data category
            file_pattern: Glob pattern for files

        Returns:
            Upload results summary
        """
        directory = Path(directory_path)
        if not directory.exists():
            return {"error": f"Directory not found: {directory_path}"}

        results = {
            "files_uploaded": 0,
            "files_failed": 0,
            "total_size": 0,
            "errors": []
        }

        for file_path in directory.glob(file_pattern):
            result = self.upload_training_data(
                str(file_path),
                category=category
            )

            if result.get("success"):
                results["files_uploaded"] += 1
                results["total_size"] += result.get("size", 0)
            else:
                results["files_failed"] += 1
                results["errors"].append({
                    "file": str(file_path),
                    "error": result.get("error", "Unknown error")
                })

        logger.info(f"Uploaded {results['files_uploaded']} files to {category}")

        return results

    def download_training_data(
        self,
        category: str = None,
        output_dir: str = "data",
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Download training data from GCS.

        Args:
            category: Filter by category (None for all)
            output_dir: Local output directory
            limit: Maximum number of files to download

        Returns:
            Download results
        """
        if not self.client.is_connected():
            return {"error": "Not connected to GCS"}

        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # List files
        prefix = f"{self.data_prefix}{category}/" if category else self.data_prefix
        files = self.client.list_files(prefix=prefix)

        if limit:
            files = files[:limit]

        results = {
            "files_downloaded": 0,
            "files_failed": 0,
            "total_size": 0,
        }

        for file_path in files:
            # Get local filename
            filename = os.path.basename(file_path)
            local_path = output_path / filename

            # Download
            result = self.client.download_file(
                source_path=file_path,
                destination_path=str(local_path)
            )

            if result.get("success"):
                results["files_downloaded"] += 1
                results["total_size"] += result.get("size", 0)
            else:
                results["files_failed"] += 1

        logger.info(f"Downloaded {results['files_downloaded']} files")

        return results

    def upload_checkpoint(
        self,
        checkpoint_path: str,
        version: str = "latest",
    ) -> Dict[str, Any]:
        """
        Upload model checkpoint to GCS.

        Args:
            checkpoint_path: Local checkpoint file path
            version: Version identifier

        Returns:
            Upload result
        """
        filename = os.path.basename(checkpoint_path)
        destination = f"{self.checkpoint_prefix}{version}/{filename}"

        result = self.client.upload_file(
            source_path=checkpoint_path,
            destination_path=destination,
        )

        if result.get("success"):
            result["gcs_path"] = f"gs://{self.client.bucket_name}/{destination}"

        return result

    def download_checkpoint(
        self,
        checkpoint_name: str,
        version: str = "latest",
        output_dir: str = "checkpoints",
    ) -> Dict[str, Any]:
        """
        Download model checkpoint from GCS.

        Args:
            checkpoint_name: Checkpoint filename
            version: Version identifier
            output_dir: Local output directory

        Returns:
            Download result
        """
        source_path = f"{self.checkpoint_prefix}{version}/{checkpoint_name}"
        output_path = Path(output_dir) / checkpoint_name
        output_path.parent.mkdir(parents=True, exist_ok=True)

        return self.client.download_file(
            source_path=source_path,
            destination_path=str(output_path),
        )

    def upload_tokenizer(
        self,
        tokenizer_path: str,
    ) -> Dict[str, Any]:
        """
        Upload tokenizer to GCS.

        Args:
            tokenizer_path: Local tokenizer file path

        Returns:
            Upload result
        """
        filename = os.path.basename(tokenizer_path)
        destination = f"{self.tokenizer_prefix}{filename}"

        return self.client.upload_file(
            source_path=tokenizer_path,
            destination_path=destination,
            make_public=True,
        )

    def download_tokenizer(
        self,
        tokenizer_name: str,
        output_dir: str = "data",
    ) -> Dict[str, Any]:
        """
        Download tokenizer from GCS.

        Args:
            tokenizer_name: Tokenizer filename
            output_dir: Local output directory

        Returns:
            Download result
        """
        source_path = f"{self.tokenizer_prefix}{tokenizer_name}"
        output_path = Path(output_dir) / tokenizer_name
        output_path.parent.mkdir(parents=True, exist_ok=True)

        return self.client.download_file(
            source_path=source_path,
            destination_path=str(output_path),
        )

    def list_data_categories(self) -> List[str]:
        """
        List all data categories in the bucket.

        Returns:
            List of category names
        """
        files = self.client.list_files(prefix=self.data_prefix)
        categories = set()

        for file_path in files:
            # Extract category from path
            parts = file_path.replace(self.data_prefix, "").split("/")
            if len(parts) >= 2:
                categories.add(parts[0])

        return sorted(list(categories))

    def get_storage_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.

        Returns:
            Storage statistics
        """
        if not self.client.is_connected():
            return {"error": "Not connected"}

        # Get bucket info
        bucket_info = self.client.get_bucket_info()

        # List all files
        all_files = self.client.list_files()

        total_size = 0
        file_count = 0

        for file_path in all_files:
            info = self.client.get_file_info(file_path)
            if "size" in info:
                total_size += info["size"]
                file_count += 1

        # Get categories
        categories = self.list_data_categories()

        return {
            "bucket_name": self.client.bucket_name,
            "total_files": file_count,
            "total_size_bytes": total_size,
            "total_size_gb": total_size / (1024 ** 3),
            "categories": categories,
            **bucket_info,
        }


def create_gcs_storage_from_env() -> GCSStorage:
    """
    Create GCSStorage with client from environment.

    Returns:
        GCSStorage instance
    """
    from .client import get_gcs_client

    client = get_gcs_client()
    return GCSStorage(client)
