"""
Yadabo AI - Google Cloud Storage Client
Connect to GCS for training data storage
"""

import os
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

try:
    from google.cloud import storage
    from google.cloud.storage import Bucket, Blob
    HAS_GCS = True
except ImportError:
    HAS_GCS = False
    storage = None
    Bucket = None
    Blob = None

logger = logging.getLogger(__name__)


@dataclass
class GCSConfig:
    """Google Cloud Storage configuration."""
    project_id: str
    bucket_name: str
    credentials_path: Optional[str] = None


class GCSClient:
    """
    Google Cloud Storage client for Yadabo AI.

    Handles connection to GCS for:
    - Storing large training datasets
    - Retrieving training data for model training
    - Managing model checkpoints
    - Storing tokenizer files

    Args:
        project_id: Google Cloud project ID
        bucket_name: GCS bucket name
        credentials_path: Path to service account JSON key file
    """

    def __init__(
        self,
        project_id: Optional[str] = None,
        bucket_name: Optional[str] = None,
        credentials_path: Optional[str] = None,
    ):
        # Get from environment if not provided
        self.project_id = project_id or os.environ.get("GCS_PROJECT_ID", "")
        self.bucket_name = bucket_name or os.environ.get("GCS_BUCKET_NAME", "")
        self.credentials_path = credentials_path or os.environ.get("GCS_CREDENTIALS", "")

        self._client = None
        self._bucket = None

        if not self.project_id:
            logger.warning("GCS project_id not provided!")
            return

        if not HAS_GCS:
            logger.warning("google-cloud-storage not installed. Run: pip install google-cloud-storage")
            return

        try:
            # Initialize client
            if self.credentials_path and os.path.exists(self.credentials_path):
                self._client = storage.Client.from_service_account_json(
                    self.credentials_path,
                    project=self.project_id
                )
            else:
                # Use default credentials (ADC)
                self._client = storage.Client(project=self.project_id)

            # Get bucket
            if self.bucket_name:
                self._bucket = self._client.bucket(self.bucket_name)
                logger.info(f"Connected to GCS bucket: {self.bucket_name}")

        except Exception as e:
            logger.error(f"Failed to connect to GCS: {e}")
            self._client = None
            self._bucket = None

    def is_connected(self) -> bool:
        """Check if connected to GCS."""
        return self._client is not None and self._bucket is not None

    @property
    def bucket(self) -> Optional[Bucket]:
        """Get the bucket object."""
        return self._bucket

    @property
    def client(self):
        """Get the storage client."""
        return self._client

    # ========================================
    # Bucket Operations
    # ========================================

    def list_buckets(self) -> List[str]:
        """List all buckets in the project."""
        if not self.is_connected():
            return []

        try:
            buckets = list(self._client.list_buckets())
            return [b.name for b in buckets]
        except Exception as e:
            logger.error(f"Error listing buckets: {e}")
            return []

    def get_bucket_info(self) -> Dict[str, Any]:
        """Get bucket information."""
        if not self.is_connected():
            return {"error": "Not connected"}

        try:
            bucket = self._client.get_bucket(self.bucket_name)
            return {
                "name": bucket.name,
                "project": bucket.project,
                "location": bucket.location,
                "storage_class": bucket.storage_class,
                "created": bucket.time_created,
            }
        except Exception as e:
            return {"error": str(e)}

    # ========================================
    # Blob Operations
    # ========================================

    def upload_file(
        self,
        source_path: str,
        destination_path: str,
        make_public: bool = False,
    ) -> Dict[str, Any]:
        """
        Upload a file to GCS.

        Args:
            source_path: Local file path
            destination_path: GCS object path (e.g., 'data/train.txt')
            make_public: Make the file publicly accessible

        Returns:
            Upload result
        """
        if not self.is_connected():
            return {"error": "Not connected to GCS"}

        try:
            blob = self._bucket.blob(destination_path)
            blob.upload_from_filename(source_path)

            if make_public:
                blob.make_public()

            result = {
                "success": True,
                "bucket": self.bucket_name,
                "path": destination_path,
                "size": blob.size,
                "public_url": blob.public_url if make_public else None,
            }

            logger.info(f"Uploaded {source_path} to gs://{self.bucket_name}/{destination_path}")
            return result

        except Exception as e:
            logger.error(f"Error uploading file: {e}")
            return {"error": str(e)}

    def download_file(
        self,
        source_path: str,
        destination_path: str,
    ) -> Dict[str, Any]:
        """
        Download a file from GCS.

        Args:
            source_path: GCS object path
            destination_path: Local file path

        Returns:
            Download result
        """
        if not self.is_connected():
            return {"error": "Not connected to GCS"}

        try:
            blob = self._bucket.blob(source_path)
            blob.download_to_filename(destination_path)

            result = {
                "success": True,
                "path": destination_path,
                "size": blob.size,
            }

            logger.info(f"Downloaded gs://{self.bucket_name}/{source_path} to {destination_path}")
            return result

        except Exception as e:
            logger.error(f"Error downloading file: {e}")
            return {"error": str(e)}

    def upload_string(
        self,
        content: str,
        destination_path: str,
        make_public: bool = False,
    ) -> Dict[str, Any]:
        """
        Upload string content to GCS.

        Args:
            content: String content to upload
            destination_path: GCS object path
            make_public: Make the file publicly accessible

        Returns:
            Upload result
        """
        if not self.is_connected():
            return {"error": "Not connected to GCS"}

        try:
            blob = self._bucket.blob(destination_path)
            blob.upload_from_string(content)

            if make_public:
                blob.make_public()

            result = {
                "success": True,
                "bucket": self.bucket_name,
                "path": destination_path,
                "size": len(content),
                "public_url": blob.public_url if make_public else None,
            }

            logger.info(f"Uploaded content to gs://{self.bucket_name}/{destination_path}")
            return result

        except Exception as e:
            logger.error(f"Error uploading string: {e}")
            return {"error": str(e)}

    def download_string(self, source_path: str) -> Optional[str]:
        """
        Download string content from GCS.

        Args:
            source_path: GCS object path

        Returns:
            File content as string
        """
        if not self.is_connected():
            return None

        try:
            blob = self._bucket.blob(source_path)
            content = blob.download_as_text()
            return content

        except Exception as e:
            logger.error(f"Error downloading string: {e}")
            return None

    def list_files(self, prefix: str = "") -> List[str]:
        """
        List files in the bucket.

        Args:
            prefix: Filter files by prefix

        Returns:
            List of file paths
        """
        if not self.is_connected():
            return []

        try:
            blobs = list(self._bucket.list_blobs(prefix=prefix))
            return [blob.name for blob in blobs]

        except Exception as e:
            logger.error(f"Error listing files: {e}")
            return []

    def delete_file(self, path: str) -> Dict[str, Any]:
        """
        Delete a file from GCS.

        Args:
            path: GCS object path

        Returns:
            Delete result
        """
        if not self.is_connected():
            return {"error": "Not connected to GCS"}

        try:
            blob = self._bucket.blob(path)
            blob.delete()

            logger.info(f"Deleted gs://{self.bucket_name}/{path}")
            return {"success": True}

        except Exception as e:
            logger.error(f"Error deleting file: {e}")
            return {"error": str(e)}

    def get_file_info(self, path: str) -> Dict[str, Any]:
        """
        Get file information.

        Args:
            path: GCS object path

        Returns:
            File metadata
        """
        if not self.is_connected():
            return {"error": "Not connected"}

        try:
            blob = self._bucket.blob(path)
            blob.reload()

            return {
                "name": blob.name,
                "size": blob.size,
                "content_type": blob.content_type,
                "created": blob.time_created,
                "updated": blob.updated,
                "public_url": blob.public_url,
            }

        except Exception as e:
            logger.error(f"Error getting file info: {e}")
            return {"error": str(e)}


# Global client instance
_gcs_client: Optional[GCSClient] = None


def get_gcs_client() -> GCSClient:
    """
    Get or create GCS client singleton.

    Returns:
        GCSClient instance
    """
    global _gcs_client

    if _gcs_client is None:
        _gcs_client = GCSClient()

    return _gcs_client


def create_gcs_client(
    project_id: str,
    bucket_name: str,
    credentials_path: Optional[str] = None
) -> GCSClient:
    """
    Create new GCS client with given credentials.

    Args:
        project_id: GCP project ID
        bucket_name: Bucket name
        credentials_path: Service account key path

    Returns:
        GCSClient instance
    """
    global _gcs_client
    _gcs_client = GCSClient(
        project_id=project_id,
        bucket_name=bucket_name,
        credentials_path=credentials_path
    )
    return _gcs_client
