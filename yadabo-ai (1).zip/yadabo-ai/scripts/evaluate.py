#!/usr/bin/env python3
"""
Yadabo AI - Evaluation Script

Evaluate a trained model on test data.
Computes perplexity, accuracy, and other metrics.

Usage:
    python scripts/evaluate.py --checkpoint output/checkpoint_best.pt --data data/test.txt
"""

import os
import sys
import argparse
import logging
from pathlib import Path

import torch
from tqdm import tqdm

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from model import TransformerLM
from data import TextDataset, DataCollator, create_dataloader
from utils import setup_logger, get_device
from utils.metrics import calculate_perplexity


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Evaluate Yadabo Transformer model",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Model
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to model checkpoint",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        default=None,
        help="Path to tokenizer file",
    )

    # Data
    parser.add_argument(
        "--data",
        type=str,
        required=True,
        help="Path to evaluation data",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=16,
        help="Batch size for evaluation",
    )
    parser.add_argument(
        "--max_length",
        type=int,
        default=512,
        help="Maximum sequence length",
    )

    # Output
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output file for results",
    )
    parser.add_argument(
        "--save_predictions",
        type=str,
        default=None,
        help="Save predictions to file",
    )

    # System
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        help="Device to use",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show verbose output",
    )

    return parser.parse_args()


def evaluate(
    model,
    dataloader,
    device,
    tokenizer,
    save_predictions: str = None,
):
    """
    Evaluate model on dataset.

    Args:
        model: Model to evaluate
        dataloader: Evaluation data loader
        device: Device to use
        tokenizer: Tokenizer for decoding
        save_predictions: Path to save predictions

    Returns:
        Dictionary of metrics
    """
    model.eval()

    total_loss = 0.0
    total_tokens = 0
    total_correct = 0
    predictions = []

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Evaluating"):
            # Move to device
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            # Forward pass
            logits = model(input_ids, attention_mask=attention_mask)

            # Calculate loss (next-token prediction)
            # Shift for language modeling
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = input_ids[..., 1:].contiguous()

            # Calculate cross-entropy loss
            loss = torch.nn.functional.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                reduction='sum',
            )

            total_loss += loss.item()

            # Calculate accuracy
            predictions_batch = shift_logits.argmax(dim=-1)
            mask = shift_labels != tokenizer.special_tokens.get('<pad>', 0)
            correct = (predictions_batch == shift_labels) & mask
            total_correct += correct.sum().item()
            total_tokens += mask.sum().item()

            # Save some predictions
            if save_predictions and len(predictions) < 100:
                for i in range(min(len(input_ids), 3)):
                    pred_tokens = predictions_batch[i].cpu().tolist()
                    true_tokens = shift_labels[i].cpu().tolist()

                    predictions.append({
                        "prompt": tokenizer.decode(true_tokens[:20], skip_special_tokens=True),
                        "predicted": tokenizer.decode(pred_tokens[:20], skip_special_tokens=True),
                        "correct": correct[i].sum().item(),
                        "total": mask[i].sum().item(),
                    })

    # Calculate metrics
    avg_loss = total_loss / total_tokens
    perplexity = calculate_perplexity(avg_loss)
    accuracy = total_correct / total_tokens if total_tokens > 0 else 0

    metrics = {
        "loss": avg_loss,
        "perplexity": perplexity,
        "accuracy": accuracy,
        "num_tokens": total_tokens,
    }

    # Save predictions
    if save_predictions:
        import json
        with open(save_predictions, 'w', encoding='utf-8') as f:
            json.dump(predictions, f, indent=2, ensure_ascii=False)
        logging.info(f"Predictions saved to {save_predictions}")

    return metrics


def main():
    """Main evaluation function."""
    args = parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logger("yadabo_eval", level=log_level)

    # Get device
    if args.device == "auto":
        device = get_device()
    else:
        device = torch.device(args.device)

    logging.info(f"Using device: {device}")

    # Load checkpoint
    checkpoint_path = args.checkpoint
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    logging.info(f"Loading checkpoint from {checkpoint_path}")
    model, metadata = TransformerLM.load(checkpoint_path, device=str(device))
    model.eval()

    # Load tokenizer
    if args.tokenizer:
        from data import BPETokenizer
        tokenizer = BPETokenizer.load(args.tokenizer)
    elif "tokenizer_path" in metadata:
        from data import BPETokenizer
        tokenizer = BPETokenizer.load(metadata["tokenizer_path"])
    else:
        raise ValueError("Tokenizer not found. Please specify --tokenizer")

    # Create dataset
    dataset = TextDataset(
        file_path=args.data,
        tokenizer=tokenizer,
        max_length=args.max_length,
        stride=args.max_length,  # Non-overlapping for evaluation
    )

    logging.info(f"Dataset size: {len(dataset)} examples")

    # Create dataloader
    collator = DataCollator(tokenizer=tokenizer)
    dataloader = create_dataloader(
        dataset=dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=2,
        collate_fn=collator,
    )

    # Evaluate
    logging.info("Starting evaluation...")
    metrics = evaluate(
        model=model,
        dataloader=dataloader,
        device=device,
        tokenizer=tokenizer,
        save_predictions=args.save_predictions,
    )

    # Print results
    print("\n" + "=" * 60)
    print("Evaluation Results")
    print("=" * 60)
    print(f"Loss:           {metrics['loss']:.4f}")
    print(f"Perplexity:     {metrics['perplexity']:.2f}")
    print(f"Accuracy:       {metrics['accuracy']:.4f}")
    print(f"Total Tokens:   {metrics['num_tokens']:,}")
    print("=" * 60)

    # Save results
    if args.output:
        import json
        with open(args.output, 'w') as f:
            json.dump(metrics, f, indent=2)
        logging.info(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
