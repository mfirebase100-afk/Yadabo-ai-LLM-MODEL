#!/usr/bin/env python3
"""
Yadabo AI - Training Script

Main training script for Yadabo Transformer model.
Supports single GPU, multi-GPU, and distributed training.

Usage:
    # Single GPU
    python scripts/train.py --config config/default.yaml

    # Multi-GPU with torchrun
    torchrun --nproc_per_node=4 scripts/train.py --config config/default.yaml

    # With custom settings
    python scripts/train.py --data_path data/train.txt --epochs 10 --batch_size 32
"""

import os
import sys
import argparse
import logging
from pathlib import Path

import torch

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from model import TransformerLM, TransformerConfig
from data import TextDataset, DataCollator, create_dataloader, create_train_val_split
from training import Trainer, TrainerConfig, create_optimizer, create_scheduler
from utils import setup_logger, set_seed, get_device, log_model_info, log_system_info


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Train Yadabo Transformer model",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Configuration files
    parser.add_argument(
        "--config",
        type=str,
        default="config/default.yaml",
        help="Path to configuration file",
    )
    parser.add_argument(
        "--model_config",
        type=str,
        default=None,
        help="Path to model configuration file",
    )

    # Data
    parser.add_argument(
        "--data_path",
        type=str,
        default="data/train.txt",
        help="Path to training data file or directory",
    )
    parser.add_argument(
        "--val_data_path",
        type=str,
        default=None,
        help="Path to validation data file",
    )
    parser.add_argument(
        "--tokenizer_path",
        type=str,
        default=None,
        help="Path to tokenizer file",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./output",
        help="Output directory for checkpoints",
    )

    # Training parameters
    parser.add_argument(
        "--epochs",
        type=int,
        default=None,
        help="Number of training epochs (overrides config)",
    )
    parser.add_argument(
        "--max_steps",
        type=int,
        default=None,
        help="Maximum training steps (overrides config)",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=None,
        help="Batch size per device (overrides config)",
    )
    parser.add_argument(
        "--learning_rate",
        type=float,
        default=None,
        help="Learning rate (overrides config)",
    )
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=None,
        help="Gradient accumulation steps (overrides config)",
    )

    # Model parameters
    parser.add_argument(
        "--vocab_size",
        type=int,
        default=None,
        help="Vocabulary size (overrides config)",
    )
    parser.add_argument(
        "--max_seq_len",
        type=int,
        default=None,
        help="Maximum sequence length (overrides config)",
    )
    parser.add_argument(
        "--d_model",
        type=int,
        default=None,
        help="Model dimension (overrides config)",
    )
    parser.add_argument(
        "--n_layers",
        type=int,
        default=None,
        help="Number of transformer layers (overrides config)",
    )
    parser.add_argument(
        "--n_heads",
        type=int,
        default=None,
        help="Number of attention heads (overrides config)",
    )

    # Optimization
    parser.add_argument(
        "--optimizer",
        type=str,
        default=None,
        choices=["adamw", "adam", "lion", "sophia", "lamb"],
        help="Optimizer type (overrides config)",
    )
    parser.add_argument(
        "--scheduler",
        type=str,
        default=None,
        choices=["cosine", "linear", "polynomial", "constant"],
        help="Learning rate scheduler (overrides config)",
    )
    parser.add_argument(
        "--weight_decay",
        type=float,
        default=None,
        help="Weight decay coefficient (overrides config)",
    )
    parser.add_argument(
        "--warmup_steps",
        type=int,
        default=None,
        help="Warmup steps (overrides config)",
    )
    parser.add_argument(
        "--max_grad_norm",
        type=float,
        default=None,
        help="Maximum gradient norm for clipping (overrides config)",
    )

    # System
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )
    parser.add_argument(
        "--local_rank",
        type=int,
        default=-1,
        help="Local rank for distributed training",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cuda", "cpu", "mps"],
        help="Device to use for training",
    )
    parser.add_argument(
        "--resume",
        type=str,
        default=None,
        help="Resume from checkpoint path",
    )
    parser.add_argument(
        "--gradient_checkpointing",
        action="store_true",
        help="Enable gradient checkpointing for memory efficiency",
    )
    parser.add_argument(
        "--log_steps",
        type=int,
        default=10,
        help="Log every N steps",
    )
    parser.add_argument(
        "--save_steps",
        type=int,
        default=1000,
        help="Save checkpoint every N steps",
    )
    parser.add_argument(
        "--eval_steps",
        type=int,
        default=1000,
        help="Evaluate every N steps",
    )

    return parser.parse_args()


def load_config(config_path: str) -> dict:
    """Load configuration from YAML file."""
    import yaml

    if not os.path.exists(config_path):
        logging.warning(f"Config file not found: {config_path}")
        return {}

    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    return config or {}


def merge_configs(base_config: dict, args: argparse.Namespace) -> dict:
    """Merge base config with command line arguments."""
    # Start with model config
    model_config = base_config.get("model", {})

    # Override with args
    if args.vocab_size is not None:
        model_config["vocab_size"] = args.vocab_size
    if args.max_seq_len is not None:
        model_config["max_seq_len"] = args.max_seq_len
    if args.d_model is not None:
        model_config["d_model"] = args.d_model
    if args.n_layers is not None:
        model_config["n_layers"] = args.n_layers
    if args.n_heads is not None:
        model_config["n_heads"] = args.n_heads

    # Training config
    train_config = base_config.get("training", {})

    if args.batch_size is not None:
        train_config["batch_size"] = args.batch_size
    if args.learning_rate is not None:
        train_config["learning_rate"] = args.learning_rate
    if args.max_steps is not None:
        train_config["max_steps"] = args.max_steps
    if args.epochs is not None:
        train_config["num_epochs"] = args.epochs
    if args.gradient_accumulation_steps is not None:
        train_config["gradient_accumulation_steps"] = args.gradient_accumulation_steps
    if args.optimizer is not None:
        train_config["optimizer_type"] = args.optimizer
    if args.scheduler is not None:
        train_config["scheduler_type"] = args.scheduler
    if args.weight_decay is not None:
        train_config["weight_decay"] = args.weight_decay
    if args.warmup_steps is not None:
        train_config["warmup_steps"] = args.warmup_steps
    if args.max_grad_norm is not None:
        train_config["max_grad_norm"] = args.max_grad_norm

    # General config
    if args.data_path is not None:
        base_config["data_path"] = args.data_path
    if args.output_dir is not None:
        base_config["output_dir"] = args.output_dir

    base_config["model"] = model_config
    base_config["training"] = train_config

    return base_config


def create_tokenizer(tokenizer_path: str, vocab_size: int):
    """Create or load tokenizer."""
    from data import BPETokenizer, TokenizerConfig

    if tokenizer_path and os.path.exists(tokenizer_path):
        tokenizer = BPETokenizer.load(tokenizer_path)
        logging.info(f"Loaded tokenizer from {tokenizer_path}")
    else:
        # Create a basic tokenizer
        config = TokenizerConfig(vocab_size=vocab_size)
        tokenizer = BPETokenizer(config)
        logging.info("Created new tokenizer")

    return tokenizer


def create_model(config: TransformerConfig):
    """Create and initialize model."""
    model = TransformerLM(config)
    return model


def main():
    """Main training function."""
    args = parse_args()

    # Setup logging
    logger = setup_logger(
        "yadabo",
        log_dir=args.output_dir,
        level=logging.INFO,
    )

    # Set seed
    set_seed(args.seed, deterministic=True)

    # Get device
    if args.device == "auto":
        device = get_device()
    else:
        device = torch.device(args.device)

    # Log system info
    if args.local_rank <= 0:
        log_system_info(logger)

    # Load configuration
    config = load_config(args.config)
    config = merge_configs(config, args)

    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)

    # Log configuration
    logger.info("=" * 60)
    logger.info("Training Configuration")
    logger.info("=" * 60)
    for key, value in config.items():
        if isinstance(value, dict):
            logger.info(f"{key}:")
            for k, v in value.items():
                logger.info(f"  {k}: {v}")
        else:
            logger.info(f"{key}: {value}")
    logger.info("=" * 60)

    # Create tokenizer
    vocab_size = config.get("model", {}).get("vocab_size", 32000)
    tokenizer_path = getattr(args, "tokenizer_path", None) or config.get("tokenizer_path")
    tokenizer = create_tokenizer(tokenizer_path, vocab_size)

    # Create model configuration
    model_config = TransformerConfig.from_dict(config.get("model", {}))
    if args.gradient_checkpointing:
        model_config.gradient_checkpointing = True

    # Create model
    logger.info("Creating model...")
    model = create_model(model_config)

    if args.local_rank <= 0:
        log_model_info(model, logger)

    # Create datasets
    data_path = config.get("data_path", args.data_path)
    max_seq_len = config.get("model", {}).get("max_seq_len", 512)
    stride = config.get("data", {}).get("stride", 128)

    logger.info(f"Loading training data from {data_path}")

    # Create training dataset
    train_dataset = TextDataset(
        file_path=data_path,
        tokenizer=tokenizer,
        max_length=max_seq_len,
        stride=stride,
    )

    logger.info(f"Training dataset size: {len(train_dataset)}")

    # Create validation dataset if provided
    val_dataset = None
    val_data_path = args.val_data_path or config.get("val_data_path")
    if val_data_path:
        val_dataset = TextDataset(
            file_path=val_data_path,
            tokenizer=tokenizer,
            max_length=max_seq_len,
            stride=stride,
        )
        logger.info(f"Validation dataset size: {len(val_dataset)}")

    # Create data loaders
    batch_size = config.get("training", {}).get("batch_size", 8)
    num_workers = config.get("training", {}).get("num_workers", 4)

    collator = DataCollator(tokenizer=tokenizer)

    train_loader = create_dataloader(
        dataset=train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        collate_fn=collator,
    )

    val_loader = None
    if val_dataset:
        val_loader = create_dataloader(
            dataset=val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            collate_fn=collator,
        )

    # Create trainer config
    train_config = config.get("training", {})
    trainer_config = TrainerConfig(
        output_dir=args.output_dir,
        max_steps=train_config.get("max_steps", 100000),
        num_epochs=train_config.get("num_epochs"),
        gradient_accumulation_steps=train_config.get("gradient_accumulation_steps", 1),
        max_grad_norm=train_config.get("max_grad_norm", 1.0),
        learning_rate=train_config.get("learning_rate", 1e-4),
        weight_decay=train_config.get("weight_decay", 0.01),
        optimizer_type=train_config.get("optimizer_type", "adamw"),
        scheduler_type=train_config.get("scheduler_type", "cosine"),
        warmup_steps=train_config.get("warmup_steps", 1000),
        log_steps=args.log_steps,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        local_rank=args.local_rank,
        resume_from_checkpoint=args.resume,
        gradient_checkpointing=args.gradient_checkpointing,
    )

    # Create trainer
    logger.info("Creating trainer...")
    trainer = Trainer(
        model=model,
        config=trainer_config,
        train_dataloader=train_loader,
        eval_dataloader=val_loader,
    )

    # Train
    logger.info("Starting training...")
    trainer.train()

    logger.info("Training completed!")


if __name__ == "__main__":
    main()
