#!/usr/bin/env python3
"""
Yadabo AI - Text Generation Script

Generate text using a trained Yadabo Transformer model.
Supports various decoding strategies including greedy, sampling, and beam search.

Usage:
    # Basic generation
    python scripts/generate.py --checkpoint output/checkpoint_best.pt --prompt "def hello_world():"

    # With sampling parameters
    python scripts/generate.py --checkpoint output/checkpoint_best.pt \
        --prompt "The answer is" --temperature 0.8 --top_p 0.9

    # Interactive mode
    python scripts/generate.py --checkpoint output/checkpoint_best.pt --interactive

    # Batch generation
    python scripts/generate.py --checkpoint output/checkpoint_best.pt \
        --prompt_file prompts.txt --output results.txt
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Optional, List

import torch

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from model import TransformerLM, TransformerConfig
from data import BPETokenizer
from utils import setup_logger, get_device, set_seed


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Generate text with Yadabo Transformer",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Model and tokenizer
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to model checkpoint",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        default=None,
        help="Path to tokenizer file",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to model config file",
    )

    # Input
    parser.add_argument(
        "--prompt",
        type=str,
        default=None,
        help="Prompt text for generation",
    )
    parser.add_argument(
        "--prompt_file",
        type=str,
        default=None,
        help="File containing prompts (one per line)",
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Run in interactive mode",
    )

    # Output
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output file for generated text",
    )
    parser.add_argument(
        "--save_probs",
        type=str,
        default=None,
        help="Save token probabilities to file",
    )

    # Generation parameters
    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=100,
        help="Maximum number of tokens to generate",
    )
    parser.add_argument(
        "--max_length",
        type=int,
        default=512,
        help="Maximum total sequence length",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Sampling temperature (higher = more random)",
    )
    parser.add_argument(
        "--top_k",
        type=int,
        default=None,
        help="Top-k sampling (None to disable)",
    )
    parser.add_argument(
        "--top_p",
        type=float,
        default=None,
        help="Nucleus sampling threshold (None to disable)",
    )
    parser.add_argument(
        "--repetition_penalty",
        type=float,
        default=1.0,
        help="Repetition penalty (1.0 to disable)",
    )
    parser.add_argument(
        "--num_beams",
        type=int,
        default=1,
        help="Number of beams for beam search (1 for sampling)",
    )
    parser.add_argument(
        "--length_penalty",
        type=float,
        default=1.0,
        help="Length penalty for beam search",
    )
    parser.add_argument(
        "--noRepeatNgramSize",
        type=int,
        default=0,
        help="N-gram size to prevent repetition (0 to disable)",
    )

    # System
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cuda", "cpu"],
        help="Device to use",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    parser.add_argument(
        "--dtype",
        type=str,
        default="float32",
        choices=["float32", "float16", "bfloat16"],
        help="Data type for inference",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show verbose output",
    )

    return parser.parse_args()


def load_model_and_tokenizer(args):
    """Load model and tokenizer from checkpoint."""
    # Get device
    if args.device == "auto":
        device = get_device()
    else:
        device = torch.device(args.device)

    # Load checkpoint
    checkpoint_path = args.checkpoint
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    logging.info(f"Loading checkpoint from {checkpoint_path}")

    # Load model
    model, metadata = TransformerLM.load(checkpoint_path, device=str(device))

    # Set to eval mode
    model.eval()

    # Convert dtype
    if args.dtype == "float16":
        model = model.half()
    elif args.dtype == "bfloat16":
        model = model.bfloat16()

    # Load tokenizer
    if args.tokenizer:
        tokenizer = BPETokenizer.load(args.tokenizer)
    elif "tokenizer_path" in metadata:
        tokenizer = BPETokenizer.load(metadata["tokenizer_path"])
    else:
        # Try to find tokenizer in checkpoint directory
        tokenizer_path = os.path.join(
            os.path.dirname(checkpoint_path),
            "tokenizer.json"
        )
        if os.path.exists(tokenizer_path):
            tokenizer = BPETokenizer.load(tokenizer_path)
        else:
            raise ValueError("Tokenizer not found. Please specify --tokenizer")

    logging.info(f"Model loaded on {device}")
    logging.info(f"Model size: {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M parameters")

    return model, tokenizer, device


def generate_single(
    model,
    tokenizer,
    prompt: str,
    device,
    args,
) -> str:
    """Generate text for a single prompt."""
    # Tokenize prompt
    input_ids = tokenizer.encode(
        prompt,
        add_special_tokens=True,
        max_length=args.max_length - args.max_new_tokens,
        truncation=True,
    )

    input_tensor = torch.tensor([input_ids], device=device)

    # Generate
    with torch.no_grad():
        if args.num_beams > 1:
            # Beam search
            output_ids = model.beam_search(
                input_tensor,
                max_new_tokens=args.max_new_tokens,
                beam_size=args.num_beams,
                length_penalty=args.length_penalty,
            )[0]
        else:
            # Sampling
            output_ids = model.generate(
                input_tensor,
                max_new_tokens=args.max_new_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                repetition_penalty=args.repetition_penalty,
            )[0]

    # Decode
    generated_text = tokenizer.decode(
        output_ids[len(input_ids):].tolist(),
        skip_special_tokens=True,
    )

    return generated_text


def generate_batch(
    model,
    tokenizer,
    prompts: List[str],
    device,
    args,
) -> List[str]:
    """Generate text for multiple prompts."""
    results = []

    for prompt in prompts:
        try:
            generated = generate_single(model, tokenizer, prompt, device, args)
            results.append(generated)
        except Exception as e:
            logging.error(f"Error generating for prompt '{prompt[:50]}...': {e}")
            results.append("")

    return results


def interactive_mode(model, tokenizer, device, args):
    """Run interactive generation loop."""
    print("\n" + "=" * 60)
    print("Yadabo AI - Interactive Mode")
    print("Type 'exit' or 'quit' to end the session")
    print("Type 'reset' to clear conversation history")
    print("=" * 60 + "\n")

    conversation = []

    while True:
        try:
            prompt = input("You: ").strip()

            if prompt.lower() in ["exit", "quit", "q"]:
                print("Goodbye!")
                break

            if prompt.lower() == "reset":
                conversation = []
                print("Conversation history cleared.\n")
                continue

            if not prompt:
                continue

            # Add to conversation
            conversation.append(prompt)

            # Generate
            full_prompt = "\n".join(conversation)
            generated = generate_single(model, tokenizer, full_prompt, device, args)

            print(f"Yadabo: {generated}\n")

            # Add to conversation
            conversation.append(generated)

        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"Error: {e}\n")


def main():
    """Main generation function."""
    args = parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logger("yadabo", level=log_level)

    # Set seed
    set_seed(args.seed)

    # Load model and tokenizer
    model, tokenizer, device = load_model_and_tokenizer(args)

    # Handle input
    if args.interactive:
        interactive_mode(model, tokenizer, device, args)
        return

    if args.prompt_file:
        # Batch generation from file
        with open(args.prompt_file, 'r', encoding='utf-8') as f:
            prompts = [line.strip() for line in f if line.strip()]

        logger.info(f"Generating for {len(prompts)} prompts...")

        results = generate_batch(model, tokenizer, prompts, device, args)

        # Output
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                for prompt, generated in zip(prompts, results):
                    f.write(f"Prompt: {prompt}\n")
                    f.write(f"Generated: {generated}\n")
                    f.write("-" * 60 + "\n")
            logger.info(f"Results saved to {args.output}")
        else:
            for prompt, generated in zip(prompts, results):
                print(f"Prompt: {prompt}")
                print(f"Generated: {generated}")
                print("-" * 60)

    elif args.prompt:
        # Single prompt
        logger.info(f"Prompt: {args.prompt}")
        generated = generate_single(model, tokenizer, args.prompt, device, args)

        print(f"\n{'=' * 60}")
        print("Generated Text:")
        print("=" * 60)
        print(generated)
        print("=" * 60)

        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(f"Prompt: {args.prompt}\n\n")
                f.write(f"Generated: {generated}\n")
            logger.info(f"Result saved to {args.output}")

    else:
        print("No prompt provided. Use --prompt, --prompt_file, or --interactive")
        print("Run with --help for more options")


if __name__ == "__main__":
    main()
