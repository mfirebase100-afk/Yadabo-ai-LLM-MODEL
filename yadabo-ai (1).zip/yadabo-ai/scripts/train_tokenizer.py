#!/usr/bin/env python3
"""
Yadabo AI - Tokenizer Training Script

Train a BPE tokenizer on a corpus.
Supports Arabic and English text, as well as programming code.

Usage:
    # Train with default settings
    python scripts/train_tokenizer.py --data data/train.txt --output data/tokenizer.json

    # Train with custom vocabulary size
    python scripts/train_tokenizer.py --data data/train.txt \
        --vocab_size 50000 --min_frequency 3
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import List

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from data import BPETokenizer, TokenizerConfig
from utils import setup_logger


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Train BPE Tokenizer for Yadabo AI",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Data
    parser.add_argument(
        "--data",
        type=str,
        required=True,
        help="Path to training data file or directory",
    )
    parser.add_argument(
        "--output",
        type=str,
        required=True,
        help="Output path for tokenizer",
    )
    parser.add_argument(
        "--file_extension",
        type=str,
        default=".txt",
        help="Extension of text files in directory",
    )

    # Tokenizer settings
    parser.add_argument(
        "--vocab_size",
        type=int,
        default=32000,
        help="Target vocabulary size",
    )
    parser.add_argument(
        "--min_frequency",
        type=int,
        default=2,
        help="Minimum frequency for a token to be kept",
    )
    parser.add_argument(
        "--byte_fallback",
        action="store_true",
        default=True,
        help="Enable byte-level fallback for unknown characters",
    )

    # Special tokens
    parser.add_argument(
        "--num_special_tokens",
        type=int,
        default=5,
        help="Number of special tokens to reserve",
    )

    # Other
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show verbose output",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )

    return parser.parse_args()


def load_corpus(data_path: str, extension: str = ".txt") -> List[str]:
    """
    Load text corpus from file or directory.

    Args:
        data_path: Path to file or directory
        extension: File extension to filter (for directories)

    Returns:
        List of text strings
    """
    corpus = []

    if os.path.isfile(data_path):
        # Single file
        logging.info(f"Loading corpus from {data_path}")
        with open(data_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line:
                    corpus.append(line)
        logging.info(f"Loaded {len(corpus)} lines")

    elif os.path.isdir(data_path):
        # Directory
        logging.info(f"Loading corpus from directory {data_path}")

        for root, _, files in os.walk(data_path):
            for filename in files:
                if filename.endswith(extension):
                    filepath = os.path.join(root, filename)
                    logging.info(f"Loading {filepath}")

                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        for line in f:
                            line = line.strip()
                            if line:
                                corpus.append(line)

        logging.info(f"Loaded {len(corpus)} lines from {data_path}")

    else:
        raise FileNotFoundError(f"Data path not found: {data_path}")

    return corpus


def create_tokenizer_config(args) -> TokenizerConfig:
    """Create tokenizer configuration."""
    # Standard special tokens
    special_tokens = {
        "<pad>": 0,
        "<bos>": 1,
        "<eos>": 2,
        "<unk>": 3,
        "<mask>": 4,
    }

    # Add code-specific tokens if needed
    code_tokens = {
        "<code>": len(special_tokens),
        "</code>": len(special_tokens) + 1,
        "<math>": len(special_tokens) + 2,
        "</math>": len(special_tokens) + 3,
    }
    special_tokens.update(code_tokens)

    return TokenizerConfig(
        vocab_size=args.vocab_size,
        min_frequency=args.min_frequency,
        special_tokens=special_tokens,
        byte_fallback=args.byte_fallback,
    )


def main():
    """Main tokenizer training function."""
    args = parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logger("yadabo_tokenizer", level=log_level)

    # Set seed
    import random
    random.seed(args.seed)

    # Load corpus
    corpus = load_corpus(args.data, args.file_extension)

    if not corpus:
        logging.error("No text loaded from corpus!")
        return

    # Create tokenizer
    config = create_tokenizer_config(args)
    tokenizer = BPETokenizer(config)

    # Train tokenizer
    logger.info("=" * 60)
    logger.info("Training BPE Tokenizer")
    logger.info("=" * 60)
    logger.info(f"Corpus size: {len(corpus)} lines")
    logger.info(f"Target vocab size: {args.vocab_size}")
    logger.info(f"Min frequency: {args.min_frequency}")

    import time
    start_time = time.time()

    tokenizer.train(
        corpus=corpus,
        vocab_size=args.vocab_size,
        min_frequency=args.min_frequency,
        show_progress=True,
    )

    training_time = time.time() - start_time

    # Save tokenizer
    os.makedirs(os.path.dirname(args.output) or '.', exist_ok=True)
    tokenizer.save(args.output)

    logger.info("=" * 60)
    logger.info("Tokenizer Training Complete")
    logger.info("=" * 60)
    logger.info(f"Final vocabulary size: {len(tokenizer)}")
    logger.info(f"Number of merges: {len(tokenizer.merges)}")
    logger.info(f"Training time: {training_time:.2f}s")
    logger.info(f"Tokenizer saved to: {args.output}")

    # Print some stats
    logger.info("\nSample tokens from vocabulary:")
    for i, (token, idx) in enumerate(list(tokenizer.token_to_id.items())[:20]):
        logger.info(f"  {idx}: {repr(token)}")

    if len(tokenizer.token_to_id) > 20:
        logger.info("  ...")


if __name__ == "__main__":
    main()
