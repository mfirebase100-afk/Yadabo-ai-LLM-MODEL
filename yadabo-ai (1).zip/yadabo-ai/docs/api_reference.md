# Yadabo AI - API Reference

Complete API reference for Yadabo AI.

## Model

### TransformerLM

Main transformer language model class.

```python
from model import TransformerLM, TransformerConfig

# Create configuration
config = TransformerConfig(
    vocab_size=32000,
    d_model=512,
    n_heads=8,
    n_layers=6,
    d_ff=2048,
)

# Create model
model = TransformerLM(config)

# Forward pass
input_ids = torch.randint(0, 32000, (2, 100))  # (batch, seq)
logits = model(input_ids)  # (batch, seq, vocab_size)
```

#### Methods

##### `forward(input_ids, attention_mask=None, labels=None)`

Forward pass through the model.

**Parameters:**
- `input_ids` (torch.Tensor): Input token IDs, shape (batch_size, seq_len)
- `attention_mask` (torch.Tensor, optional): Attention mask
- `labels` (torch.Tensor, optional): Labels for loss computation

**Returns:**
- If `labels` provided: Tuple of (loss, logits)
- Otherwise: Logits tensor

##### `generate(input_ids, **kwargs)`

Generate text autoregressively.

**Parameters:**
- `input_ids` (torch.Tensor): Starting token IDs
- `max_new_tokens` (int): Maximum tokens to generate
- `temperature` (float): Sampling temperature
- `top_k` (int, optional): Top-k sampling
- `top_p` (float, optional): Nucleus sampling
- `repetition_penalty` (float): Repetition penalty

**Returns:**
- Generated token IDs

##### `beam_search(input_ids, max_new_tokens, beam_size=5)`

Beam search generation.

##### `save(path)` / `load(path)`

Save and load model checkpoints.

---

### TransformerConfig

Configuration dataclass for the model.

```python
config = TransformerConfig(
    vocab_size=32000,
    max_seq_len=512,
    d_model=512,
    n_heads=8,
    n_layers=6,
    d_ff=2048,
    dropout=0.1,
    activation="gelu",
)
```

**Presets:**

```python
TransformerConfig.small_arabic_english()   # ~8M params
TransformerConfig.medium_arabic_english()    # ~40M params
TransformerConfig.large_arabic_english()    # ~125M params
TransformerConfig.xlarge_arabic_english()   # ~350M params
```

---

## Data

### BPETokenizer

Custom BPE tokenizer for Arabic and English.

```python
from data import BPETokenizer

# Load trained tokenizer
tokenizer = BPETokenizer.load("tokenizer.json")

# Encode
input_ids = tokenizer.encode("Hello, world!")
tokens = tokenizer.tokenize("Hello, world!")

# Decode
text = tokenizer.decode(input_ids)
```

#### Methods

##### `encode(text, add_special_tokens=True, max_length=None)`

Encode text to token IDs.

##### `decode(token_ids, skip_special_tokens=True)`

Decode token IDs to text.

##### `train(corpus, vocab_size, min_frequency)`

Train tokenizer on corpus.

##### `batch_encode()` / `batch_decode()`

Batch operations.

---

### TextDataset

Dataset for loading text data.

```python
from data import TextDataset, DataCollator, create_dataloader

dataset = TextDataset(
    file_path="train.txt",
    tokenizer=tokenizer,
    max_length=512,
    stride=128,
)

collator = DataCollator(tokenizer=tokenizer)
dataloader = create_dataloader(
    dataset=dataset,
    batch_size=32,
    shuffle=True,
    collate_fn=collator,
)
```

---

## Training

### Trainer

Main training class.

```python
from training import Trainer, TrainerConfig

config = TrainerConfig(
    output_dir="./output",
    max_steps=100000,
    learning_rate=1e-4,
    batch_size=32,
)

trainer = Trainer(
    model=model,
    config=config,
    train_dataloader=train_loader,
    eval_dataloader=val_loader,
)

trainer.train()
```

### Optimizer

```python
from training import create_optimizer

optimizer = create_optimizer(
    model,
    optimizer_type="adamw",
    learning_rate=1e-4,
    weight_decay=0.01,
)
```

**Supported optimizers:**
- `adamw` - Adam with weight decay
- `adam` - Standard Adam
- `lion` - Lion optimizer
- `sophia` - Sophia optimizer
- `lamb` - LAMB optimizer

### Scheduler

```python
from training import create_scheduler

scheduler = create_scheduler(
    optimizer,
    scheduler_type="cosine",
    num_warmup_steps=1000,
    num_training_steps=100000,
    min_lr=0.0,
)
```

**Supported schedulers:**
- `cosine` - Cosine annealing with warmup
- `linear` - Linear decay with warmup
- `polynomial` - Polynomial decay
- `constant` - Constant with warmup

---

## Utils

### Logging

```python
from utils import setup_logger

logger = setup_logger(
    name="yadabo",
    log_dir="./logs",
    level=logging.INFO,
)
```

### Device

```python
from utils import get_device, set_seed

device = get_device("auto")  # auto, cuda, cpu, mps
set_seed(42)
```

### Model Utils

```python
from utils import count_parameters, freeze_layers

total, trainable = count_parameters(model)
freeze_layers(model, freeze_embeddings=True)
```

### Checkpoint Utils

```python
from utils import save_checkpoint, load_checkpoint, get_latest_checkpoint

save_checkpoint(model, optimizer, step=1000, ...)
checkpoint = get_latest_checkpoint("./output")
```

---

## Scripts

### Training

```bash
python scripts/train.py \
    --config config/default.yaml \
    --data_path data/train.txt \
    --output_dir ./output
```

### Generation

```bash
python scripts/generate.py \
    --checkpoint output/best.pt \
    --prompt "def hello_world():" \
    --max_new_tokens 100
```

### Tokenizer Training

```bash
python scripts/train_tokenizer.py \
    --data data/train.txt \
    --output data/tokenizer.json \
    --vocab_size 32000
```

### Evaluation

```bash
python scripts/evaluate.py \
    --checkpoint output/best.pt \
    --data data/test.txt \
    --tokenizer data/tokenizer.json
```
