# Yadabo AI - Google Cloud Setup Guide

This guide explains how to set up Yadabo AI for training on Google Cloud Platform (GCP) with GPU support.

## Prerequisites

1. Google Cloud account with billing enabled
2. gcloud CLI installed and configured
3. Project with sufficient quota for GPU instances

## Quick Start with Cloud GPU

### 1. Create a GPU Instance

```bash
# Set your project
gcloud config set project YOUR_PROJECT_ID

# Create A100 instance
gcloud compute instances create yadabo-training \
    --zone=us-central1-a \
    --machine-type=a2-highgpu-1g \
    --accelerator=type=nvidia-tesla-a100,count=1 \
    --image-family=pytorch-latest \
    --image-project=deeplearning-platform-release \
    --boot-disk-size=200GB \
    --boot-disk-type=pd-ssd \
    --scopes=storage-full
```

### 2. Connect to Instance

```bash
gcloud compute ssh yadabo-training --zone=us-central1-a
```

### 3. Install Yadabo AI

```bash
# Clone repository
git clone https://github.com/yadabo/yadabo-ai.git
cd yadabo-ai

# Install dependencies
pip install -e .

# Verify PyTorch with CUDA
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
```

## Data Setup on GCP

### Option 1: Cloud Storage Bucket

```bash
# Create bucket
gsutil mb -l us-central1 gs://YOUR_BUCKET_NAME

# Upload training data
gsutil cp -r data/* gs://YOUR_BUCKET_NAME/data/

# Update config to use GCS paths
# Or use symbolic links
ln -sf /path/to/gcs/data ./data
```

### Option 2: Local Storage with Cloud Sync

```bash
# Sync data periodically
gsutil rsync -r gs://YOUR_BUCKET_NAME/data ./data
```

## Multi-GPU Training

### Create Multi-GPU Instance

```bash
# Create instance with 4 A100s
gcloud compute instances create yadabo-training-4x \
    --zone=us-central1-a \
    --machine-type=a2-highgpu-4g \
    --accelerator=type=nvidia-tesla-a100,count=4 \
    --image-family=pytorch-latest \
    --image-project=deeplearning-platform-release \
    --boot-disk-size=500GB \
    --boot-disk-type=pd-ssd
```

### Launch Distributed Training

```bash
# Using torchrun for distributed training
torchrun \
    --nproc_per_node=4 \
    --nnodes=1 \
    --rdzv_id=123 \
    --rdzv_endpoint="localhost:29500" \
    scripts/train.py \
    --config config/production.yaml \
    --output_dir gs://YOUR_BUCKET_NAME/output
```

## Scaling Training

### Horizontal Scaling (Multiple Nodes)

```bash
# Node 0 (master)
torchrun \
    --nproc_per_node=4 \
    --nnodes=2 \
    --node_rank=0 \
    --rdzv_id=123 \
    --rdzv_endpoint="node0:29500" \
    scripts/train.py \
    --config config/production.yaml

# Node 1 (worker)
torchrun \
    --nproc_per_node=4 \
    --nnodes=2 \
    --node_rank=1 \
    --rdzv_id=123 \
    --rdzv_endpoint="node0:29500" \
    scripts/train.py \
    --config config/production.yaml
```

### Checkpoint Management

```python
# In your training script, use GCS paths
checkpoint_path = "gs://YOUR_BUCKET_NAME/checkpoints/step_1000.pt"

# With tensorboard
tensorboard --logdir=gs://YOUR_BUCKET_NAME/logs
```

## Monitoring

### View GPU Utilization

```bash
# SSH into instance
nvidia-smi -l 1
```

### Cloud Logging

```bash
# View logs
gcloud logging read "resource.type=gce_instance" --limit=100

# Filter by training
gcloud logging read "resource.type=gce_instance AND logName:yadabo" --limit=100
```

## Cost Optimization

### Spot Instances (Preemptible)

```bash
# Create spot instance (80% cheaper)
gcloud compute instances create yadabo-spot \
    --zone=us-central1-a \
    --machine-type=a2-highgpu-1g \
    --accelerator=type=nvidia-tesla-a100,count=1 \
    --image-family=pytorch-latest \
    --image-project=deeplearning-platform-release \
    --provisioning-model=SPOT \
    --spot-instance-traits=preemptible
```

### Auto-Shutdown

```bash
# Create startup script to auto-shutdown after training
echo "#!/bin/bash
echo '0 6 * * * shutdown -h' | crontab -
" > startup.sh
```

## Troubleshooting

### CUDA Out of Memory

```bash
# Reduce batch size
python scripts/train.py --batch_size 16 --gradient_checkpointing

# Clear cache
nvidia-smi --gpu-reset
```

### Slow Training

```bash
# Check NCCL
python -c "import torch; torch.distributed.is_nccl_available()"

# Use mixed precision
python scripts/train.py --fp16
```

## Next Steps

1. Upload your dataset to Cloud Storage
2. Start with small model for testing
3. Scale up to larger models
4. Set up automated training with Cloud Functions
5. Enable model versioning with Vertex AI

## Resources

- [Google Cloud GPU Documentation](https://cloud.google.com/compute/docs/gpus)
- [PyTorch on GCP](https://cloud.google.com/deep-learning-vm/docs/pytorch_start_instance)
- [Cloud Storage Documentation](https://cloud.google.com/storage/docs)
