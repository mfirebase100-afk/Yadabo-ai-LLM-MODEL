# Yadabo AI - Architecture Documentation

This document provides detailed information about Yadabo AI's architecture.

## Overview

Yadabo AI is a Transformer-based language model built from scratch using PyTorch. It implements the complete Transformer architecture with support for both Arabic and English languages.

## Architecture Components

### 1. Token Embedding Layer

The token embedding layer transforms token IDs into dense vectors.

```python
TokenEmbedding(
    vocab_size=32000,
    d_model=512,
    padding_idx=0,
    dropout=0.1
)
```

**Features:**
- Learned embeddings for each token
- Optional dropout for regularization
- Handles padding tokens specially

### 2. Positional Encoding

Two options are available:

#### Sinusoidal Positional Encoding
- Uses sine and cosine functions
- Allows model to attend to relative positions
- No learned parameters

```python
PositionalEncoding(
    d_model=512,
    max_len=2048,
    dropout=0.1
)
```

#### Learned Positional Encoding
- Learns position embeddings
- May perform better for some tasks
- More parameters

### 3. Transformer Block

Each transformer block contains:

1. **Multi-Head Self-Attention**
   - 8 attention heads (configurable)
   - Scaled dot-product attention
   - Causal masking for autoregressive generation

2. **Feed-Forward Network**
   - Two linear layers with GELU activation
   - 4x expansion ratio (d_model -> d_ff -> d_model)

3. **Residual Connections**
   - Pre-normalization architecture
   - Layer normalization before each sublayer

```python
TransformerBlock(
    d_model=512,
    n_heads=8,
    d_ff=2048,
    dropout=0.1,
    activation="gelu"
)
```

### 4. Multi-Head Attention

The attention mechanism computes:

```
Attention(Q, K, V) = softmax(QK^T / sqrt(d_k))V
```

**Variants:**
- Standard Multi-Head Attention
- Grouped Query Attention (GQA) - fewer K/V heads
- Cross Attention (for encoder-decoder)

### 5. Feed-Forward Network

Standard FFN with configurable activation:

```
FFN(x) = max(0, xW1 + b1)W2 + b2
```

**Activation options:**
- GELU (default)
- ReLU
- SwiGLU (LLaMA-style)

## Model Variants

### Small (Testing)
```yaml
d_model: 256
n_heads: 4
n_layers: 4
d_ff: 1024
Parameters: ~8M
GPU Memory: ~1GB
```

### Medium (Development)
```yaml
d_model: 512
n_heads: 8
n_layers: 6
d_ff: 2048
Parameters: ~40M
GPU Memory: ~2GB
```

### Large (Production)
```yaml
d_model: 768
n_heads: 12
n_layers: 12
d_ff: 3072
Parameters: ~125M
GPU Memory: ~6GB
```

### Extra Large (Maximum)
```yaml
d_model: 1024
n_heads: 16
n_layers: 24
d_ff: 4096
Parameters: ~350M
GPU Memory: ~16GB
```

## Training

### Optimization
- **Optimizer:** AdamW with weight decay
- **Learning Rate Schedule:** Cosine annealing with warmup
- **Gradient Clipping:** max_norm=1.0
- **Gradient Checkpointing:** Optional for memory efficiency

### Regularization
- Dropout (configurable)
- Weight decay
- Label smoothing (optional)

## Tokenizer

### BPE Tokenizer

Byte Pair Encoding tokenizer optimized for Arabic and English:

1. **Pre-tokenization:** Splits text into words
2. **Byte-level encoding:** Handles any Unicode character
3. **BPE merging:** Learns most common token pairs
4. **Special tokens:** <pad>, <bos>, <eos>, <unk>, <mask>

### Arabic Support

- Full Arabic Unicode range (U+0600 to U+06FF)
- Proper handling of Arabic diacritics
- RTL text support

## Inference

### Generation Methods

1. **Greedy Decoding:** Select most probable token
2. **Temperature Sampling:** Add randomness
3. **Top-K Sampling:** Sample from top K tokens
4. **Nucleus (Top-P) Sampling:** Dynamic token selection
5. **Beam Search:** Explore multiple hypotheses

### KV Cache

For efficient generation, the model caches key and value tensors from previous steps.

## Memory Optimization

### Techniques Used

1. **Gradient Checkpointing:** Trade compute for memory
2. **Mixed Precision:** FP16/BF16 training
3. **Gradient Accumulation:** Larger effective batch size
4. **Efficient Data Loading:** Prefetching and pinning

### Memory Estimates

| Configuration | Parameters | Batch Size | Memory |
|--------------|------------|------------|--------|
| Small | 8M | 32 | 2GB |
| Medium | 40M | 16 | 4GB |
| Large | 125M | 8 | 8GB |
| XLarge | 350M | 4 | 16GB |

## Extensibility

### Adding New Attention Types

```python
class CustomAttention(MultiHeadAttention):
    def forward(self, x):
        # Custom attention logic
        pass

# Register in model
TransformerBlock(attention=CustomAttention)
```

### Custom Tokenizer

```python
class CustomTokenizer(BPETokenizer):
    def _init_patterns(self):
        # Add custom tokenization patterns
        pass
```

## References

- [Attention Is All You Need](https://arxiv.org/abs/1706.03762)
- [GPT-3 Paper](https://arxiv.org/abs/2005.14165)
- [LLaMA Paper](https://arxiv.org/abs/2302.13971)
