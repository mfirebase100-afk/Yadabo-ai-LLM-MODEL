# Yadabo AI - Quick Start Guide

Get started with Yadabo AI in minutes.

## Installation

```bash
# Clone repository
git clone https://github.com/yadabo/yadabo-ai.git
cd yadabo-ai

# Install dependencies
pip install torch numpy tqdm

# Install Yadabo AI
pip install -e .
```

## Quick Training Example

### 1. Prepare Data

Create a simple text file:

```bash
echo "Hello, world!
This is Yadabo AI.
We are training a language model." > data/sample.txt
```

### 2. Train Tokenizer

```bash
python scripts/train_tokenizer.py \
    --data data/sample.txt \
    --output data/tokenizer.json \
    --vocab_size 5000
```

### 3. Train Model

```bash
python scripts/train.py \
    --config config/small_test.yaml \
    --data_path data/sample.txt \
    --tokenizer_path data/tokenizer.json \
    --max_steps 100 \
    --output_dir ./output
```

### 4. Generate Text

```bash
python scripts/generate.py \
    --checkpoint ./output/checkpoint_step_100.pt \
    --tokenizer data/tokenizer.json \
    --prompt "Hello" \
    --max_new_tokens 50
```

## Complete Example Script

```python
import torch
from model import TransformerLM, TransformerConfig
from data import BPETokenizer, TextDataset, DataCollator, create_dataloader
from training import Trainer, TrainerConfig

# 1. Create tokenizer
tokenizer = BPETokenizer()
tokenizer.train(
    corpus=["Your training text here..."] * 100,
    vocab_size=5000,
)

# 2. Create model
config = TransformerConfig.small_arabic_english()
config.vocab_size = 5000
model = TransformerLM(config)

# 3. Create dataset
dataset = TextDataset(
    file_path="data/sample.txt",
    tokenizer=tokenizer,
    max_length=128,
)

# 4. Create trainer
trainer = Trainer(
    model=model,
    config=TrainerConfig(
        max_steps=100,
        learning_rate=1e-3,
        batch_size=4,
    ),
    train_dataloader=create_dataloader(
        dataset=dataset,
        batch_size=4,
        collate_fn=DataCollator(tokenizer),
    ),
)

# 5. Train
trainer.train()

# 6. Generate
prompt = "Hello"
input_ids = tokenizer.encode(prompt)
output = model.generate(
    torch.tensor([input_ids]),
    max_new_tokens=50,
)
print(tokenizer.decode(output[0]))
```

## Next Steps

- Read the [full documentation](README.md)
- Check out [configuration options](config/)
- Learn about [Google Cloud setup](setup_gcp.md)
- Explore the [API reference](api_reference.md)
