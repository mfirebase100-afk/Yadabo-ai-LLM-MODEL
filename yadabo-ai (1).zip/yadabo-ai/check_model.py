#!/usr/bin/env python3
"""
Yadabo AI - Model Size Calculator
Calculate model sizes for different configurations
"""

import math

def calculate_model_size(
    vocab_size=25000,
    d_model=256,
    n_layers=4,
    n_heads=4,
    d_ff=1024,
    max_seq_len=256
):
    """Calculate model size in parameters and memory."""

    # Token embeddings
    token_emb_params = vocab_size * d_model

    # Positional embeddings
    pos_emb_params = max_seq_len * d_model

    # Attention parameters per layer
    # Q, K, V projections: 3 * d_model * d_model
    # Output projection: d_model * d_model
    attn_params_per_layer = 4 * d_model * d_model

    # Feed-forward parameters per layer
    # W1: d_model * d_ff
    # W2: d_ff * d_model
    ff_params_per_layer = 2 * d_model * d_ff

    # Layer norms: 2 * d_model (gain + bias)
    layernorm_params_per_layer = 4 * d_model

    # Total per layer
    total_per_layer = attn_params_per_layer + ff_params_per_layer + layernorm_params_per_layer

    # All layers
    total_layers_params = total_per_layer * n_layers

    # Final layer norm
    final_ln_params = 2 * d_model

    # LM head
    lm_head_params = vocab_size * d_model

    # Total
    total_params = (
        token_emb_params +
        pos_emb_params +
        total_layers_params +
        final_ln_params +
        lm_head_params
    )

    # Memory estimates (FP32 = 4 bytes, FP16 = 2 bytes)
    memory_fp32_mb = (total_params * 4) / (1024 ** 2)
    memory_fp16_mb = (total_params * 2) / (1024 ** 2)
    memory_fp16_gb = memory_fp16_mb / 1024

    return {
        "vocab_size": vocab_size,
        "d_model": d_model,
        "n_layers": n_layers,
        "n_heads": n_heads,
        "d_ff": d_ff,
        "max_seq_len": max_seq_len,
        "total_params": total_params,
        "params_millions": total_params / 1_000_000,
        "memory_fp32_mb": memory_fp32_mb,
        "memory_fp16_mb": memory_fp16_mb,
        "memory_fp16_gb": memory_fp16_gb,
    }

# Different configurations
configs = [
    {"name": "Small (Test)", **calculate_model_size(25000, 256, 4, 4, 1024, 256)},
    {"name": "Medium", **calculate_model_size(30000, 512, 6, 8, 2048, 512)},
    {"name": "Large (GPU)", **calculate_model_size(32000, 768, 12, 12, 3072, 1024)},
    {"name": "XLarge (A100)", **calculate_model_size(32000, 1024, 24, 16, 4096, 2048)},
    {"name": "Huge", **calculate_model_size(50000, 1536, 32, 16, 6144, 4096)},
]

print("="*80)
print("📊 Yadabo AI - Model Sizes")
print("="*80)

for cfg in configs:
    print(f"\n🔹 {cfg['name']}")
    print(f"   Architecture: d_model={cfg['d_model']}, layers={cfg['n_layers']}, heads={cfg['n_heads']}")
    print(f"   Parameters: {cfg['params_millions']:.1f}M ({cfg['total_params']:,})")
    print(f"   Memory (FP32): {cfg['memory_fp32_mb']:.1f} MB")
    print(f"   Memory (FP16): {cfg['memory_fp16_mb']:.1f} MB ({cfg['memory_fp16_gb']:.2f} GB)")

print("\n" + "="*80)
print("📌 GPU Memory Requirements (with training overhead)")
print("="*80)

for cfg in configs:
    # Training needs ~3x inference memory for activations + gradients
    training_memory_gb = cfg['memory_fp16_gb'] * 3
    gpu_recommendation = "RTX 3090 (24GB)" if training_memory_gb <= 24 else "A100 (40GB)" if training_memory_gb <= 40 else "Multiple A100s"

    print(f"\n🔹 {cfg['name']} ({cfg['params_millions']:.0f}M params)")
    print(f"   Training Memory: ~{training_memory_gb:.1f} GB")
    print(f"   Recommended GPU: {gpu_recommendation}")

print("\n" + "="*80)
