"""
Yadabo AI - Logging Utilities
Logging configuration and helpers
"""

import os
import sys
import logging
from pathlib import Path
from typing import Optional
from datetime import datetime


def setup_logger(
    name: str = "yadabo",
    log_dir: Optional[str] = None,
    level: int = logging.INFO,
    format_string: Optional[str] = None,
    file_name: Optional[str] = None,
) -> logging.Logger:
    """
    Setup a logger with console and file handlers.

    Args:
        name: Logger name
        log_dir: Directory for log files
        level: Logging level
        format_string: Custom format string
        file_name: Custom log file name

    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers = []  # Clear existing handlers

    # Format
    if format_string is None:
        format_string = "%(asctime)s | %(levelname)-8s | %(message)s"
    formatter = logging.Formatter(format_string, datefmt="%Y-%m-%d %H:%M:%S")

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler
    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        if file_name is None:
            file_name = f"{name}_{datetime.now():%Y%m%d_%H%M%S}.log"
        file_path = os.path.join(log_dir, file_name)

        file_handler = logging.FileHandler(file_path)
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def get_logger(name: str = "yadabo") -> logging.Logger:
    """
    Get a logger instance.

    Args:
        name: Logger name

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


class LoggerWriter:
    """
    Writer class to redirect stdout/stderr to logger.
    """

    def __init__(self, logger: logging.Logger, level: int = logging.INFO):
        self.logger = logger
        self.level = level

    def write(self, message: str):
        """Write message to logger."""
        if message.strip():
            self.logger.log(self.level, message.strip())

    def flush(self):
        """Flush the writer."""
        pass


def redirect_output_to_logger(logger: logging.Logger):
    """
    Redirect stdout and stderr to logger.

    Args:
        logger: Logger to redirect to
    """
    sys.stdout = LoggerWriter(logger, logging.INFO)
    sys.stderr = LoggerWriter(logger, logging.ERROR)


class TrainingLogger:
    """
    Specialized logger for training progress.

    Tracks and displays:
    - Training progress
    - Loss values
    - Learning rates
    - ETA estimates
    """

    def __init__(
        self,
        total_steps: int,
        log_interval: int = 10,
        logger: Optional[logging.Logger] = None,
    ):
        self.total_steps = total_steps
        self.log_interval = log_interval
        self.logger = logger or get_logger()
        self.start_time = None

    def start(self):
        """Start timing."""
        import time
        self.start_time = time.time()

    def log_step(
        self,
        step: int,
        loss: float,
        lr: float,
        metrics: Optional[dict] = None,
    ):
        """Log training step."""
        if step % self.log_interval != 0:
            return

        elapsed = time.time() - self.start_time if self.start_time else 0
        progress = step / self.total_steps
        eta = elapsed / progress - elapsed if progress > 0 else 0

        msg = f"Step {step}/{self.total_steps} | "
        msg += f"Loss: {loss:.4f} | "
        msg += f"LR: {lr:.2e} | "
        msg += f"Progress: {progress * 100:.1f}% | "
        msg += f"ETA: {eta / 60:.1f}min"

        if metrics:
            metrics_str = " | ".join(f"{k}: {v:.4f}" for k, v in metrics.items())
            msg += f" | {metrics_str}"

        self.logger.info(msg)

    def log_epoch(self, epoch: int, metrics: dict):
        """Log epoch results."""
        msg = f"Epoch {epoch} Summary | "
        msg += " | ".join(f"{k}: {v:.4f}" for k, v in metrics.items())
        self.logger.info(msg)


def log_model_info(model, logger: Optional[logging.Logger] = None):
    """
    Log model architecture and parameter information.

    Args:
        model: Model to log
        logger: Logger to use
    """
    if logger is None:
        logger = get_logger()

    from .model_utils import count_parameters

    logger.info("=" * 60)
    logger.info("Model Architecture")
    logger.info("=" * 60)

    total_params, trainable_params = count_parameters(model)

    logger.info(f"Total parameters: {total_params:,}")
    logger.info(f"Trainable parameters: {trainable_params:,}")
    logger.info(f"Non-trainable parameters: {total_params - trainable_params:,}")
    logger.info("=" * 60)


def log_system_info(logger: Optional[logging.Logger] = None):
    """
    Log system and environment information.

    Args:
        logger: Logger to use
    """
    if logger is None:
        logger = get_logger()

    import platform
    import torch

    logger.info("=" * 60)
    logger.info("System Information")
    logger.info("=" * 60)
    logger.info(f"Platform: {platform.platform()}")
    logger.info(f"Python: {platform.python_version()}")
    logger.info(f"PyTorch: {torch.__version__}")
    logger.info(f"CUDA available: {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        logger.info(f"CUDA version: {torch.version.cuda}")
        logger.info(f"GPU count: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            logger.info(f"  GPU {i}: {torch.cuda.get_device_name(i)}")

    logger.info("=" * 60)
