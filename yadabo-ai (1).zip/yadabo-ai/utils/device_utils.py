"""
Yadabo AI - Device Utilities
Device detection and management
"""

import os
import random
import logging
from typing import Optional, Dict, Any
from dataclasses import dataclass

import torch
import numpy as np


@dataclass
class DeviceInfo:
    """Container for device information."""
    device: str
    device_name: str
    device_count: int
    cuda_available: bool
    cuda_version: Optional[str]
    memory_total: Optional[int]
    memory_available: Optional[int]


def get_device(preferred: str = "auto") -> torch.device:
    """
    Get the best available device.

    Args:
        preferred: Preferred device ('cuda', 'cpu', 'mps', 'auto')

    Returns:
        torch.device
    """
    if preferred == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        elif torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            return torch.device("cpu")

    device = torch.device(preferred)

    # Validate device availability
    if device.type == "cuda" and not torch.cuda.is_available():
        logging.warning("CUDA requested but not available, falling back to CPU")
        return torch.device("cpu")

    if device.type == "mps" and not torch.backends.mps.is_available():
        logging.warning("MPS requested but not available, falling back to CPU")
        return torch.device("cpu")

    return device


def get_device_info(device: Optional[torch.device] = None) -> DeviceInfo:
    """
    Get detailed device information.

    Args:
        device: Device to get info for (default: CUDA if available)

    Returns:
        DeviceInfo object
    """
    if device is None:
        device = get_device()

    info = DeviceInfo(
        device=str(device),
        device_name="CPU",
        device_count=1,
        cuda_available=False,
        cuda_version=None,
        memory_total=None,
        memory_available=None,
    )

    if device.type == "cuda":
        info.cuda_available = True
        info.cuda_version = torch.version.cuda
        info.device_count = torch.cuda.device_count()
        info.device_name = torch.cuda.get_device_name(device.index or 0)
        info.memory_total = torch.cuda.get_device_properties(device).total_memory
        info.memory_available = torch.cuda.memory_reserved(device)

    return info


def set_seed(seed: int, deterministic: bool = False):
    """
    Set random seed for reproducibility.

    Args:
        seed: Random seed
        deterministic: Enable deterministic operations (slower)
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        # Enable deterministic algorithms
        os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'


def move_to_device(obj: Any, device: torch.device) -> Any:
    """
    Move tensors in object to device.

    Handles:
    - torch.Tensor
    - dict of tensors
    - list/tuple of tensors
    - nested structures

    Args:
        obj: Object to move
        device: Target device

    Returns:
        Object on target device
    """
    if isinstance(obj, torch.Tensor):
        return obj.to(device)
    elif isinstance(obj, dict):
        return {k: move_to_device(v, device) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return type(obj)(move_to_device(v, device) for v in obj)
    else:
        return obj


def optimize_memory(device: torch.device):
    """
    Optimize memory usage for training.

    Args:
        device: Device to optimize
    """
    if device.type == "cuda":
        # Clear cache
        torch.cuda.empty_cache()

        # Enable memory pooling
        torch.cuda.memory.set_per_process_memory_fraction(0.95)

        # Memory stats
        logging.info(
            f"GPU Memory: {torch.cuda.memory_allocated(device) / 1024**3:.2f}GB / "
            f"{torch.cuda.get_device_properties(device).total_memory / 1024**3:.2f}GB"
        )


def get_optimal_batch_size(
    base_batch_size: int,
    model_size: int,
    device: torch.device,
) -> int:
    """
    Calculate optimal batch size based on available memory.

    Args:
        base_batch_size: Base batch size to scale
        model_size: Model size in bytes
        device: Target device

    Returns:
        Optimal batch size
    """
    if device.type != "cuda":
        return base_batch_size

    # Get available memory
    total_memory = torch.cuda.get_device_properties(device).total_memory
    available_memory = total_memory - torch.cuda.memory_reserved(device)

    # Estimate memory per sample (rough estimate)
    # Model + activations + gradients
    memory_per_sample = model_size * 4  # Rough estimate

    # Calculate max batch size
    max_batch_size = int(available_memory / memory_per_sample)

    # Return minimum of base and max
    return min(base_batch_size, max_batch_size)


class GPUMonitor:
    """
    Monitor GPU usage during training.
    """

    def __init__(self, device: torch.device):
        self.device = device
        self.memory_allocated = []
        self.memory_reserved = []

    def record(self):
        """Record current memory usage."""
        if self.device.type == "cuda":
            self.memory_allocated.append(torch.cuda.memory_allocated(self.device))
            self.memory_reserved.append(torch.cuda.memory_reserved(self.device))

    def get_stats(self) -> Dict[str, float]:
        """Get memory statistics."""
        if not self.memory_allocated:
            return {}

        return {
            "max_allocated_mb": max(self.memory_allocated) / 1024**2,
            "max_reserved_mb": max(self.memory_reserved) / 1024**2,
            "avg_allocated_mb": sum(self.memory_allocated) / len(self.memory_allocated) / 1024**2,
        }

    def reset(self):
        """Reset memory tracking."""
        self.memory_allocated = []
        self.memory_reserved = []
        if self.device.type == "cuda":
            torch.cuda.empty_cache()


# Environment variable helpers
def get_world_size() -> int:
    """Get distributed training world size."""
    return int(os.environ.get("WORLD_SIZE", 1))


def get_rank() -> int:
    """Get current process rank."""
    return int(os.environ.get("RANK", 0))


def is_main_process() -> bool:
    """Check if this is the main process."""
    return get_rank() == 0


def barrier():
    """Synchronization barrier for distributed training."""
    if get_world_size() > 1:
        torch.distributed.barrier()
