"""
Yadabo AI - Metrics Utilities
Evaluation metrics for language modeling
"""

import math
from typing import List, Dict, Any, Optional
import torch
import torch.nn.functional as F


def calculate_perplexity(loss: float) -> float:
    """
    Calculate perplexity from cross-entropy loss.

    Args:
        loss: Cross-entropy loss

    Returns:
        Perplexity score
    """
    return math.exp(loss)


def calculate_accuracy(
    logits: torch.Tensor,
    labels: torch.Tensor,
    ignore_index: int = -100,
) -> float:
    """
    Calculate token-level accuracy.

    Args:
        logits: Model logits of shape (batch, seq, vocab)
        labels: Target labels of shape (batch, seq)
        ignore_index: Token to ignore in accuracy

    Returns:
        Accuracy score
    """
    # Get predictions
    predictions = logits.argmax(dim=-1)  # (batch, seq)

    # Mask for valid tokens
    mask = labels != ignore_index
    correct = (predictions == labels) & mask

    # Calculate accuracy
    accuracy = correct.sum().item() / mask.sum().item()

    return accuracy


def calculate_top_k_accuracy(
    logits: torch.Tensor,
    labels: torch.Tensor,
    k: int = 5,
    ignore_index: int = -100,
) -> float:
    """
    Calculate top-k accuracy.

    Args:
        logits: Model logits
        labels: Target labels
        k: k for top-k
        ignore_index: Token to ignore

    Returns:
        Top-k accuracy
    """
    # Get top-k predictions
    _, top_k_preds = logits.topk(k, dim=-1)  # (batch, seq, k)

    # Expand labels for comparison
    labels_expanded = labels.unsqueeze(-1).expand_as(top_k_preds)

    # Check if any top-k prediction matches
    correct = (top_k_preds == labels_expanded).any(dim=-1)

    # Mask for valid tokens
    mask = labels != ignore_index
    correct = correct & mask

    accuracy = correct.sum().item() / mask.sum().item()

    return accuracy


def calculate_metrics(
    logits: torch.Tensor,
    labels: torch.Tensor,
    ignore_index: int = -100,
) -> Dict[str, float]:
    """
    Calculate multiple metrics at once.

    Args:
        logits: Model logits
        labels: Target labels
        ignore_index: Token to ignore

    Returns:
        Dictionary of metrics
    """
    # Calculate loss
    loss = F.cross_entropy(
        logits.view(-1, logits.size(-1)),
        labels.view(-1),
        ignore_index=ignore_index,
    )

    # Calculate accuracies
    acc1 = calculate_accuracy(logits, labels, ignore_index)
    acc5 = calculate_top_k_accuracy(logits, labels, k=5, ignore_index=ignore_index)

    # Calculate perplexity
    ppl = calculate_perplexity(loss.item())

    return {
        "loss": loss.item(),
        "perplexity": ppl,
        "accuracy": acc1,
        "top5_accuracy": acc5,
    }


class MetricsTracker:
    """
    Track metrics over training.

    Computes running averages and maintains history.
    """

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.history: Dict[str, List[float]] = {}
        self.windows: Dict[str, List[float]] = {}

    def update(self, metrics: Dict[str, float]):
        """Update metrics."""
        for key, value in metrics.items():
            if key not in self.history:
                self.history[key] = []
                self.windows[key] = []

            self.history[key].append(value)
            self.windows[key].append(value)

            # Maintain window
            if len(self.windows[key]) > self.window_size:
                self.windows[key].pop(0)

    def get_average(self, key: str, window: bool = False) -> float:
        """Get average for a metric."""
        if key not in self.history:
            return 0.0

        values = self.windows[key] if window else self.history[key]
        if not values:
            return 0.0

        return sum(values) / len(values)

    def get_all_averages(self, window: bool = False) -> Dict[str, float]:
        """Get averages for all metrics."""
        return {key: self.get_average(key, window) for key in self.history}

    def get_latest(self, key: str) -> float:
        """Get latest value for a metric."""
        if key not in self.history or not self.history[key]:
            return 0.0
        return self.history[key][-1]

    def reset(self):
        """Reset all metrics."""
        self.history = {}
        self.windows = {}

    def summary(self) -> Dict[str, Dict[str, float]]:
        """Get summary statistics."""
        summary = {}

        for key in self.history:
            values = self.history[key]
            if not values:
                continue

            summary[key] = {
                "latest": values[-1],
                "mean": sum(values) / len(values),
                "min": min(values),
                "max": max(values),
                "window_mean": self.get_average(key, window=True),
            }

        return summary


def evaluate_model(
    model,
    dataloader,
    device: str = "cuda",
    ignore_index: int = -100,
) -> Dict[str, float]:
    """
    Evaluate model on a dataset.

    Args:
        model: Model to evaluate
        dataloader: Data loader
        device: Device to use
        ignore_index: Token to ignore

    Returns:
        Dictionary of evaluation metrics
    """
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    total_correct = 0

    with torch.no_grad():
        for batch in dataloader:
            # Move to device
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch.get("labels", input_ids).to(device)

            # Forward pass
            outputs = model(input_ids, attention_mask=attention_mask)

            # Calculate loss
            loss = F.cross_entropy(
                outputs[..., :-1, :].reshape(-1, outputs.size(-1)),
                labels[..., 1:].reshape(-1),
                ignore_index=ignore_index,
            )

            total_loss += loss.item()

            # Calculate accuracy
            predictions = outputs[..., :-1, :].argmax(dim=-1)
            mask = labels[..., 1:] != ignore_index
            correct = (predictions == labels[..., 1:]) & mask
            total_correct += correct.sum().item()
            total_tokens += mask.sum().item()

    # Calculate metrics
    avg_loss = total_loss / len(dataloader)
    perplexity = math.exp(avg_loss)
    accuracy = total_correct / total_tokens if total_tokens > 0 else 0

    return {
        "loss": avg_loss,
        "perplexity": perplexity,
        "accuracy": accuracy,
    }


def compare_models(
    results: Dict[str, Dict[str, float]],
) -> Dict[str, Any]:
    """
    Compare multiple model evaluation results.

    Args:
        results: Dictionary mapping model names to their metrics

    Returns:
        Comparison summary
    """
    comparison = {
        "models": list(results.keys()),
        "metrics": {},
    }

    # Find best for each metric
    for model_name, metrics in results.items():
        for metric_name, value in metrics.items():
            if metric_name not in comparison["metrics"]:
                comparison["metrics"][metric_name] = {}

            comparison["metrics"][metric_name][model_name] = value

    # Determine winners
    comparison["winners"] = {}
    for metric_name, values in comparison["metrics"].items():
        # Lower is better for loss, perplexity
        if "loss" in metric_name.lower() or "perplexity" in metric_name.lower():
            comparison["winners"][metric_name] = min(values, key=values.get)
        else:
            # Higher is better for accuracy
            comparison["winners"][metric_name] = max(values, key=values.get)

    return comparison
