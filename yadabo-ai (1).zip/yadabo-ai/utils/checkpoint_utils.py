"""
Yadabo AI - Checkpoint Utilities
Checkpoint saving, loading, and management
"""

import os
import json
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict

import torch


@dataclass
class CheckpointInfo:
    """Information about a checkpoint."""
    path: str
    step: int
    epoch: int
    loss: float
    perplexity: Optional[float] = None
    metrics: Optional[Dict[str, float]] = None
    created_at: Optional[str] = None
    model_size_mb: Optional[float] = None


def save_checkpoint(
    model,
    optimizer,
    scheduler,
    step: int,
    epoch: int,
    loss: float,
    output_dir: str,
    metrics: Optional[Dict[str, float]] = None,
    filename: Optional[str] = None,
    save_optimizer: bool = True,
    save_scheduler: bool = True,
    save_model_only: bool = False,
) -> str:
    """
    Save a training checkpoint.

    Args:
        model: Model to save
        optimizer: Optimizer state (if save_optimizer=True)
        scheduler: Scheduler state (if save_scheduler=True)
        step: Current training step
        epoch: Current epoch
        loss: Current loss value
        output_dir: Directory to save checkpoint
        metrics: Additional metrics to save
        filename: Custom filename
        save_optimizer: Whether to save optimizer state
        save_scheduler: Whether to save scheduler state
        save_model_only: Save only model weights

    Returns:
        Path to saved checkpoint
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    if filename is None:
        filename = f"checkpoint_step{step}.pt"

    checkpoint_path = os.path.join(output_dir, filename)

    # Get model state dict
    if hasattr(model, 'module'):
        model_state = model.module.state_dict()
    else:
        model_state = model.state_dict()

    checkpoint = {
        "model_state_dict": model_state,
        "step": step,
        "epoch": epoch,
        "loss": loss,
    }

    if save_optimizer and optimizer is not None:
        checkpoint["optimizer_state_dict"] = optimizer.state_dict()

    if save_scheduler and scheduler is not None:
        checkpoint["scheduler_state_dict"] = scheduler.state_dict()

    if metrics is not None:
        checkpoint["metrics"] = metrics

    torch.save(checkpoint, checkpoint_path)

    logging.info(f"Checkpoint saved to {checkpoint_path}")

    # Save metadata as sidecar file
    metadata = {
        "step": step,
        "epoch": epoch,
        "loss": loss,
        "metrics": metrics,
    }
    metadata_path = checkpoint_path + ".meta.json"
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)

    return checkpoint_path


def load_checkpoint(
    checkpoint_path: str,
    model,
    optimizer=None,
    scheduler=None,
    device: str = "cpu",
    strict: bool = True,
) -> Dict[str, Any]:
    """
    Load a checkpoint.

    Args:
        checkpoint_path: Path to checkpoint file
        model: Model to load state into
        optimizer: Optimizer to load state into (optional)
        scheduler: Scheduler to load state into (optional)
        device: Device to load to
        strict: Whether to strictly enforce state dict matching

    Returns:
        Checkpoint metadata
    """
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    logging.info(f"Loading checkpoint from {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=device)

    # Load model state
    model_state = checkpoint.get("model_state_dict", checkpoint)

    if hasattr(model, 'module'):
        model.module.load_state_dict(model_state, strict=strict)
    else:
        model.load_state_dict(model_state, strict=strict)

    # Load optimizer state
    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

    # Load scheduler state
    if scheduler is not None and "scheduler_state_dict" in checkpoint:
        scheduler.load_state_dict(checkpoint["scheduler_state_dict"])

    metadata = {
        "step": checkpoint.get("step", 0),
        "epoch": checkpoint.get("epoch", 0),
        "loss": checkpoint.get("loss", 0),
        "metrics": checkpoint.get("metrics", {}),
    }

    logging.info(
        f"Checkpoint loaded | Step: {metadata['step']} | "
        f"Epoch: {metadata['epoch']} | Loss: {metadata['loss']:.4f}"
    )

    return metadata


def list_checkpoints(
    checkpoint_dir: str,
    pattern: str = "*.pt",
    sort_by: str = "step",
) -> List[CheckpointInfo]:
    """
    List all checkpoints in a directory.

    Args:
        checkpoint_dir: Directory to search
        pattern: File pattern to match
        sort_by: Sort by 'step', 'time', or 'loss'

    Returns:
        List of CheckpointInfo objects
    """
    checkpoint_dir = Path(checkpoint_dir)
    checkpoints = []

    for path in checkpoint_dir.glob(pattern):
        if path.suffix in ['.pt', '.pth']:
            info = _get_checkpoint_info(path)
            if info:
                checkpoints.append(info)

    # Sort checkpoints
    if sort_by == "step":
        checkpoints.sort(key=lambda x: x.step)
    elif sort_by == "time":
        checkpoints.sort(key=lambda x: x.created_at or "", reverse=True)
    elif sort_by == "loss":
        checkpoints.sort(key=lambda x: x.loss)

    return checkpoints


def _get_checkpoint_info(path: Path) -> Optional[CheckpointInfo]:
    """Get checkpoint info from file."""
    try:
        # Try to load metadata
        meta_path = str(path) + ".meta.json"
        if os.path.exists(meta_path):
            with open(meta_path, 'r') as f:
                metadata = json.load(f)
            return CheckpointInfo(
                path=str(path),
                step=metadata.get("step", 0),
                epoch=metadata.get("epoch", 0),
                loss=metadata.get("loss", 0),
                perplexity=metadata.get("perplexity"),
                metrics=metadata.get("metrics"),
                created_at=str(path.stat().st_mtime),
                model_size_mb=path.stat().st_size / 1024**2,
            )

        # Load checkpoint directly (slower)
        checkpoint = torch.load(path, map_location='cpu')
        return CheckpointInfo(
            path=str(path),
            step=checkpoint.get("step", 0),
            epoch=checkpoint.get("epoch", 0),
            loss=checkpoint.get("loss", 0),
            metrics=checkpoint.get("metrics"),
            created_at=str(path.stat().st_mtime),
            model_size_mb=path.stat().st_size / 1024**2,
        )
    except Exception as e:
        logging.warning(f"Could not read checkpoint {path}: {e}")
        return None


def get_latest_checkpoint(checkpoint_dir: str) -> Optional[str]:
    """
    Get the path to the latest checkpoint.

    Args:
        checkpoint_dir: Directory containing checkpoints

    Returns:
        Path to latest checkpoint or None
    """
    checkpoints = list_checkpoints(checkpoint_dir, sort_by="step")
    if checkpoints:
        return checkpoints[-1].path
    return None


def get_best_checkpoint(
    checkpoint_dir: str,
    metric: str = "loss",
    mode: str = "min",
) -> Optional[str]:
    """
    Get the path to the best checkpoint based on a metric.

    Args:
        checkpoint_dir: Directory containing checkpoints
        metric: Metric to compare
        mode: 'min' or 'max'

    Returns:
        Path to best checkpoint or None
    """
    checkpoints = list_checkpoints(checkpoint_dir)

    if not checkpoints:
        return None

    best = None
    best_value = float('inf') if mode == "min" else float('-inf')

    for cp in checkpoints:
        if cp.metrics and metric in cp.metrics:
            value = cp.metrics[metric]
        elif metric == "loss":
            value = cp.loss
        else:
            continue

        if mode == "min":
            if value < best_value:
                best_value = value
                best = cp
        else:
            if value > best_value:
                best_value = value
                best = cp

    return best.path if best else None


def cleanup_checkpoints(
    checkpoint_dir: str,
    keep_last: int = 3,
    keep_best: bool = True,
    metric: str = "loss",
    mode: str = "min",
):
    """
    Clean up old checkpoints.

    Args:
        checkpoint_dir: Directory containing checkpoints
        keep_last: Number of recent checkpoints to keep
        keep_best: Whether to keep the best checkpoint
        metric: Metric to determine best
        mode: 'min' or 'max'
    """
    checkpoints = list_checkpoints(checkpoint_dir)

    if not checkpoints:
        return

    # Determine checkpoints to keep
    to_keep = set()

    # Keep last N
    for cp in checkpoints[-keep_last:]:
        to_keep.add(cp.path)

    # Keep best
    if keep_best:
        best = get_best_checkpoint(checkpoint_dir, metric, mode)
        if best:
            to_keep.add(best)

    # Delete others
    for cp in checkpoints:
        if cp.path not in to_keep:
            try:
                os.remove(cp.path)
                # Also remove metadata
                meta_path = cp.path + ".meta.json"
                if os.path.exists(meta_path):
                    os.remove(meta_path)
                logging.info(f"Deleted checkpoint: {cp.path}")
            except Exception as e:
                logging.warning(f"Could not delete {cp.path}: {e}")


def copy_checkpoint(
    src: str,
    dst: str,
    keep_metadata: bool = True,
) -> str:
    """
    Copy a checkpoint to a new location.

    Args:
        src: Source checkpoint path
        dst: Destination path
        keep_metadata: Whether to copy metadata file

    Returns:
        Destination path
    """
    shutil.copy2(src, dst)

    if keep_metadata:
        src_meta = src + ".meta.json"
        if os.path.exists(src_meta):
            dst_meta = dst + ".meta.json"
            shutil.copy2(src_meta, dst_meta)

    return dst


def export_for_inference(
    model,
    output_path: str,
    tokenizer,
    config: Optional[Dict] = None,
):
    """
    Export model for inference (scripted/traced).

    Args:
        model: Model to export
        output_path: Output file path
        tokenizer: Tokenizer to save
        config: Model configuration
    """
    model.eval()

    # Save tokenizer
    tokenizer_path = output_path.replace(".pt", "_tokenizer.json")
    tokenizer.save(tokenizer_path)

    # Save config
    config_path = output_path.replace(".pt", "_config.json")
    if config:
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

    # Export model
    if hasattr(model, 'module'):
        model_to_save = model.module
    else:
        model_to_save = model

    # Create example input
    example_input = torch.randint(0, 32000, (1, 128))

    # Trace model
    with torch.no_grad():
        traced = torch.jit.trace(model_to_save, example_input)

    # Save traced model
    traced_path = output_path.replace(".pt", "_traced.pt")
    torch.jit.save(traced, traced_path)

    logging.info(f"Model exported to {traced_path}")
    logging.info(f"Tokenizer saved to {tokenizer_path}")


class CheckpointManager:
    """
    Manager for handling checkpoints during training.

    Tracks and manages:
    - Periodic saves
    - Best model tracking
    - Checkpoint cleanup
    """

    def __init__(
        self,
        output_dir: str,
        save_steps: int = 1000,
        keep_last: int = 3,
        keep_best: bool = True,
        monitor: str = "loss",
        mode: str = "min",
    ):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.save_steps = save_steps
        self.keep_last = keep_last
        self.keep_best = keep_best
        self.monitor = monitor
        self.mode = mode

        self.best_value = float('inf') if mode == "min" else float('-inf')
        self.checkpoints: List[str] = []

    def should_save(self, step: int) -> bool:
        """Check if a checkpoint should be saved."""
        return step % self.save_steps == 0

    def save(
        self,
        model,
        optimizer,
        scheduler,
        step: int,
        epoch: int,
        loss: float,
        metrics: Optional[Dict[str, float]] = None,
    ) -> Optional[str]:
        """Save checkpoint and return path."""
        checkpoint_path = save_checkpoint(
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            step=step,
            epoch=epoch,
            loss=loss,
            output_dir=str(self.output_dir),
            metrics=metrics,
        )

        self.checkpoints.append(checkpoint_path)

        # Check if best
        if self.keep_best:
            current = metrics.get(self.monitor, loss) if metrics else loss
            is_best = False

            if self.mode == "min":
                is_best = current < self.best_value
            else:
                is_best = current > self.best_value

            if is_best:
                self.best_value = current
                # Copy as best
                best_path = os.path.join(self.output_dir, "best.pt")
                copy_checkpoint(checkpoint_path, best_path)

        # Cleanup old checkpoints
        self._cleanup()

        return checkpoint_path

    def _cleanup(self):
        """Clean up old checkpoints."""
        if len(self.checkpoints) <= self.keep_last:
            return

        to_remove = self.checkpoints[:-self.keep_last]
        for path in to_remove:
            if os.path.exists(path):
                os.remove(path)
                meta_path = path + ".meta.json"
                if os.path.exists(meta_path):
                    os.remove(meta_path)
        self.checkpoints = self.checkpoints[-self.keep_last:]

    def get_latest(self) -> Optional[str]:
        """Get latest checkpoint path."""
        if self.checkpoints:
            return self.checkpoints[-1]
        return get_latest_checkpoint(str(self.output_dir))

    def get_best(self) -> Optional[str]:
        """Get best checkpoint path."""
        return os.path.join(self.output_dir, "best.pt")

    # Import List for type hint
    List = List if 'List' in dir() else list
