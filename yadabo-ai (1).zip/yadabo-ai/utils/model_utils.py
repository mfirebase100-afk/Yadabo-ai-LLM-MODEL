"""
Yadabo AI - Model Utilities
Model inspection and manipulation helpers
"""

import os
import logging
from typing import Dict, List, Tuple, Optional, Callable
from collections import OrderedDict

import torch
import torch.nn as nn


def count_parameters(
    model: nn.Module,
    trainable_only: bool = False,
) -> Tuple[int, int]:
    """
    Count model parameters.

    Args:
        model: Model to count
        trainable_only: Count only trainable parameters

    Returns:
        Tuple of (total_params, trainable_params)
    """
    total = 0
    trainable = 0

    for param in model.parameters():
        num_params = param.numel()
        total += num_params
        if param.requires_grad:
            trainable += num_params

    return total, trainable


def get_model_size_mb(model: nn.Module) -> float:
    """
    Get model size in megabytes.

    Args:
        model: Model to measure

    Returns:
        Size in MB
    """
    param_size = 0
    buffer_size = 0

    for param in model.parameters():
        param_size += param.nelement() * param.element_size()

    for buffer in model.buffers():
        buffer_size += buffer.nelement() * buffer.element_size()

    return (param_size + buffer_size) / 1024**2


def freeze_layers(
    model: nn.Module,
    layer_names: Optional[List[str]] = None,
    freeze_embeddings: bool = False,
    freeze_encoder: bool = False,
    freeze_decoder: bool = False,
):
    """
    Freeze specific layers in the model.

    Args:
        model: Model to freeze
        layer_names: Specific layer names to freeze
        freeze_embeddings: Freeze embedding layers
        freeze_encoder: Freeze encoder layers
        freeze_decoder: Freeze decoder layers
    """
    for name, param in model.named_parameters():
        should_freeze = False

        if layer_names:
            should_freeze = any(layer in name for layer in layer_names)
        elif freeze_embeddings and "embedding" in name.lower():
            should_freeze = True
        elif freeze_encoder and "encoder" in name.lower():
            should_freeze = True
        elif freeze_decoder and "decoder" in name.lower():
            should_freeze = True

        if should_freeze:
            param.requires_grad = False


def unfreeze_layers(
    model: nn.Module,
    layer_names: Optional[List[str]] = None,
    unfreeze_all: bool = False,
):
    """
    Unfreeze specific layers in the model.

    Args:
        model: Model to unfreeze
        layer_names: Specific layer names to unfreeze
        unfreeze_all: Unfreeze all layers
    """
    if unfreeze_all:
        for param in model.parameters():
            param.requires_grad = True
        return

    for name, param in model.named_parameters():
        if layer_names:
            if any(layer in name for layer in layer_names):
                param.requires_grad = True


def print_trainable_parameters(model: nn.Module) -> str:
    """
    Print trainable parameters with details.

    Args:
        model: Model to inspect

    Returns:
        Summary string
    """
    trainable_params = []
    frozen_params = []

    for name, param in model.named_parameters():
        if param.requires_grad:
            trainable_params.append((name, param.numel()))
        else:
            frozen_params.append((name, param.numel()))

    total_trainable = sum(p[1] for p in trainable_params)
    total_frozen = sum(p[1] for p in frozen_params)

    lines = []
    lines.append("=" * 60)
    lines.append("Trainable Parameters")
    lines.append("=" * 60)

    for name, num in sorted(trainable_params, key=lambda x: -x[1])[:10]:
        lines.append(f"  {name}: {num:,}")

    lines.append(f"  ... and {len(trainable_params) - 10} more")
    lines.append(f"Total trainable: {total_trainable:,}")

    lines.append("-" * 60)
    lines.append("Frozen Parameters")
    lines.append(f"Total frozen: {total_frozen:,}")
    lines.append("=" * 60)

    return "\n".join(lines)


def get_layer_wise_lr(
    model: nn.Module,
    base_lr: float,
    decay_factor: float = 0.9,
    num_layers: Optional[int] = None,
) -> List[Dict[str, float]]:
    """
    Create layer-wise learning rates with decay.

    Args:
        model: Model to create LR for
        base_lr: Base learning rate
        decay_factor: Decay factor per layer
        num_layers: Number of layers (auto-detect if None)

    Returns:
        List of parameter groups with learning rates
    """
    if num_layers is None:
        num_layers = _count_layers(model)

    param_groups = []
    for i, (name, param) in enumerate(model.named_parameters()):
        if not param.requires_grad:
            continue

        # Calculate layer depth (0 = embeddings, higher = later layers)
        layer_depth = _get_layer_depth(name, num_layers)
        lr = base_lr * (decay_factor ** layer_depth)

        param_groups.append({
            "params": [param],
            "lr": lr,
        })

    return param_groups


def _count_layers(model: nn.Module) -> int:
    """Count transformer layers in model."""
    count = 0
    for name, _ in model.named_modules():
        if "layer" in name.lower() or "block" in name.lower():
            count += 1
    return max(count, 1)


def _get_layer_depth(name: str, max_layers: int) -> float:
    """Get layer depth from parameter name."""
    import re

    # Try to extract layer number
    match = re.search(r'\.(\d+)\.', name)
    if match:
        layer_num = int(match.group(1))
        return layer_num

    # Default to middle
    return max_layers / 2


def apply_weight_decay_exemptions(
    model: nn.Module,
    no_decay_names: List[str] = None,
) -> List[Dict[str, any]]:
    """
    Create optimizer parameter groups with weight decay exemptions.

    Common exemptions: bias, layernorm, embedding

    Args:
        model: Model to create groups for
        no_decay_names: Additional names to exempt

    Returns:
        List of parameter groups
    """
    if no_decay_names is None:
        no_decay_names = []

    no_decay_keywords = [
        "bias", "layernorm", "layer_norm", "bn", "batchnorm",
        "batch_norm", "embedding", "positional",
    ] + no_decay_names

    decay_params = []
    no_decay_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue

        if any(keyword in name.lower() for keyword in no_decay_keywords):
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    return [
        {"params": decay_params, "weight_decay": 0.01},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]


def get_gradient_flow_direction(
    model: nn.Module,
) -> Dict[str, float]:
    """
    Analyze gradient flow through the model.

    Args:
        model: Model to analyze

    Returns:
        Dictionary mapping layer names to gradient norms
    """
    grad_norms = {}

    for name, param in model.named_parameters():
        if param.grad is not None:
            grad_norm = param.grad.norm().item()
            grad_norms[name] = grad_norm

    return grad_norms


def summarize_gradients(
    model: nn.Module,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, float]:
    """
    Summarize gradient statistics.

    Args:
        model: Model to analyze
        logger: Logger to write to

    Returns:
        Summary statistics
    """
    total_norm = 0.0
    num_grads = 0
    grad_stats = {
        "max": float('-inf'),
        "min": float('inf'),
        "mean": 0.0,
    }

    for param in model.parameters():
        if param.grad is not None:
            grad = param.grad.data
            grad_norm = grad.norm().item()
            total_norm += grad_norm ** 2
            num_grads += 1

            grad_stats["max"] = max(grad_stats["max"], grad_norm)
            grad_stats["min"] = min(grad_stats["min"], grad_norm)

    grad_stats["mean"] = total_norm / num_grads if num_grads > 0 else 0
    grad_stats["total_norm"] = total_norm ** 0.5

    if logger:
        logger.info(
            f"Gradient Stats | Total Norm: {grad_stats['total_norm']:.4f} | "
            f"Max: {grad_stats['max']:.4f} | Min: {grad_stats['min']:.4f}"
        )

    return grad_stats


def replace_activation(
    model: nn.Module,
    old_activation: str,
    new_activation: Callable,
):
    """
    Replace activation functions in model.

    Args:
        model: Model to modify
        old_activation: Name of activation to replace
        new_activation: New activation function
    """
    for name, module in model.named_modules():
        if old_activation.lower() in type(module).__name__.lower():
            # Replace in parent
            parent_name, child_name = _get_parent_child_names(model, name)
            if parent_name:
                parent = model.get_submodule(parent_name)
                setattr(parent, child_name, new_activation())


def _get_parent_child_names(model: nn.Module, full_name: str) -> Tuple[Optional[str], str]:
    """Get parent and child module names from full path."""
    parts = full_name.rsplit('.', 1)
    if len(parts) == 1:
        return None, parts[0]
    return parts[0], parts[1]


# Model architecture inspection
def get_attention_weights_shapes(model: nn.Module) -> Dict[str, tuple]:
    """Get shapes of all attention weight matrices."""
    shapes = {}

    for name, module in model.named_modules():
        if "attention" in name.lower():
            if hasattr(module, 'qkv_proj'):
                shapes[f"{name}.qkv"] = module.qkv_proj.weight.shape
            if hasattr(module, 'out_proj'):
                shapes[f"{name}.out"] = module.out_proj.weight.shape

    return shapes


def verify_model_integrity(model: nn.Module) -> bool:
    """
    Verify model has no NaN or Inf values.

    Args:
        model: Model to verify

    Returns:
        True if model is valid
    """
    has_nan = False
    has_inf = False

    for name, param in model.named_parameters():
        if torch.isnan(param).any():
            logging.error(f"NaN detected in {name}")
            has_nan = True
        if torch.isinf(param).any():
            logging.error(f"Inf detected in {name}")
            has_inf = True

    return not (has_nan or has_inf)


# Optional typing import for type hints
Optional = Optional if 'Optional' in dir(__builtins__) else None
if Optional is None:
    from typing import Optional
