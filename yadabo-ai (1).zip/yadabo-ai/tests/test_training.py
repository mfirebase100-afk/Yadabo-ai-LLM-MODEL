"""
Yadabo AI - Training Tests
Test suite for training components
"""

import pytest
import torch
import torch.nn as nn

from training import create_optimizer, create_scheduler
from training.optimizer import AdamW, Lion, SophiaG, LAMB
from training.scheduler import get_cosine_schedule_with_warmup


class TestOptimizers:
    """Tests for optimizer implementations."""

    @pytest.fixture
    def simple_model(self):
        """Simple model for testing."""
        return nn.Sequential(
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
        )

    def test_adamw_creation(self, simple_model):
        """Test AdamW optimizer creation."""
        optimizer = create_optimizer(
            simple_model,
            optimizer_type="adamw",
            learning_rate=1e-3,
        )

        assert isinstance(optimizer, AdamW)
        assert optimizer.defaults['lr'] == 1e-3

    def test_lion_creation(self, simple_model):
        """Test Lion optimizer creation."""
        optimizer = create_optimizer(
            simple_model,
            optimizer_type="lion",
            learning_rate=1e-4,
        )

        assert isinstance(optimizer, Lion)

    def test_sophia_creation(self, simple_model):
        """Test Sophia optimizer creation."""
        optimizer = create_optimizer(
            simple_model,
            optimizer_type="sophia",
            learning_rate=1e-4,
        )

        assert isinstance(optimizer, SophiaG)

    def test_lamb_creation(self, simple_model):
        """Test LAMB optimizer creation."""
        optimizer = create_optimizer(
            simple_model,
            optimizer_type="lamb",
            learning_rate=1e-3,
        )

        assert isinstance(optimizer, LAMB)

    def test_weight_decay_separation(self, simple_model):
        """Test that weight decay is applied correctly."""
        optimizer = create_optimizer(
            simple_model,
            weight_decay=0.01,
        )

        # Check parameter groups
        has_decay = any(g['weight_decay'] > 0 for g in optimizer.param_groups)
        no_decay = any(g['weight_decay'] == 0 for g in optimizer.param_groups)

        assert has_decay
        assert no_decay

    def test_optimizer_step(self, simple_model):
        """Test optimizer can perform step."""
        optimizer = create_optimizer(simple_model, learning_rate=1e-3)

        # Forward pass
        x = torch.randn(4, 64)
        y = simple_model(x)
        loss = y.sum()

        # Backward
        loss.backward()

        # Step
        optimizer.step()
        optimizer.zero_grad()

        # Check loss was backpropagated
        assert loss.item() is not None


class TestSchedulers:
    """Tests for learning rate schedulers."""

    @pytest.fixture
    def optimizer(self):
        """Optimizer for testing."""
        model = nn.Linear(10, 10)
        return torch.optim.Adam(model.parameters(), lr=0.1)

    def test_cosine_schedule(self, optimizer):
        """Test cosine schedule with warmup."""
        scheduler = get_cosine_schedule_with_warmup(
            optimizer,
            num_warmup_steps=100,
            num_training_steps=1000,
        )

        # Initial LR
        assert optimizer.param_groups[0]['lr'] == 0.1

        # After warmup
        for _ in range(100):
            scheduler.step()
        warmup_lr = optimizer.param_groups[0]['lr']
        assert warmup_lr > 0.1  # Should have increased during warmup

        # After more steps
        for _ in range(400):
            scheduler.step()
        final_lr = optimizer.param_groups[0]['lr']
        assert final_lr < warmup_lr  # Should have decreased

    def test_create_scheduler(self, optimizer):
        """Test scheduler factory function."""
        scheduler = create_scheduler(
            optimizer,
            scheduler_type="cosine",
            num_warmup_steps=100,
            num_training_steps=1000,
        )

        assert scheduler is not None

    def test_scheduler_step(self, optimizer):
        """Test scheduler can perform step."""
        scheduler = create_scheduler(
            optimizer,
            scheduler_type="cosine",
            num_warmup_steps=10,
            num_training_steps=100,
        )

        initial_lr = optimizer.param_groups[0]['lr']

        for _ in range(20):
            optimizer.step()
            scheduler.step()

        new_lr = optimizer.param_groups[0]['lr']
        assert new_lr != initial_lr


class TestTrainingLoop:
    """Tests for complete training loop."""

    def test_single_training_step(self):
        """Test a single training step."""
        from model import TransformerConfig, TransformerLM

        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        optimizer = create_optimizer(model, learning_rate=1e-3)

        # Create dummy batch
        batch_size = 2
        seq_len = 16
        input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))

        # Forward pass
        loss, _ = model(input_ids, labels=input_ids)

        # Backward
        loss.backward()

        # Optimizer step
        optimizer.step()
        optimizer.zero_grad()

        assert loss.item() > 0

    def test_gradient_accumulation(self):
        """Test gradient accumulation."""
        from model import TransformerConfig, TransformerLM

        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        optimizer = create_optimizer(model, learning_rate=1e-3)

        batch_size = 2
        seq_len = 16
        accumulation_steps = 4

        initial_params = [p.clone() for p in model.parameters()]

        for _ in range(accumulation_steps):
            input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
            loss, _ = model(input_ids, labels=input_ids)
            loss = loss / accumulation_steps
            loss.backward()

        optimizer.step()
        optimizer.zero_grad()

        # Check parameters changed
        changed = any(
            not torch.allclose(p, ip)
            for p, ip in zip(model.parameters(), initial_params)
        )
        assert changed


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
