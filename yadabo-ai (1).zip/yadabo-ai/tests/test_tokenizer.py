"""
Yadabo AI - Tokenizer Tests
Test suite for BPE tokenizer
"""

import pytest
from data import BPETokenizer, TokenizerConfig


class TestBPETokenizer:
    """Tests for BPETokenizer."""

    @pytest.fixture
    def sample_corpus(self):
        """Sample corpus for testing."""
        return [
            "Hello, world!",
            "This is a test.",
            "The quick brown fox jumps.",
            "Yadabo AI is amazing.",
        ] * 100  # Repeat for more data

    @pytest.fixture
    def trained_tokenizer(self, sample_corpus):
        """Trained tokenizer for testing."""
        config = TokenizerConfig(vocab_size=500, min_frequency=2)
        tokenizer = BPETokenizer(config)
        tokenizer.train(sample_corpus, vocab_size=500, min_frequency=2)
        return tokenizer

    def test_tokenizer_initialization(self):
        """Test tokenizer initializes correctly."""
        config = TokenizerConfig(vocab_size=1000)
        tokenizer = BPETokenizer(config)

        assert len(tokenizer) >= len(config.special_tokens)

    def test_train_creates_vocabulary(self, sample_corpus):
        """Test that training creates vocabulary."""
        config = TokenizerConfig(vocab_size=200, min_frequency=2)
        tokenizer = BPETokenizer(config)
        tokenizer.train(sample_corpus, vocab_size=200, min_frequency=2)

        assert len(tokenizer) >= 200

    def test_encode_decode(self, trained_tokenizer):
        """Test encoding and decoding."""
        text = "Hello, world!"

        encoded = trained_tokenizer.encode(text)
        decoded = trained_tokenizer.decode(encoded)

        assert isinstance(encoded, list)
        assert isinstance(decoded, str)
        assert len(encoded) > 0

    def test_encode_with_special_tokens(self, trained_tokenizer):
        """Test encoding with special tokens."""
        text = "Test sentence"
        encoded_with = trained_tokenizer.encode(text, add_special_tokens=True)
        encoded_without = trained_tokenizer.encode(text, add_special_tokens=False)

        # Should have special tokens at start and end
        assert len(encoded_with) >= len(encoded_without)

    def test_decode_skip_special_tokens(self, trained_tokenizer):
        """Test decoding skips special tokens."""
        text = "Hello world"
        encoded = trained_tokenizer.encode(text, add_special_tokens=True)

        decoded_skip = trained_tokenizer.decode(encoded, skip_special_tokens=True)
        decoded_keep = trained_tokenizer.decode(encoded, skip_special_tokens=False)

        # Should be different when skipping vs keeping special tokens
        assert isinstance(decoded_skip, str)
        assert isinstance(decoded_keep, str)

    def test_batch_encode_decode(self, trained_tokenizer):
        """Test batch operations."""
        texts = ["Hello", "World", "Test"]

        encoded_batch = trained_tokenizer.batch_encode(texts)
        decoded_batch = trained_tokenizer.batch_decode(encoded_batch["input_ids"])

        assert len(encoded_batch["input_ids"]) == len(texts)
        assert len(decoded_batch) == len(texts)

    def test_arabic_text(self, trained_tokenizer):
        """Test handling of Arabic text."""
        arabic_text = "مرحبا بالعالم"

        encoded = trained_tokenizer.encode(arabic_text)
        decoded = trained_tokenizer.decode(encoded)

        assert isinstance(encoded, list)
        assert len(encoded) > 0

    def test_special_tokens(self, trained_tokenizer):
        """Test special tokens are properly handled."""
        assert trained_tokenizer.special_tokens["<pad>"] in trained_tokenizer.token_to_id
        assert trained_tokenizer.special_tokens["<bos>"] in trained_tokenizer.token_to_id
        assert trained_tokenizer.special_tokens["<eos>"] in trained_tokenizer.token_to_id

    def test_tokenizer_save_load(self, trained_tokenizer, tmp_path):
        """Test tokenizer save and load."""
        tokenizer_path = tmp_path / "tokenizer.json"

        trained_tokenizer.save(str(tokenizer_path))
        loaded_tokenizer = BPETokenizer.load(str(tokenizer_path))

        # Check vocabulary matches
        assert len(loaded_tokenizer) == len(trained_tokenizer)

        # Check merges match
        assert len(loaded_tokenizer.merges) == len(trained_tokenizer.merges)


class TestTokenizerConfig:
    """Tests for TokenizerConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = TokenizerConfig()

        assert config.vocab_size == 32000
        assert config.min_frequency == 2
        assert config.byte_fallback is True

    def test_custom_special_tokens(self):
        """Test custom special tokens."""
        special = {"<pad>": 0, "<bos>": 1, "<custom>": 100}
        config = TokenizerConfig(special_tokens=special)

        assert config.special_tokens["<custom>"] == 100


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
