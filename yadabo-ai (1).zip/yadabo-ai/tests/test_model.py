"""
Yadabo AI - Unit Tests
Test suite for model components
"""

import pytest
import torch

from model import TransformerLM, TransformerConfig
from model.embeddings import TokenEmbedding, PositionalEncoding
from model.attention import MultiHeadAttention
from model.feedforward import FeedForward
from model.layers import TransformerBlock, LayerNorm


class TestTokenEmbedding:
    """Tests for TokenEmbedding module."""

    def test_embedding_forward(self):
        """Test forward pass produces correct shape."""
        vocab_size = 1000
        d_model = 64
        batch_size = 4
        seq_len = 32

        embedding = TokenEmbedding(vocab_size, d_model)
        input_ids = torch.randint(0, vocab_size, (batch_size, seq_len))

        output = embedding(input_ids)

        assert output.shape == (batch_size, seq_len, d_model)

    def test_padding_handling(self):
        """Test that padding tokens have zero embeddings."""
        vocab_size = 1000
        d_model = 64

        embedding = TokenEmbedding(vocab_size, d_model, padding_idx=0)

        # Check that padding embeddings are zero
        assert torch.all(embedding.token_embedding.weight[0] == 0)


class TestPositionalEncoding:
    """Tests for PositionalEncoding module."""

    def test_output_shape(self):
        """Test output has correct shape."""
        d_model = 64
        max_len = 100
        batch_size = 4
        seq_len = 32

        pe = PositionalEncoding(d_model, max_len)
        x = torch.randn(batch_size, seq_len, d_model)

        output = pe(x)

        assert output.shape == (batch_size, seq_len, d_model)


class TestMultiHeadAttention:
    """Tests for MultiHeadAttention module."""

    def test_attention_output_shape(self):
        """Test attention produces correct output shape."""
        d_model = 64
        n_heads = 4
        batch_size = 2
        seq_len = 16

        attention = MultiHeadAttention(d_model, n_heads)
        x = torch.randn(batch_size, seq_len, d_model)

        output, weights = attention(x, is_causal=True)

        assert output.shape == (batch_size, seq_len, d_model)
        assert weights.shape == (batch_size, n_heads, seq_len, seq_len)

    def test_causal_masking(self):
        """Test that causal masking prevents attending to future tokens."""
        d_model = 64
        n_heads = 4
        batch_size = 1
        seq_len = 8

        attention = MultiHeadAttention(d_model, n_heads)
        x = torch.randn(batch_size, seq_len, d_model)

        output, weights = attention(x, is_causal=True)

        # Check that causal mask is applied
        # All positions should be able to attend to position 0
        assert torch.all(weights[0, 0, :, 0] == weights[0, 0, 0, 0])


class TestFeedForward:
    """Tests for FeedForward module."""

    def test_ffn_output_shape(self):
        """Test FFN produces correct output shape."""
        d_model = 64
        d_ff = 256
        batch_size = 4
        seq_len = 16

        ff = FeedForward(d_model, d_ff)
        x = torch.randn(batch_size, seq_len, d_model)

        output = ff(x)

        assert output.shape == (batch_size, seq_len, d_model)

    def test_gelu_activation(self):
        """Test GELU activation."""
        ff = FeedForward(64, 256, activation="gelu")
        x = torch.randn(2, 8, 64)
        output = ff(x)
        assert not torch.isnan(output).any()


class TestTransformerBlock:
    """Tests for TransformerBlock module."""

    def test_block_output_shape(self):
        """Test transformer block produces correct output shape."""
        d_model = 64
        n_heads = 4
        d_ff = 256
        batch_size = 2
        seq_len = 16

        block = TransformerBlock(d_model, n_heads, d_ff)
        x = torch.randn(batch_size, seq_len, d_model)

        output = block(x, is_causal=True)

        assert output.shape == (batch_size, seq_len, d_model)


class TestTransformerLM:
    """Tests for complete TransformerLM model."""

    def test_model_forward(self):
        """Test complete model forward pass."""
        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        batch_size = 2
        seq_len = 32

        input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
        output = model(input_ids)

        assert output.shape == (batch_size, seq_len, config.vocab_size)

    def test_model_with_labels(self):
        """Test model with labels returns loss."""
        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        batch_size = 2
        seq_len = 32

        input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
        loss, output = model(input_ids, labels=input_ids)

        assert isinstance(loss.item(), float)
        assert output.shape == (batch_size, seq_len, config.vocab_size)

    def test_generation(self):
        """Test text generation."""
        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)
        model.eval()

        batch_size = 1
        prompt_len = 8

        input_ids = torch.randint(0, config.vocab_size, (batch_size, prompt_len))
        output = model.generate(input_ids, max_new_tokens=10)

        assert output.shape[1] == prompt_len + 10

    def test_model_size_info(self):
        """Test model size calculation."""
        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        size_info = model.get_model_size()

        assert "total_parameters" in size_info
        assert "memory_mb" in size_info
        assert size_info["total_parameters"] > 0

    def test_checkpoint_save_load(self, tmp_path):
        """Test checkpoint saving and loading."""
        config = TransformerConfig.small_arabic_english()
        model = TransformerLM(config)

        checkpoint_path = tmp_path / "test_checkpoint.pt"
        model.save(str(checkpoint_path))

        loaded_model, metadata = TransformerLM.load(str(checkpoint_path))

        # Check that model was loaded correctly
        assert isinstance(loaded_model, TransformerLM)

        # Check that parameters match
        original_params = sum(p.numel() for p in model.parameters())
        loaded_params = sum(p.numel() for p in loaded_model.parameters())
        assert original_params == loaded_params


class TestConfiguration:
    """Tests for TransformerConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = TransformerConfig()

        assert config.vocab_size == 32000
        assert config.d_model == 512
        assert config.n_heads == 8
        assert config.n_layers == 6

    def test_preset_configs(self):
        """Test preset configurations."""
        small = TransformerConfig.small_arabic_english()
        assert small.d_model == 256
        assert small.n_layers == 4

        large = TransformerConfig.large_arabic_english()
        assert large.d_model == 768
        assert large.n_layers == 12

    def test_config_save_load(self, tmp_path):
        """Test configuration save and load."""
        config = TransformerConfig.small_arabic_english()

        config_path = tmp_path / "config.yaml"
        config.save(str(config_path))

        loaded_config = TransformerConfig.load(str(config_path))

        assert loaded_config.vocab_size == config.vocab_size
        assert loaded_config.d_model == config.d_model


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
