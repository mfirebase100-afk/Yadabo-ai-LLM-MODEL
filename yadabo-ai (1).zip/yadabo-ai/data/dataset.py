"""
Yadabo AI - Dataset Implementation
Dataset classes for language modeling
"""

import os
import torch
from torch.utils.data import Dataset, IterableDataset
from typing import List, Dict, Optional, Iterator, Callable
import random


class TextDataset(Dataset):
    """
    Text Dataset for Language Modeling.

    Loads text from files and prepares training examples
    by creating sliding window chunks.

    Args:
        file_path: Path to text file or list of paths
        tokenizer: Tokenizer to use for encoding
        max_length: Maximum sequence length
        stride: Stride for sliding window
        lazy: Whether to load data lazily
    """

    def __init__(
        self,
        file_path: str,
        tokenizer,
        max_length: int = 512,
        stride: int = 128,
        lazy: bool = False,
    ):
        self.file_path = file_path
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.stride = stride

        if lazy:
            self.examples = None
            self._load_lazy()
        else:
            self.examples = self._load_and_tokenize()

    def _load_and_tokenize(self) -> List[Dict[str, torch.Tensor]]:
        """Load text file and tokenize all content."""
        examples = []

        # Handle both single file and directory
        if os.path.isdir(self.file_path):
            file_paths = [
                os.path.join(self.file_path, f)
                for f in os.listdir(self.file_path)
                if f.endswith('.txt') or f.endswith('.json')
            ]
        else:
            file_paths = [self.file_path]

        for fp in file_paths:
            with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read()

            # Tokenize with sliding window
            tokens = self.tokenizer.encode(text, add_special_tokens=False)

            # Create sliding windows
            for i in range(0, len(tokens) - max_length, self.stride):
                chunk = tokens[i:i + max_length]
                examples.append({
                    'input_ids': torch.tensor(chunk, dtype=torch.long),
                })

        return examples

    def _load_lazy(self):
        """Load data lazily for large files."""
        # For very large files, load in chunks
        self.total_length = 0
        if os.path.isfile(self.file_path):
            with open(self.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                while True:
                    chunk = f.read(1024 * 1024)  # 1MB chunks
                    if not chunk:
                        break
                    tokens = self.tokenizer.encode(chunk, add_special_tokens=False)
                    self.total_length += len(tokens)

    def __len__(self) -> int:
        """Return number of examples."""
        if self.examples is not None:
            return len(self.examples)
        return self.total_length // self.stride

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get a single example."""
        if self.examples is not None:
            return self.examples[idx]

        # Lazy loading
        offset = idx * self.stride
        with open(self.file_path, 'r', encoding='utf-8', errors='ignore') as f:
            f.seek(offset)
            chunk = f.read(self.max_length * 10)
            tokens = self.tokenizer.encode(chunk, add_special_tokens=False)

        return {
            'input_ids': torch.tensor(tokens[:self.max_length], dtype=torch.long),
        }


class StreamingTextDataset(IterableDataset):
    """
    Streaming Text Dataset for large corpora.

    Memory-efficient dataset that streams examples on-the-fly.
    Ideal for very large datasets that don't fit in memory.

    Args:
        file_paths: List of text file paths
        tokenizer: Tokenizer to use
        max_length: Maximum sequence length
        shuffle_buffer: Buffer size for shuffling
    """

    def __init__(
        self,
        file_paths: List[str],
        tokenizer,
        max_length: int = 512,
        shuffle: bool = False,
        shuffle_buffer: int = 10000,
    ):
        self.file_paths = file_paths
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.shuffle = shuffle
        self.shuffle_buffer = shuffle_buffer

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        """Iterate over dataset."""
        buffer = []

        for file_path in self.file_paths:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                current_text = []

                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    # Tokenize line
                    tokens = self.tokenizer.encode(line, add_special_tokens=False)
                    current_text.extend(tokens)

                    # Yield examples when buffer is full
                    while len(current_text) >= self.max_length:
                        example = {
                            'input_ids': torch.tensor(
                                current_text[:self.max_length],
                                dtype=torch.long
                            )
                        }

                        if self.shuffle:
                            buffer.append(example)
                            if len(buffer) >= self.shuffle_buffer:
                                yield buffer.pop(random.randint(0, len(buffer) - 1))
                        else:
                            yield example

                        current_text = current_text[self.max_length // 2:]

                # Yield remaining tokens
                if current_text:
                    yield {
                        'input_ids': torch.tensor(
                            current_text[:self.max_length],
                            dtype=torch.long
                        )
                    }

        # Yield remaining buffer items
        if self.shuffle:
            random.shuffle(buffer)
            while buffer:
                yield buffer.pop()


class ConcatDataset(Dataset):
    """
    Concatenated Dataset for mixing multiple sources.

    Useful for combining different text sources like
    code and natural language.

    Args:
        datasets: List of datasets to concatenate
        probabilities: Sampling probabilities for each dataset
    """

    def __init__(
        self,
        datasets: List[Dataset],
        probabilities: Optional[List[float]] = None,
    ):
        self.datasets = datasets
        self.cumulative_sizes = self._get_cumulative_sizes()

        if probabilities:
            assert len(probabilities) == len(datasets)
            # Normalize probabilities
            total = sum(probabilities)
            self.probabilities = [p / total for p in probabilities]
        else:
            self.probabilities = None

    def _get_cumulative_sizes(self) -> List[int]:
        """Calculate cumulative sizes for indexing."""
        sizes = [len(d) for d in self.datasets]
        cumsum = [0]
        for s in sizes:
            cumsum.append(cumsum[-1] + s)
        return cumsum

    def __len__(self) -> int:
        return self.cumulative_sizes[-1]

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get item from appropriate dataset."""
        # Find which dataset this index belongs to
        dataset_idx = 0
        for i, size in enumerate(self.cumulative_sizes[1:], 1):
            if idx < size:
                dataset_idx = i - 1
                break

        # Get item from that dataset
        local_idx = idx - self.cumulative_sizes[dataset_idx]
        return self.datasets[dataset_idx][local_idx]


class CodeDataset(Dataset):
    """
    Specialized Dataset for Programming Code.

    Handles code-specific formatting and preserves
    structure like function definitions.

    Args:
        file_path: Path to code file or directory
        tokenizer: Tokenizer to use
        max_length: Maximum sequence length
        language: Programming language hint
    """

    def __init__(
        self,
        file_path: str,
        tokenizer,
        max_length: int = 512,
        language: Optional[str] = None,
    ):
        self.file_path = file_path
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.language = language
        self.examples = self._load_code()

    def _load_code(self) -> List[Dict[str, torch.Tensor]]:
        """Load and tokenize code files."""
        examples = []

        extensions = {
            'python': ['.py'],
            'javascript': ['.js', '.jsx', '.ts', '.tsx'],
            'java': ['.java'],
            'cpp': ['.cpp', '.cc', '.cxx', '.h', '.hpp'],
            'c': ['.c', '.h'],
            'go': ['.go'],
            'rust': ['.rs'],
            'ruby': ['.rb'],
            'php': ['.php'],
            'swift': ['.swift'],
            'kotlin': ['.kt', '.kts'],
            'scala': ['.scala'],
            'general': ['.txt', '.md', '.code']
        }

        exts = extensions.get(self.language, extensions['general'])

        # Collect files
        if os.path.isdir(file_path):
            file_paths = []
            for root, _, files in os.walk(file_path):
                for f in files:
                    if any(f.endswith(ext) for ext in exts):
                        file_paths.append(os.path.join(root, f))
        else:
            file_paths = [self.file_path]

        for fp in file_paths:
            try:
                with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                    code = f.read()

                # Add code markers
                code = f" {self.language or 'code'} " + code + " </code>"

                # Tokenize
                tokens = self.tokenizer.encode(code, add_special_tokens=False)

                # Create chunks with overlap
                for i in range(0, len(tokens), self.max_length // 2):
                    chunk = tokens[i:i + self.max_length]
                    if len(chunk) >= 50:  # Only keep meaningful chunks
                        examples.append({
                            'input_ids': torch.tensor(chunk, dtype=torch.long),
                            'file_path': fp,
                        })
            except Exception:
                continue

        return examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.examples[idx]


class MathDataset(Dataset):
    """
    Specialized Dataset for Mathematical Content.

    Handles LaTeX, equations, and mathematical notation.

    Args:
        file_path: Path to math text file
        tokenizer: Tokenizer to use
        max_length: Maximum sequence length
    """

    def __init__(
        self,
        file_path: str,
        tokenizer,
        max_length: int = 512,
    ):
        self.file_path = file_path
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.examples = self._load_math()

    def _load_math(self) -> List[Dict[str, torch.Tensor]]:
        """Load and tokenize mathematical content."""
        examples = []

        import re

        # LaTeX pattern
        latex_pattern = re.compile(r'\[.*?\]|\$.*?\$|\\\[.*?\\\]')

        with open(self.file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                # Extract LaTeX expressions
                latex_exprs = latex_pattern.findall(line)

                for expr in latex_exprs:
                    # Add math markers
                    math_text = f" <math> {expr} </math> "
                    tokens = self.tokenizer.encode(math_text, add_special_tokens=False)

                    if len(tokens) >= 10:
                        examples.append({
                            'input_ids': torch.tensor(tokens[:self.max_length], dtype=torch.long),
                        })

        return examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.examples[idx]


class DataCollator:
    """
    Data Collator for batching and padding.

    Collates individual examples into batches with
    proper padding and attention masks.

    Args:
        tokenizer: Tokenizer for padding
        pad_to_multiple_of: Pad to multiple of this value
        return_tensors: Return format ('pt' or 'np')
    """

    def __init__(
        self,
        tokenizer,
        pad_to_multiple_of: Optional[int] = None,
        return_tensors: str = 'pt',
    ):
        self.tokenizer = tokenizer
        self.pad_to_multiple_of = pad_to_multiple_of
        self.return_tensors = return_tensors

    def __call__(
        self,
        examples: List[Dict[str, torch.Tensor]]
    ) -> Dict[str, torch.Tensor]:
        """Collate examples into batch."""
        # Stack input IDs
        input_ids = torch.stack([ex['input_ids'] for ex in examples])

        # Create attention mask (1 for real tokens, 0 for padding)
        attention_mask = (input_ids != self.tokenizer.special_tokens['<pad>']).long()

        # Pad if needed
        max_len = input_ids.size(1)
        if self.pad_to_multiple_of:
            pad_len = (self.pad_to_multiple_of - max_len % self.pad_to_multiple_of) % self.pad_to_multiple_of
            if pad_len > 0:
                input_ids = torch.cat([
                    input_ids,
                    torch.full((input_ids.size(0), pad_len), self.tokenizer.special_tokens['<pad>'])
                ], dim=1)
                attention_mask = torch.cat([
                    attention_mask,
                    torch.zeros((attention_mask.size(0), pad_len), dtype=torch.long)
                ], dim=1)

        batch = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': input_ids.clone(),
        }

        return batch


def create_dataset(
    file_path: str,
    tokenizer,
    dataset_type: str = 'text',
    max_length: int = 512,
    stride: int = 128,
    **kwargs
) -> Dataset:
    """
    Factory function to create datasets.

    Args:
        file_path: Path to data
        tokenizer: Tokenizer to use
        dataset_type: Type of dataset ('text', 'code', 'math', 'streaming')
        max_length: Maximum sequence length
        stride: Sliding window stride
        **kwargs: Additional arguments

    Returns:
        Dataset instance
    """
    if dataset_type == 'text':
        return TextDataset(file_path, tokenizer, max_length, stride, **kwargs)
    elif dataset_type == 'code':
        return CodeDataset(file_path, tokenizer, max_length, **kwargs)
    elif dataset_type == 'math':
        return MathDataset(file_path, tokenizer, max_length, **kwargs)
    elif dataset_type == 'streaming':
        if isinstance(file_path, list):
            file_paths = file_path
        else:
            file_paths = [file_path]
        return StreamingTextDataset(file_paths, tokenizer, max_length, **kwargs)
    else:
        raise ValueError(f"Unknown dataset type: {dataset_type}")
