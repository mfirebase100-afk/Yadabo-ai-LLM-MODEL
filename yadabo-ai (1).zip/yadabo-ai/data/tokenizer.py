"""
Yadabo AI - BPE Tokenizer
Custom Byte Pair Encoding tokenizer supporting Arabic and English

This tokenizer implements Byte Pair Encoding (BPE) from scratch,
optimized for handling both Arabic and English text, as well as
programming code.
"""

import os
import re
import json
import pickle
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Set
from collections import Counter, defaultdict
from pathlib import Path


@dataclass
class TokenizerConfig:
    """Configuration for the BPE tokenizer."""
    vocab_size: int = 32000
    min_frequency: int = 2
    special_tokens: Dict[str, int] = field(default_factory=lambda: {
        "<pad>": 0,
        "<bos>": 1,
        "<eos>": 2,
        "<unk>": 3,
        "<mask>": 4,
    })
    byte_fallback: bool = True
    dropout: float = 0.0
    merge_file: Optional[str] = None


class BPETokenizer:
    """
    Byte Pair Encoding Tokenizer.

    Implements BPE tokenization from scratch with support for:
    - Arabic text (with proper normalization)
    - English text
    - Programming code
    - Special tokens handling
    - Byte-level fallback for unknown characters

    Args:
        config: Tokenizer configuration
    """

    def __init__(self, config: Optional[TokenizerConfig] = None):
        self.config = config or TokenizerConfig()

        # Vocabulary
        self.token_to_id: Dict[str, int] = {}
        self.id_to_token: Dict[int, str] = {}
        self.merges: List[Tuple[str, str]] = []

        # Character vocabulary for byte-level encoding
        self.byte_vocab: Dict[int, str] = {}
        self.reverse_byte_vocab: Dict[str, int] = {}

        # Special tokens
        self.special_tokens = self.config.special_tokens.copy()

        # Initialize byte vocabulary
        self._init_byte_vocab()

        # Regex patterns for different text types
        self._init_patterns()

    def _init_byte_vocab(self):
        """Initialize byte-level vocabulary."""
        # Create all 256 byte values as tokens
        for i in range(256):
            self.byte_vocab[i] = chr(i)
            self.reverse_byte_vocab[chr(i)] = i

    def _init_patterns(self):
        """Initialize regex patterns for text processing."""
        # Pattern for splitting text into words for BPE training
        # Handles Arabic, English, numbers, and punctuation
        self.word_pattern = re.compile(r"""
            (?:[a-zA-Z]+) |              # English words
            (?:[\u0600-\u06FF]+) |      # Arabic characters
            (?:[\u0750-\u077F]+) |      # Arabic Extended
            (?:[\u08A0-\u08FF]+) |      # Arabic Extended-A
            (?:[0-9]+\.?[0-9]*) |       # Numbers (with optional decimal)
            (?:[.!?]) |                 # Sentence endings
            (?:[، Bert!?]) |            # Arabic punctuation
            (?:[^\sa-zA-Z0-9\u0600-\u06FF])  # Other characters
        """, re.VERBOSE)

        # Pattern for code tokens - simplified version
        self.code_pattern = re.compile(
            r'\w+|[+\-*/=<>!&|]+|[\(\)\[\]\{\}]|[:;,."\'`]|\\n|\\t|#[^\n]*|"[^"]*"|\'[^\']*\'|\s+|[^\s\w]'
        )

    def train(
        self,
        corpus: List[str],
        vocab_size: Optional[int] = None,
        min_frequency: Optional[int] = None,
        show_progress: bool = True,
    ):
        """
        Train the tokenizer on a corpus.

        Args:
            corpus: List of text strings to train on
            vocab_size: Target vocabulary size
            min_frequency: Minimum frequency for a merge
            show_progress: Whether to show training progress
        """
        vocab_size = vocab_size or self.config.vocab_size
        min_frequency = min_frequency or self.config.min_frequency

        if show_progress:
            print(f"Training BPE tokenizer with target vocab size: {vocab_size}")

        # Step 1: Initialize with character-level vocabulary
        self._init_char_vocab(corpus)

        # Step 2: Count word frequencies
        word_freqs = self._count_word_frequencies(corpus)

        if show_progress:
            print(f"Initial vocabulary size: {len(self.token_to_id)}")
            print(f"Total words to merge: {len(word_freqs)}")

        # Step 3: Iteratively merge most frequent pairs
        num_merges_needed = vocab_size - len(self.token_to_id)

        for i in range(num_merges_needed):
            # Get pair frequencies
            pair_freqs = self._get_pair_frequencies(word_freqs)

            if not pair_freqs:
                break

            # Find most frequent pair
            most_common = max(pair_freqs.items(), key=lambda x: x[1])

            # Check minimum frequency
            if most_common[1] < min_frequency:
                break

            # Merge the pair
            self._merge_pair(most_common[0], word_freqs)

            if show_progress and (i + 1) % 1000 == 0:
                print(f"Merged {i + 1} pairs, vocab size: {len(self.token_to_id)}")

        # Update reverse vocabulary
        self._update_reverse_vocab()

        if show_progress:
            print(f"Training complete. Final vocab size: {len(self.token_to_id)}")

    def _init_char_vocab(self, corpus: List[str]):
        """Initialize vocabulary with characters and special tokens."""
        # Add special tokens first
        self.token_to_id = self.special_tokens.copy()
        self.id_to_token = {v: k for k, v in self.special_tokens.items()}

        # Add all characters from corpus
        chars = set()
        for text in corpus:
            chars.update(text)

        for char in chars:
            if char not in self.token_to_id:
                idx = len(self.token_to_id)
                self.token_to_id[char] = idx
                self.id_to_token[idx] = char

    def _count_word_frequencies(self, corpus: List[str]) -> Dict[str, int]:
        """Count word frequencies in corpus."""
        word_freqs = Counter()

        for text in corpus:
            # Split into words
            words = self.word_pattern.findall(text)

            for word in words:
                # Normalize word (handle case)
                word = word.lower()
                word_freqs[word] += 1

        return dict(word_freqs)

    def _get_pair_frequencies(
        self,
        word_freqs: Dict[str, int]
    ) -> Dict[Tuple[str, str], int]:
        """Get frequencies of all adjacent pairs in words."""
        pair_freqs = defaultdict(int)

        for word, freq in word_freqs.items():
            # Split word into characters
            chars = list(word)
            # Add end-of-word marker
            chars.append('</w>')

            # Count adjacent pairs
            for i in range(len(chars) - 1):
                pair = (chars[i], chars[i + 1])
                pair_freqs[pair] += freq

        return pair_freqs

    def _merge_pair(
        self,
        pair: Tuple[str, str],
        word_freqs: Dict[str, int]
    ):
        """Merge a pair of tokens and update word frequencies."""
        bigram = ''.join(pair)

        # Update vocabulary
        idx = len(self.token_to_id)
        self.token_to_id[bigram] = idx
        self.id_to_token[idx] = bigram
        self.merges.append(pair)

        # Update word frequencies
        for word in list(word_freqs.keys()):
            if pair[1] not in word:
                continue

            new_word = word.replace(pair[0] + pair[1], bigram)
            if new_word != word:
                word_freqs[new_word] = word_freqs.pop(word)

    def _update_reverse_vocab(self):
        """Update reverse vocabulary mapping."""
        self.id_to_token = {v: k for k, v in self.token_to_id.items()}

    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False,
    ) -> List[int]:
        """
        Encode text to token IDs.

        Args:
            text: Input text string
            add_special_tokens: Whether to add special tokens
            max_length: Maximum sequence length
            padding: Whether to pad sequences
            truncation: Whether to truncate sequences

        Returns:
            List of token IDs
        """
        # Tokenize text
        tokens = self._tokenize(text)

        # Convert to IDs
        token_ids = self._convert_tokens_to_ids(tokens)

        # Handle special tokens
        if add_special_tokens:
            token_ids = [self.special_tokens["<bos>"]] + token_ids + [self.special_tokens["<eos>"]]

        # Truncate if needed
        if truncation and max_length:
            if add_special_tokens:
                max_length -= 2
            token_ids = token_ids[:max_length]

        # Pad if needed
        if padding and max_length:
            padding_length = max_length - len(token_ids)
            if add_special_tokens:
                padding_length = max_length - len(token_ids)
            token_ids = token_ids + [self.special_tokens["<pad>"]] * padding_length

        return token_ids

    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text using trained BPE merges."""
        # Split into words
        words = self.word_pattern.findall(text.lower())

        tokens = []
        for word in words:
            # Encode word as characters
            chars = list(word)
            chars.append('</w>')

            # Apply BPE merges
            while len(chars) > 1:
                # Find lowest index pair
                pairs = [(chars[i], chars[i + 1]) for i in range(len(chars) - 1)]

                if not pairs:
                    break

                # Get indices of pairs in merges
                pair_indices = []
                for p in pairs:
                    if p in self.merges:
                        pair_indices.append((self.merges.index(p), p))

                if not pair_indices:
                    break

                # Merge the pair with lowest index
                _, pair_to_merge = min(pair_indices, key=lambda x: x[0])
                chars = self._merge_list(chars, pair_to_merge)

            # Remove end-of-word marker and add to tokens
            if chars and chars[-1] == '</w>':
                chars = chars[:-1]

            tokens.extend(chars if chars else ['</w>'])

        return tokens

    def _merge_list(
        self,
        chars: List[str],
        pair: Tuple[str, str]
    ) -> List[str]:
        """Merge adjacent pair occurrences in a list."""
        result = []
        i = 0
        bigram = ''.join(pair)

        while i < len(chars):
            if i < len(chars) - 1 and chars[i] == pair[0] and chars[i + 1] == pair[1]:
                result.append(bigram)
                i += 2
            else:
                result.append(chars[i])
                i += 1

        return result

    def _convert_tokens_to_ids(self, tokens: List[str]) -> List[int]:
        """Convert tokens to IDs."""
        ids = []
        for token in tokens:
            if token in self.token_to_id:
                ids.append(self.token_to_id[token])
            elif token in self.reverse_byte_vocab:
                # Use byte fallback
                ids.append(self.reverse_byte_vocab[token])
            else:
                # Use unknown token
                ids.append(self.special_tokens["<unk>"])
        return ids

    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True,
        clean_up_tokenization_spaces: bool = True,
    ) -> str:
        """
        Decode token IDs to text.

        Args:
            token_ids: List of token IDs
            skip_special_tokens: Whether to skip special tokens
            clean_up_tokenization_spaces: Whether to clean up spaces

        Returns:
            Decoded text string
        """
        tokens = []

        for token_id in token_ids:
            # Handle special tokens
            if token_id in [v for k, v in self.special_tokens.items()]:
                if skip_special_tokens:
                    continue
                token = self.id_to_token.get(token_id, "<unk>")
            else:
                token = self.id_to_token.get(token_id, self.byte_vocab.get(token_id, "<unk>"))

            tokens.append(token)

        # Join tokens
        text = ''.join(tokens)

        # Clean up
        text = text.replace('</w>', ' ')
        text = text.replace('<unk>', '')

        if clean_up_tokenization_spaces:
            text = re.sub(r' +', ' ', text)
            text = text.strip()

        return text

    def batch_encode(
        self,
        texts: List[str],
        **kwargs
    ) -> Dict[str, List[List[int]]]:
        """Encode a batch of texts."""
        return {
            "input_ids": [self.encode(text, **kwargs) for text in texts]
        }

    def batch_decode(
        self,
        batch_ids: List[List[int]],
        **kwargs
    ) -> List[str]:
        """Decode a batch of token IDs."""
        return [self.decode(ids, **kwargs) for ids in batch_ids]

    def save(self, path: str):
        """
        Save tokenizer to file.

        Args:
            path: Path to save tokenizer
        """
        tokenizer_data = {
            "token_to_id": self.token_to_id,
            "id_to_token": self.id_to_token,
            "merges": self.merges,
            "config": {
                "vocab_size": self.config.vocab_size,
                "min_frequency": self.config.min_frequency,
                "special_tokens": self.config.special_tokens,
                "byte_fallback": self.config.byte_fallback,
            },
            "byte_vocab": self.byte_vocab,
            "reverse_byte_vocab": self.reverse_byte_vocab,
        }

        with open(path, 'w', encoding='utf-8') as f:
            json.dump(tokenizer_data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "BPETokenizer":
        """
        Load tokenizer from file.

        Args:
            path: Path to tokenizer file

        Returns:
            Loaded BPETokenizer instance
        """
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        config = TokenizerConfig(**data["config"])
        tokenizer = cls(config)
        tokenizer.token_to_id = data["token_to_id"]
        tokenizer.id_to_token = {int(k): v for k, v in data["id_to_token"].items()}
        tokenizer.merges = [tuple(m) for m in data["merges"]]
        tokenizer.byte_vocab = data["byte_vocab"]
        tokenizer.reverse_byte_vocab = data["reverse_byte_vocab"]

        return tokenizer

    def __len__(self) -> int:
        """Return vocabulary size."""
        return len(self.token_to_id)

    def __repr__(self) -> str:
        return f"BPETokenizer(vocab_size={len(self)}, num_merges={len(self.merges)})"


def train_tokenizer(
    corpus: List[str],
    output_path: str,
    vocab_size: int = 32000,
    min_frequency: int = 2,
    show_progress: bool = True,
) -> BPETokenizer:
    """
    Train and save a BPE tokenizer.

    Args:
        corpus: Training corpus
        output_path: Path to save tokenizer
        vocab_size: Target vocabulary size
        min_frequency: Minimum frequency for merges
        show_progress: Show training progress

    Returns:
        Trained tokenizer
    """
    config = TokenizerConfig(
        vocab_size=vocab_size,
        min_frequency=min_frequency,
    )

    tokenizer = BPETokenizer(config)
    tokenizer.train(corpus, vocab_size, min_frequency, show_progress)

    os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
    tokenizer.save(output_path)

    return tokenizer


def load_tokenizer(path: str) -> BPETokenizer:
    """Load a trained tokenizer from file."""
    return BPETokenizer.load(path)
