"""
Yadabo AI - DataLoader Utilities
DataLoader creation and management
"""

import os
import math
import torch
from torch.utils.data import DataLoader, random_split, Dataset
from typing import List, Optional, Tuple, Callable


def create_dataloader(
    dataset: Dataset,
    batch_size: int,
    shuffle: bool = True,
    num_workers: int = 4,
    pin_memory: bool = True,
    drop_last: bool = True,
    collate_fn: Optional[Callable] = None,
) -> DataLoader:
    """
    Create a DataLoader with standard settings.

    Args:
        dataset: Dataset to load from
        batch_size: Number of samples per batch
        shuffle: Whether to shuffle data
        num_workers: Number of worker processes
        pin_memory: Pin memory for faster GPU transfer
        drop_last: Drop last incomplete batch
        collate_fn: Custom collate function

    Returns:
        DataLoader instance
    """
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        collate_fn=collate_fn,
    )


def create_train_val_split(
    dataset: Dataset,
    train_ratio: float = 0.9,
    val_ratio: float = 0.1,
    seed: int = 42,
    generator: Optional[torch.Generator] = None,
) -> Tuple[Dataset, Dataset]:
    """
    Split dataset into training and validation sets.

    Args:
        dataset: Dataset to split
        train_ratio: Proportion for training
        val_ratio: Proportion for validation
        seed: Random seed for reproducibility
        generator: PyTorch generator for seeding

    Returns:
        Tuple of (train_dataset, val_dataset)
    """
    assert abs(train_ratio + val_ratio - 1.0) < 1e-6, "Ratios must sum to 1"

    dataset_size = len(dataset)
    train_size = int(dataset_size * train_ratio)
    val_size = dataset_size - train_size

    generator = generator or torch.Generator().manual_seed(seed)

    train_dataset, val_dataset = random_split(
        dataset,
        [train_size, val_size],
        generator=generator,
    )

    return train_dataset, val_dataset


class DistributedDataLoader:
    """
    Wrapper for distributed data loading.

    Handles distributed sampling and epoch-based
    dataset iteration across multiple workers.

    Args:
        dataloader: Base DataLoader
        world_size: Number of distributed processes
        rank: Current process rank
    """

    def __init__(
        self,
        dataloader: DataLoader,
        world_size: int = 1,
        rank: int = 0,
    ):
        self.dataloader = dataloader
        self.world_size = world_size
        self.rank = rank
        self.iter = None

    def __iter__(self):
        """Iterate with distributed sampling."""
        if self.world_size > 1:
            from torch.utils.data.distributed import DistributedSampler
            sampler = DistributedSampler(
                self.dataloader.dataset,
                num_replicas=self.world_size,
                rank=self.rank,
                shuffle=self.dataloader.shuffle,
            )
            self.iter = iter(DataLoader(
                self.dataloader.dataset,
                batch_size=self.dataloader.batch_size,
                sampler=sampler,
                num_workers=self.dataloader.num_workers,
                collate_fn=self.dataloader.collate_fn,
                pin_memory=self.dataloader.pin_memory,
                drop_last=self.dataloader.drop_last,
            ))
        else:
            self.iter = iter(self.dataloader)

        return self

    def __next__(self):
        return next(self.iter)

    def __len__(self):
        return len(self.dataloader)


class PrefetchDataLoader:
    """
    DataLoader with CPU prefetching.

    Uses separate CPU thread to prefetch next batch
    while GPU processes current batch.

    Args:
        dataloader: Base DataLoader
        device: Device to prefetch to
    """

    def __init__(
        self,
        dataloader: DataLoader,
        device: str = 'cuda',
    ):
        self.dataloader = dataloader
        self.device = device
        self.stream = torch.cuda.Stream() if device == 'cuda' else None
        self.iter = None
        self.prefetched_batch = None

    def __iter__(self):
        """Start prefetching."""
        self.iter = iter(self.dataloader)
        self._prefetch()
        return self

    def _prefetch(self):
        """Prefetch next batch to device."""
        try:
            batch = next(self.iter)
            if self.stream:
                with torch.cuda.stream(self.stream):
                    self.prefetched_batch = {
                        k: v.to(self.device, non_blocking=True)
                        if isinstance(v, torch.Tensor) else v
                        for k, v in batch.items()
                    }
            else:
                self.prefetched_batch = batch
        except StopIteration:
            self.prefetched_batch = None

    def __next__(self):
        """Return prefetched batch and prefetch next."""
        if self.prefetched_batch is None:
            raise StopIteration

        batch = self.prefetched_batch
        self._prefetch()
        return batch

    def __len__(self):
        return len(self.dataloader)


class DataLoaderFactory:
    """
    Factory for creating DataLoaders with various configurations.

    Supports creating loaders for different training scenarios
    including single GPU, multi-GPU, and distributed training.
    """

    def __init__(
        self,
        tokenizer,
        max_length: int = 512,
        pad_to_multiple_of: Optional[int] = 8,
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_to_multiple_of = pad_to_multiple_of

        # Create collator
        from .dataset import DataCollator
        self.collator = DataCollator(
            tokenizer=tokenizer,
            pad_to_multiple_of=pad_to_multiple_of,
        )

    def create_train_loader(
        self,
        dataset: Dataset,
        batch_size: int,
        num_workers: int = 4,
        shuffle: bool = True,
        prefetch: bool = False,
    ) -> DataLoader:
        """Create training DataLoader."""
        loader = create_dataloader(
            dataset=dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=num_workers,
            collate_fn=self.collator,
            drop_last=True,
        )

        if prefetch:
            loader = PrefetchDataLoader(loader)

        return loader

    def create_eval_loader(
        self,
        dataset: Dataset,
        batch_size: int,
        num_workers: int = 2,
    ) -> DataLoader:
        """Create evaluation DataLoader."""
        return create_dataloader(
            dataset=dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            collate_fn=self.collator,
            drop_last=False,
        )

    def create_distributed_loader(
        self,
        dataset: Dataset,
        batch_size: int,
        num_workers: int = 4,
        world_size: int = 1,
        rank: int = 0,
    ) -> DistributedDataLoader:
        """Create distributed DataLoader."""
        loader = create_dataloader(
            dataset=dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            collate_fn=self.collator,
            drop_last=True,
        )

        return DistributedDataLoader(loader, world_size, rank)


def get_dataloader_stats(dataloader: DataLoader) -> dict:
    """
    Get statistics about a DataLoader.

    Args:
        dataloader: DataLoader to analyze

    Returns:
        Dictionary with statistics
    """
    total_samples = len(dataloader.dataset)
    batch_size = dataloader.batch_size
    num_batches = len(dataloader)
    last_batch_size = total_samples % batch_size

    return {
        'total_samples': total_samples,
        'batch_size': batch_size,
        'num_batches': num_batches,
        'last_batch_size': last_batch_size if last_batch_size > 0 else batch_size,
        'num_workers': dataloader.num_workers,
        'pin_memory': dataloader.pin_memory,
    }


def estimate_dataset_size_gb(
    dataset: Dataset,
    batch_size: int,
    num_samples: Optional[int] = None,
) -> float:
    """
    Estimate dataset size in gigabytes.

    Args:
        dataset: Dataset to estimate
        batch_size: Batch size for loading
        num_samples: Number of samples to sample (None = all)

    Returns:
        Estimated size in GB
    """
    num_samples = num_samples or len(dataset)

    # Sample a few batches
    loader = DataLoader(dataset, batch_size=batch_size)

    sample_size = min(batch_size * 10, num_samples)
    total_bytes = 0

    for i, batch in enumerate(loader):
        if i * batch_size >= sample_size:
            break
        for v in batch.values():
            if isinstance(v, torch.Tensor):
                total_bytes += v.element_size() * v.nelement()

    # Extrapolate
    bytes_per_sample = total_bytes / (i * batch_size)
    total_bytes_estimate = bytes_per_sample * num_samples

    return total_bytes_estimate / (1024 ** 3)
