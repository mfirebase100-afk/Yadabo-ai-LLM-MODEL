"""
Yadabo AI - Transformer Configuration
Central configuration management for model architecture
"""

from dataclasses import dataclass, field
from typing import Optional, List
import yaml
from pathlib import Path


@dataclass
class TransformerConfig:
    """
    Configuration class for the Transformer language model.

    Attributes:
        vocab_size: Size of the vocabulary
        max_seq_len: Maximum sequence length
        d_model: Dimension of the model (embedding size)
        n_heads: Number of attention heads
        n_layers: Number of transformer layers
        d_ff: Dimension of the feed-forward network
        dropout: Dropout probability
        activation: Activation function (gelu or relu)
        layer_norm_eps: Epsilon for layer normalization
        pad_token_id: Token ID used for padding
        bos_token_id: Token ID for beginning of sequence
        eos_token_id: Token ID for end of sequence
        tie_weights: Whether to tie input and output embeddings
        gradient_checkpointing: Whether to use gradient checkpointing
    """

    # Vocabulary and sequence
    vocab_size: int = 32000
    max_seq_len: int = 512

    # Model dimensions
    d_model: int = 512
    n_heads: int = 8
    n_layers: int = 6
    d_ff: int = 2048

    # Regularization
    dropout: float = 0.1
    activation: str = "gelu"
    layer_norm_eps: float = 1e-12

    # Special tokens
    pad_token_id: int = 0
    bos_token_id: int = 1
    eos_token_id: int = 2

    # Optimization
    tie_weights: bool = False
    gradient_checkpointing: bool = False

    # Model variant names for easy reference
    @property
    def model_size(self) -> str:
        """Return model size classification."""
        if self.d_model >= 1024:
            return "large"
        elif self.d_model >= 768:
            return "medium"
        else:
            return "small"

    def save(self, path: str) -> None:
        """Save configuration to YAML file."""
        config_dict = {
            "vocab_size": self.vocab_size,
            "max_seq_len": self.max_seq_len,
            "d_model": self.d_model,
            "n_heads": self.n_heads,
            "n_layers": self.n_layers,
            "d_ff": self.d_ff,
            "dropout": self.dropout,
            "activation": self.activation,
            "layer_norm_eps": self.layer_norm_eps,
            "pad_token_id": self.pad_token_id,
            "bos_token_id": self.bos_token_id,
            "eos_token_id": self.eos_token_id,
            "tie_weights": self.tie_weights,
            "gradient_checkpointing": self.gradient_checkpointing,
        }
        with open(path, 'w', encoding='utf-8') as f:
            yaml.dump(config_dict, f, default_flow_style=False)

    @classmethod
    def load(cls, path: str) -> 'TransformerConfig':
        """Load configuration from YAML file."""
        with open(path, 'r', encoding='utf-8') as f:
            config_dict = yaml.safe_load(f)
        return cls(**config_dict)

    @classmethod
    def from_dict(cls, config_dict: dict) -> 'TransformerConfig':
        """Create configuration from dictionary."""
        return cls(**config_dict)

    def to_dict(self) -> dict:
        """Convert configuration to dictionary."""
        return {
            "vocab_size": self.vocab_size,
            "max_seq_len": self.max_seq_len,
            "d_model": self.d_model,
            "n_heads": self.n_heads,
            "n_layers": self.n_layers,
            "d_ff": self.d_ff,
            "dropout": self.dropout,
            "activation": self.activation,
            "layer_norm_eps": self.layer_norm_eps,
            "pad_token_id": self.pad_token_id,
            "bos_token_id": self.bos_token_id,
            "eos_token_id": self.eos_token_id,
            "tie_weights": self.tie_weights,
            "gradient_checkpointing": self.gradient_checkpointing,
        }

    @classmethod
    def small_arabic_english(cls) -> 'TransformerConfig':
        """
        Small model configuration optimized for testing.
        Suitable for single GPU with ~4GB VRAM.
        """
        return cls(
            vocab_size=25000,
            max_seq_len=256,
            d_model=256,
            n_heads=4,
            n_layers=4,
            d_ff=1024,
            dropout=0.1,
        )

    @classmethod
    def medium_arabic_english(cls) -> 'TransformerConfig':
        """
        Medium model configuration for development.
        Suitable for single GPU with ~8GB VRAM.
        """
        return cls(
            vocab_size=30000,
            max_seq_len=512,
            d_model=512,
            n_heads=8,
            n_layers=6,
            d_ff=2048,
            dropout=0.1,
        )

    @classmethod
    def large_arabic_english(cls) -> 'TransformerConfig':
        """
        Large model configuration for production training.
        Designed for Google Cloud A100 or similar GPUs.
        """
        return cls(
            vocab_size=32000,
            max_seq_len=1024,
            d_model=768,
            n_heads=12,
            n_layers=12,
            d_ff=3072,
            dropout=0.1,
        )

    @classmethod
    def xlarge_arabic_english(cls) -> 'TransformerConfig':
        """
        Extra large model for maximum performance.
        Requires multiple A100 GPUs.
        """
        return cls(
            vocab_size=32000,
            max_seq_len=2048,
            d_model=1024,
            n_heads=16,
            n_layers=24,
            d_ff=4096,
            dropout=0.1,
            gradient_checkpointing=True,
        )


# Preset configurations for common use cases
PRESETS = {
    "test": TransformerConfig.small_arabic_english,
    "dev": TransformerConfig.medium_arabic_english,
    "prod": TransformerConfig.large_arabic_english,
    "xprod": TransformerConfig.xlarge_arabic_english,
}


def get_preset_config(preset: str) -> TransformerConfig:
    """Get a preset configuration by name."""
    if preset not in PRESETS:
        raise ValueError(f"Unknown preset: {preset}. Available: {list(PRESETS.keys())}")
    return PRESETS[preset]()
