"""
Yadabo AI - Embedding Layers
Token embeddings and positional encoding implementations
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class TokenEmbedding(nn.Module):
    """
    Token embedding layer with learned embeddings.

    Transforms token IDs into dense vectors of size d_model.
    Includes optional layer normalization.

    Args:
        vocab_size: Size of the vocabulary
        d_model: Dimension of the embedding vectors
        padding_idx: Token ID used for padding (will have zero embeddings)
        dropout: Dropout probability
    """

    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        padding_idx: int = 0,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.padding_idx = padding_idx

        # Token embeddings
        self.token_embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=d_model,
            padding_idx=padding_idx,
        )

        # Dropout layer
        self.dropout = nn.Dropout(p=dropout)

        # Initialize weights
        self._init_weights()

    def _init_weights(self):
        """Initialize token embedding weights."""
        nn.init.normal_(self.token_embedding.weight, mean=0, std=self.d_model ** -0.5)

        # Keep padding embeddings at zero
        with torch.no_grad():
            self.token_embedding.weight[self.padding_idx].zero_()

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        """
        Transform token IDs to embeddings.

        Args:
            token_ids: Tensor of shape (batch_size, seq_len) containing token IDs

        Returns:
            Embeddings of shape (batch_size, seq_len, d_model)
        """
        embeddings = self.token_embedding(token_ids)
        embeddings = embeddings * math.sqrt(self.d_model)
        embeddings = self.dropout(embeddings)
        return embeddings

    def get_output_layer(self) -> Optional[nn.Linear]:
        """Return the output projection layer if tie_weights is True."""
        return self.token_embedding


class PositionalEncoding(nn.Module):
    """
    Positional encoding layer using sine and cosine functions.

    Implements the original Transformer positional encoding from
    "Attention Is All You Need" paper.

    Args:
        d_model: Dimension of the model
        max_len: Maximum sequence length
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        max_len: int = 5000,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.max_len = max_len

        # Create positional encoding
        pe = self._create_positional_encoding(max_len, d_model)
        self.register_buffer('pe', pe)

        # Dropout layer
        self.dropout = nn.Dropout(p=dropout)

    def _create_positional_encoding(
        self,
        max_len: int,
        d_model: int
    ) -> torch.Tensor:
        """
        Create sinusoidal positional encoding.

        Uses the formula:
        PE(pos, 2i) = sin(pos / 10000^(2i/d_model))
        PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))

        Args:
            max_len: Maximum sequence length
            d_model: Dimension of the model

        Returns:
            Positional encoding tensor of shape (1, max_len, d_model)
        """
        # Create position indices
        position = torch.arange(max_len).unsqueeze(1)

        # Create dimension indices
        div_term = torch.exp(
            torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model)
        )

        # Calculate sinusoidal encoding
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)

        return pe

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Add positional encoding to input embeddings.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)

        Returns:
            embeddings with positional encoding added
        """
        seq_len = x.size(1)

        # Slice positional encoding to match sequence length
        pe = self.pe[:, :seq_len, :].expand(x.size(0), -1, -1)

        # Add positional encoding
        x = x + pe

        return self.dropout(x)


class LearnedPositionalEncoding(nn.Module):
    """
    Learned positional embedding layer.

    Alternative to sinusoidal positional encoding where each position
    has a learned embedding.

    Args:
        max_len: Maximum sequence length
        d_model: Dimension of the model
        dropout: Dropout probability
    """

    def __init__(
        self,
        max_len: int,
        d_model: int,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.max_len = max_len
        self.d_model = d_model

        # Learned position embeddings
        self.position_embedding = nn.Embedding(max_len, d_model)

        # Dropout layer
        self.dropout = nn.Dropout(p=dropout)

        # Initialize weights
        self._init_weights()

    def _init_weights(self):
        """Initialize position embedding weights."""
        nn.init.normal_(self.position_embedding.weight, mean=0, std=self.d_model ** -0.5)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Add learned positional encoding to input embeddings.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)

        Returns:
            Embeddings with positional encoding added
        """
        batch_size, seq_len, _ = x.size()

        # Create position indices
        positions = torch.arange(seq_len, device=x.device).unsqueeze(0).expand(batch_size, -1)

        # Get position embeddings
        pos_embeddings = self.position_embedding(positions)

        # Add positional encoding
        x = x + pos_embeddings

        return self.dropout(x)


class RotaryPositionalEncoding(nn.Module):
    """
    Rotary Positional Encoding (RoPE).

    Implements rotary embeddings that rotate the query and key vectors
    based on their positions. More efficient than standard positional encoding
    and used in models like GPT-NeoX and LLaMA.

    Args:
        d_model: Dimension of the model
        max_seq_len: Maximum sequence length
        base: Base for the rotation angles
    """

    def __init__(
        self,
        d_model: int,
        max_seq_len: int = 2048,
        base: float = 10000.0,
    ):
        super().__init__()
        self.d_model = d_model
        self.max_seq_len = max_seq_len
        self.base = base

        # Precompute inverse frequencies
        inv_freq = 1.0 / (base ** (torch.arange(0, d_model, 2).float() / d_model))
        self.register_buffer('inv_freq', inv_freq)

        # Precompute cos and sin for efficiency
        self._precompute()

    def _precompute(self):
        """Precompute cos and sin values for all positions."""
        t = torch.arange(self.max_seq_len, device=self.inv_freq.device).type_as(self.inv_freq)
        freqs = torch.einsum('i,j->ij', t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        self.register_buffer('cos_cached', emb.cos())
        self.register_buffer('sin_cached', emb.sin())

    def rotate_half(self, x: torch.Tensor) -> torch.Tensor:
        """
        Rotate half of the tensor.

        Args:
            x: Input tensor of shape (..., d_model)

        Returns:
            Rotated tensor
        """
        x1 = x[..., :x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2:]
        return torch.cat((-x2, x1), dim=-1)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        seq_len: Optional[int] = None,
    ) -> tuple:
        """
        Apply rotary positional encoding to query and key tensors.

        Args:
            q: Query tensor of shape (batch_size, n_heads, seq_len, head_dim)
            k: Key tensor of shape (batch_size, n_heads, seq_len, head_dim)
            seq_len: Sequence length (uses cached value if None)

        Returns:
            Tuple of (rotated_q, rotated_k)
        """
        if seq_len is None:
            seq_len = q.size(2)

        # Get cos and sin for the sequence
        cos = self.cos_cached[:seq_len].unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, d_model)
        sin = self.sin_cached[:seq_len].unsqueeze(0).unsqueeze(0)

        # Apply rotation
        q_embed = (q * cos) + (self.rotate_half(q) * sin)
        k_embed = (k * cos) + (self.rotate_half(k) * sin)

        return q_embed, k_embed


def create_positional_encoding(
    encoding_type: str,
    d_model: int,
    max_len: int,
    dropout: float = 0.1,
) -> nn.Module:
    """
    Factory function to create positional encoding layer.

    Args:
        encoding_type: Type of positional encoding ('sinusoidal', 'learned', 'rotary')
        d_model: Dimension of the model
        max_len: Maximum sequence length
        dropout: Dropout probability

    Returns:
        Positional encoding module
    """
    if encoding_type == "sinusoidal":
        return PositionalEncoding(d_model, max_len, dropout)
    elif encoding_type == "learned":
        return LearnedPositionalEncoding(max_len, d_model, dropout)
    elif encoding_type == "rotary":
        return RotaryPositionalEncoding(d_model, max_len)
    else:
        raise ValueError(f"Unknown positional encoding type: {encoding_type}")
