"""
Yadabo AI - Transformer Language Model
Complete Transformer architecture implementation
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Union
from dataclasses import dataclass

from .config import TransformerConfig
from .embeddings import TokenEmbedding, PositionalEncoding
from .attention import MultiHeadAttention
from .feedforward import FeedForward
from .layers import TransformerBlock, LayerNorm


class TransformerLM(nn.Module):
    """
    Complete Transformer-based Language Model.

    This is an autoregressive Transformer decoder that can be trained
    on language modeling tasks and used for text generation.

    Architecture:
        Input Tokens -> Token Embeddings -> Positional Encoding
                    -> [Transformer Block] x N
                    -> LayerNorm -> Linear -> Output

    Args:
        config: Transformer configuration object

    Example:
        >>> config = TransformerConfig(
        ...     vocab_size=32000,
        ...     d_model=512,
        ...     n_heads=8,
        ...     n_layers=6,
        ...     d_ff=2048,
        ... )
        >>> model = TransformerLM(config)
        >>> tokens = torch.randint(0, 32000, (2, 100))  # (batch, seq)
        >>> logits = model(tokens)  # (batch, seq, vocab)
        >>> loss = model.compute_loss(logits, tokens)
    """

    def __init__(self, config: TransformerConfig):
        super().__init__()
        self.config = config

        # Validate configuration
        self._validate_config()

        # Token embeddings
        self.token_embedding = TokenEmbedding(
            vocab_size=config.vocab_size,
            d_model=config.d_model,
            padding_idx=config.pad_token_id,
            dropout=config.dropout,
        )

        # Positional encoding
        self.positional_encoding = PositionalEncoding(
            d_model=config.d_model,
            max_len=config.max_seq_len,
            dropout=config.dropout,
        )

        # Transformer blocks
        self.layers = nn.ModuleList([
            TransformerBlock(
                d_model=config.d_model,
                n_heads=config.n_heads,
                d_ff=config.d_ff,
                dropout=config.dropout,
                activation=config.activation,
            )
            for _ in range(config.n_layers)
        ])

        # Final layer norm
        self.final_norm = LayerNorm(config.d_model, eps=config.layer_norm_eps)

        # Output projection
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)

        # Tie weights between embedding and output if specified
        if config.tie_weights:
            self.lm_head.weight = self.token_embedding.token_embedding.weight

        # Initialize weights
        self._init_weights()

        # Gradient checkpointing
        self.use_checkpoint = config.gradient_checkpointing
        if self.use_checkpoint:
            self._enable_gradient_checkpointing()

    def _validate_config(self):
        """Validate configuration parameters."""
        if self.config.d_model % self.config.n_heads != 0:
            raise ValueError(
                f"d_model ({self.config.d_model}) must be divisible by "
                f"n_heads ({self.config.n_heads})"
            )
        if self.config.d_model <= 0:
            raise ValueError(f"d_model must be positive, got {self.config.d_model}")
        if self.config.n_layers <= 0:
            raise ValueError(f"n_layers must be positive, got {self.config.n_layers}")

    def _init_weights(self):
        """Initialize model weights using appropriate strategies."""
        # Initialize linear layers
        for module in self.modules():
            if isinstance(module, nn.Linear):
                # Use normal initialization for projection layers
                if module in [self.lm_head]:
                    nn.init.normal_(module.weight, mean=0, std=0.02)
                else:
                    nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def _enable_gradient_checkpointing(self):
        """Enable gradient checkpointing for memory efficiency."""
        for i, layer in enumerate(self.layers):
            layer.checkpoint = torch.utils.checkpoint.checkpoint

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ) -> Union[Tuple[torch.Tensor, torch.Tensor], torch.Tensor]:
        """
        Forward pass through the Transformer.

        Args:
            input_ids: Input token IDs of shape (batch_size, seq_len)
            attention_mask: Optional attention mask
            labels: Optional labels for computing loss

        Returns:
            If labels provided: Tuple of (loss, logits)
            Otherwise: Logits tensor of shape (batch_size, seq_len, vocab_size)
        """
        batch_size, seq_len = input_ids.size()

        # Check sequence length
        if seq_len > self.config.max_seq_len:
            raise ValueError(
                f"Input sequence length ({seq_len}) exceeds maximum "
                f"({self.config.max_seq_len})"
            )

        # Get token embeddings
        hidden_states = self.token_embedding(input_ids)

        # Add positional encoding
        hidden_states = self.positional_encoding(hidden_states)

        # Apply transformer layers
        for layer in self.layers:
            # Use gradient checkpointing if enabled
            if self.use_checkpoint and self.training:
                hidden_states = torch.utils.checkpoint.checkpoint(
                    layer,
                    hidden_states,
                    attention_mask,
                    True,
                )
            else:
                hidden_states = layer(
                    hidden_states,
                    attention_mask=attention_mask,
                    is_causal=True,
                )

        # Apply final layer norm
        hidden_states = self.final_norm(hidden_states)

        # Project to vocabulary
        logits = self.lm_head(hidden_states)

        # Compute loss if labels provided
        loss = None
        if labels is not None:
            loss = self.compute_loss(logits, labels)

        if loss is not None:
            return loss, logits
        return logits

    def compute_loss(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor,
        ignore_index: int = -100,
    ) -> torch.Tensor:
        """
        Compute cross-entropy loss for language modeling.

        Args:
            logits: Model output logits of shape (batch_size, seq_len, vocab_size)
            labels: Target token IDs of shape (batch_size, seq_len)
            ignore_index: Token ID to ignore in loss computation

        Returns:
            Loss tensor (scalar)
        """
        # Shift logits and labels for next-token prediction
        # logits: (batch, seq, vocab) -> (batch, seq-1, vocab)
        # labels: (batch, seq) -> (batch, seq-1)
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()

        # Flatten for cross-entropy
        loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            ignore_index=ignore_index,
        )

        return loss

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        repetition_penalty: float = 1.0,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Generate text using autoregressive decoding.

        Args:
            input_ids: Starting token IDs of shape (batch_size, seq_len)
            max_new_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (higher = more random)
            top_k: If set, sample from top k tokens
            top_p: If set, nucleus sampling threshold
            repetition_penalty: Penalty for repeating tokens
            attention_mask: Optional attention mask

        Returns:
            Generated token IDs including input
        """
        self.eval()

        batch_size = input_ids.size(0)
        device = input_ids.device
        seq_len = input_ids.size(1)

        for _ in range(max_new_tokens):
            # Crop to max_seq_len if needed
            if seq_len > self.config.max_seq_len:
                input_ids = input_ids[:, -self.config.max_seq_len:]
                seq_len = self.config.max_seq_len

            # Forward pass
            logits = self.forward(input_ids)
            logits = logits[:, -1, :] / temperature  # (batch, vocab)

            # Apply repetition penalty
            if repetition_penalty != 1.0:
                for i in range(batch_size):
                    for j, token_id in enumerate(input_ids[i]):
                        logits[i, token_id] /= repetition_penalty

            # Apply top-k filtering
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = float('-inf')

            # Apply top-p (nucleus) filtering
            if top_p is not None:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cumsum_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

                # Remove tokens with cumulative probability above threshold
                sorted_indices_to_remove = cumsum_probs > top_p
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0

                for i in range(batch_size):
                    indices_to_remove = sorted_indices[i][sorted_indices_to_remove[i]]
                    logits[i, indices_to_remove] = float('-inf')

            # Sample from distribution
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)

            # Append to sequence
            input_ids = torch.cat([input_ids, next_token], dim=1)
            seq_len += 1

        return input_ids

    @torch.no_grad()
    def beam_search(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 100,
        beam_size: int = 5,
        length_penalty: float = 1.0,
    ) -> torch.Tensor:
        """
        Generate text using beam search.

        Args:
            input_ids: Starting token IDs
            max_new_tokens: Maximum number of tokens to generate
            beam_size: Number of beams to use
            length_penalty: Penalty for sequence length

        Returns:
            Best generated sequence
        """
        self.eval()

        device = input_ids.device
        batch_size = input_ids.size(0)

        # Initialize beams
        beam_scores = torch.zeros(batch_size, beam_size, device=device)
        beam_scores[:, 1:] = -1e9

        beams = input_ids.unsqueeze(1).expand(-1, beam_size, -1)
        beams = beams.reshape(batch_size * beam_size, -1)

        completed = [None] * batch_size
        finished = torch.zeros(batch_size * beam_size, dtype=torch.bool, device=device)

        for step in range(max_new_tokens):
            logits = self.forward(beams)
            logits = logits[:, -1, :]  # (batch * beam, vocab)

            # Apply length penalty
            log_probs = F.log_softmax(logits, dim=-1)

            if step == 0:
                log_probs = log_probs.view(batch_size, beam_size, -1)
                next_scores = beam_scores.unsqueeze(-1) + log_probs
            else:
                next_scores = beam_scores.unsqueeze(-1) + log_probs.unsqueeze(1)
                next_scores = next_scores.view(batch_size, beam_size * logits.size(-1))

            # Get top beam_size candidates
            next_scores, next_tokens = next_scores.topk(beam_size, dim=-1)

            # Reshape and select beams
            beam_idx = next_tokens // logits.size(-1)
            next_tokens = next_tokens % logits.size(-1)

            # Update beams
            new_beams = []
            for b in range(batch_size):
                best_beam = next_scores[b].argmax()
                beam_id = beam_idx[b, best_beam]
                token = next_tokens[b, best_beam]

                if step == 0:
                    beams[b] = torch.cat([input_ids[b], token.unsqueeze(0)])
                else:
                    beams[b] = torch.cat([beams[b * beam_size + beam_id], token.unsqueeze(0)])

                beam_scores[b] = next_scores[b]

            # Check for completion
            for b in range(batch_size):
                if completed[b] is None and next_tokens[b, 0] == self.config.eos_token_id:
                    completed[b] = beams[b]
                    beam_scores[b] = -1e9

            if all(c is not None for c in completed):
                break

        # Return completed sequences or best beams
        for b in range(batch_size):
            if completed[b] is None:
                completed[b] = beams[b * beam_size]

        return torch.stack(completed)

    def get_num_parameters(self, trainable_only: bool = False) -> int:
        """
        Get the number of parameters in the model.

        Args:
            trainable_only: If True, count only trainable parameters

        Returns:
            Number of parameters
        """
        if trainable_only:
            return sum(p.numel() for p in self.parameters() if p.requires_grad)
        return sum(p.numel() for p in self.parameters())

    def get_model_size(self) -> dict:
        """
        Get detailed model size information.

        Returns:
            Dictionary with parameter counts and memory estimates
        """
        total = self.get_num_parameters()
        trainable = self.get_num_parameters(trainable_only=True)

        # Estimate memory in bytes (assuming float32)
        memory_bytes = total * 4
        memory_mb = memory_bytes / (1024 ** 2)
        memory_gb = memory_bytes / (1024 ** 3)

        return {
            "total_parameters": total,
            "trainable_parameters": trainable,
            "non_trainable_parameters": total - trainable,
            "memory_mb": memory_mb,
            "memory_gb": memory_gb,
            "vocab_size": self.config.vocab_size,
            "d_model": self.config.d_model,
            "n_layers": self.config.n_layers,
            "n_heads": self.config.n_heads,
            "d_ff": self.config.d_ff,
            "max_seq_len": self.config.max_seq_len,
        }

    def save(self, path: str, optimizer_state: Optional[dict] = None, **kwargs):
        """
        Save model checkpoint.

        Args:
            path: Path to save checkpoint
            optimizer_state: Optional optimizer state dict
            **kwargs: Additional metadata to save
        """
        checkpoint = {
            "model_state_dict": self.state_dict(),
            "config": self.config.to_dict(),
        }

        if optimizer_state is not None:
            checkpoint["optimizer_state_dict"] = optimizer_state

        checkpoint.update(kwargs)

        torch.save(checkpoint, path)

    @classmethod
    def load(cls, path: str, device: str = "cpu") -> Tuple["TransformerLM", dict]:
        """
        Load model from checkpoint.

        Args:
            path: Path to checkpoint
            device: Device to load model to

        Returns:
            Tuple of (model, checkpoint metadata)
        """
        checkpoint = torch.load(path, map_location=device)

        config = TransformerConfig.from_dict(checkpoint["config"])
        model = cls(config)
        model.load_state_dict(checkpoint["model_state_dict"])
        model.to(device)

        metadata = {k: v for k, v in checkpoint.items() if k not in ["model_state_dict", "config"]}

        return model, metadata

    def enable_gradient_checkpointing(self):
        """Enable gradient checkpointing for training."""
        self.use_checkpoint = True
        for layer in self.layers:
            layer.checkpoint = torch.utils.checkpoint.checkpoint

    def disable_gradient_checkpointing(self):
        """Disable gradient checkpointing."""
        self.use_checkpoint = False
        for layer in self.layers:
            if hasattr(layer, 'checkpoint'):
                delattr(layer, 'checkpoint')


def create_transformer(config: Union[TransformerConfig, dict, str]) -> TransformerLM:
    """
    Factory function to create a Transformer model.

    Args:
        config: TransformerConfig, dict, or preset name string

    Returns:
        TransformerLM instance
    """
    if isinstance(config, str):
        # Load preset configuration
        from .config import get_preset_config
        config = get_preset_config(config)
    elif isinstance(config, dict):
        config = TransformerConfig.from_dict(config)

    if not isinstance(config, TransformerConfig):
        raise TypeError(f"config must be TransformerConfig, dict, or str, got {type(config)}")

    return TransformerLM(config)
