"""
Yadabo AI - Transformer Layers
Building blocks for the Transformer architecture
"""

import torch
import torch.nn as nn
from typing import Optional
from .attention import MultiHeadAttention
from .feedforward import FeedForward


class LayerNorm(nn.Module):
    """
    Layer Normalization with optional elementwise affine transformation.

    Applies normalization over the last dimension:
    y = (x - mean) / (std + eps) * gamma + beta

    Args:
        d_model: Dimension of the input
        eps: Epsilon for numerical stability
        bias: Whether to include bias term
    """

    def __init__(
        self,
        d_model: int,
        eps: float = 1e-12,
        bias: bool = True,
    ):
        super().__init__()
        self.d_model = d_model
        self.eps = eps

        # Learnable parameters
        self.weight = nn.Parameter(torch.ones(d_model))
        self.bias = nn.Parameter(torch.zeros(d_model)) if bias else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Apply layer normalization.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)

        Returns:
            Normalized tensor of same shape
        """
        # Compute mean and variance over last dimension
        mean = x.mean(dim=-1, keepdim=True)
        var = x.var(dim=-1, keepdim=True, unbiased=False)

        # Normalize
        x = (x - mean) / torch.sqrt(var + self.eps)

        # Scale and shift
        x = x * self.weight
        if self.bias is not None:
            x = x + self.bias

        return x


class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization (RMSNorm).

    Simplified normalization that only uses RMS, often used in
    modern LLMs like LLaMA.

    Args:
        d_model: Dimension of the input
        eps: Epsilon for numerical stability
    """

    def __init__(
        self,
        d_model: int,
        eps: float = 1e-6,
    ):
        super().__init__()
        self.d_model = d_model
        self.eps = eps

        self.weight = nn.Parameter(torch.ones(d_model))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply RMS normalization."""
        # Compute RMS
        rms = torch.rsqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)

        # Normalize and scale
        return x * rms * self.weight


class PreNormResidual(nn.Module):
    """
    Pre-Normalization with Residual Connection.

    Applies layer norm before the sublayer, then adds residual connection.
    Used in the original Transformer and many modern variants.

    Architecture:
        x -> LayerNorm -> Sublayer -> Dropout -> + x

    Args:
        d_model: Dimension of the model
        sublayer: The sublayer to apply (attention or FFN)
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        sublayer: nn.Module,
        dropout: float = 0.1,
        norm_type: str = "layer",  # 'layer' or 'rms'
    ):
        super().__init__()
        self.norm = LayerNorm(d_model) if norm_type == "layer" else RMSNorm(d_model)
        self.sublayer = sublayer
        self.dropout = nn.Dropout(p=dropout)

    def forward(
        self,
        x: torch.Tensor,
        *args,
        **kwargs
    ) -> torch.Tensor:
        """Forward pass with pre-norm and residual."""
        # Apply norm, sublayer, dropout, and residual
        normed = self.norm(x)
        output = self.sublayer(normed, *args, **kwargs)

        # Handle tuple returns (attention returns weights)
        if isinstance(output, tuple):
            output = output[0]

        return x + self.dropout(output)


class PostNormResidual(nn.Module):
    """
    Post-Normalization with Residual Connection.

    Applies residual first, then layer norm. Used in some
    modern Transformer variants.

    Architecture:
        x -> Sublayer -> Dropout -> + x -> LayerNorm

    Args:
        d_model: Dimension of the model
        sublayer: The sublayer to apply
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        sublayer: nn.Module,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.sublayer = sublayer
        self.dropout = nn.Dropout(p=dropout)
        self.norm = LayerNorm(d_model)

    def forward(
        self,
        x: torch.Tensor,
        *args,
        **kwargs
    ) -> torch.Tensor:
        """Forward pass with post-norm and residual."""
        output = x + self.dropout(self.sublayer(x, *args, **kwargs))
        if isinstance(output, tuple):
            output = self.norm(output[0]), output[1]
        else:
            output = self.norm(output)
        return output


class TransformerBlock(nn.Module):
    """
    Complete Transformer Block.

    Implements a single layer of the Transformer encoder with:
    - Multi-head self-attention
    - Feed-forward network
    - Pre-normalization and residual connections

    Architecture:
        Input -> [Attention -> FFN] x N layers

    Args:
        d_model: Dimension of the model
        n_heads: Number of attention heads
        d_ff: Hidden dimension of FFN
        dropout: Dropout probability
        activation: Activation function for FFN
        attn_dropout: Dropout for attention weights
        pre_norm: Whether to use pre-norm (True) or post-norm (False)
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        dropout: float = 0.1,
        activation: str = "gelu",
        attn_dropout: float = 0.0,
        pre_norm: bool = True,
        norm_type: str = "layer",
    ):
        super().__init__()
        self.pre_norm = pre_norm

        # Multi-head attention
        self.attention = MultiHeadAttention(
            d_model=d_model,
            n_heads=n_heads,
            dropout=attn_dropout,
        )

        # Feed-forward network
        self.feed_forward = FeedForward(
            d_model=d_model,
            d_ff=d_ff,
            dropout=dropout,
            activation=activation,
        )

        if pre_norm:
            # Pre-norm architecture
            self.norm1 = LayerNorm(d_model) if norm_type == "layer" else RMSNorm(d_model)
            self.norm2 = LayerNorm(d_model) if norm_type == "layer" else RMSNorm(d_model)
            self.dropout = nn.Dropout(p=dropout)
        else:
            # Post-norm architecture
            self.norm1 = LayerNorm(d_model)
            self.norm2 = LayerNorm(d_model)
            self.dropout1 = nn.Dropout(p=dropout)
            self.dropout2 = nn.Dropout(p=dropout)

    def forward(
        self,
        x: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        is_causal: bool = True,
    ) -> torch.Tensor:
        """
        Forward pass through transformer block.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)
            attention_mask: Optional attention mask
            is_causal: Whether to apply causal masking

        Returns:
            Output tensor of shape (batch_size, seq_len, d_model)
        """
        if self.pre_norm:
            # Pre-norm: norm first, then sublayer + residual
            # Attention with pre-norm
            attn_input = self.norm1(x)
            attn_output, _ = self.attention(
                attn_input,
                attention_mask=attention_mask,
                is_causal=is_causal,
            )
            x = x + self.dropout(attn_output)

            # FFN with pre-norm
            ff_input = self.norm2(x)
            ff_output = self.feed_forward(ff_input)
            x = x + self.dropout(ff_output)
        else:
            # Post-norm: sublayer + residual, then norm
            # Attention
            attn_output, _ = self.attention(x, attention_mask, is_causal)
            x = self.norm1(x + self.dropout1(attn_output))

            # FFN
            ff_output = self.feed_forward(x)
            x = self.norm2(x + self.dropout2(ff_output))

        return x

    def forward_with_cache(
        self,
        x: torch.Tensor,
        past_key_value: Optional[tuple] = None,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> tuple:
        """
        Forward pass with KV cache for generation.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)
            past_key_value: Cached key/value from previous forward pass
            attention_mask: Optional attention mask

        Returns:
            Tuple of (output, present_key_value)
        """
        # Pre-norm
        attn_input = self.norm1(x)

        # Attention with cache
        if past_key_value is not None:
            # Concatenate cached and new key/value
            pass  # Simplified for single forward pass

        attn_output, _ = self.attention(
            attn_input,
            attention_mask=attention_mask,
            is_causal=True,
        )
        x = x + self.dropout(attn_output)

        # FFN
        ff_input = self.norm2(x)
        ff_output = self.feed_forward(ff_input)
        x = x + self.dropout(ff_output)

        return x, None


class AdaLNBlock(nn.Module):
    """
    Adaptive Layer Normalization Block (AdaLN).

    Uses conditioning information to dynamically adjust
    layer normalization parameters. Used in some diffusion
    and control-based models.

    Args:
        d_model: Dimension of the model
        n_heads: Number of attention heads
        d_ff: Hidden dimension of FFN
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        dropout: float = 0.1,
    ):
        super().__init__()

        # Conditioning network
        self.cond_proj = nn.Linear(d_model, 6 * d_model)

        # Attention and FFN (without their own norms)
        self.attention = MultiHeadAttention(d_model, n_heads, dropout)
        self.feed_forward = FeedForward(d_model, d_ff, dropout)

        # Scale and shift for AdaLN
        self.norm = nn.LayerNorm(d_model, elementwise_affine=False)

        self.dropout = nn.Dropout(p=dropout)

    def forward(
        self,
        x: torch.Tensor,
        cond: torch.Tensor,
    ) -> torch.Tensor:
        """Forward pass with conditioning."""
        # Get AdaLN parameters
        params = self.cond_proj(cond)
        scale, shift, gate1, gate2 = params.chunk(6, dim=-1)

        # Normalize with conditioning
        normed = self.norm(x)
        normed = normed * (1 + gate1.unsqueeze(1)) + shift.unsqueeze(1)

        # Attention
        attn_out, _ = self.attention(normed, is_causal=True)
        x = x + self.dropout(attn_out)

        # FFN with conditioning
        normed = self.norm(x)
        normed = normed * (1 + gate2.unsqueeze(1)) + shift.unsqueeze(1)
        ff_out = self.feed_forward(normed)
        x = x + self.dropout(ff_out)

        return x


def create_transformer_block(
    block_type: str,
    d_model: int,
    n_heads: int,
    d_ff: int,
    dropout: float = 0.1,
    **kwargs
) -> nn.Module:
    """
    Factory function to create transformer block.

    Args:
        block_type: Type of block ('standard', 'adaln')
        d_model: Dimension of the model
        n_heads: Number of attention heads
        d_ff: Hidden dimension
        dropout: Dropout probability

    Returns:
        Transformer block module
    """
    if block_type == "standard":
        return TransformerBlock(
            d_model=d_model,
            n_heads=n_heads,
            d_ff=d_ff,
            dropout=dropout,
            **kwargs
        )
    elif block_type == "adaln":
        return AdaLNBlock(
            d_model=d_model,
            n_heads=n_heads,
            d_ff=d_ff,
            dropout=dropout,
        )
    else:
        raise ValueError(f"Unknown block type: {block_type}")
