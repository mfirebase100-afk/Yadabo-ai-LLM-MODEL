"""
Yadabo AI - Multi-Head Self-Attention
Implementation of scaled dot-product attention mechanism
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class MultiHeadAttention(nn.Module):
    """
    Multi-Head Self-Attention mechanism.

    Implements the scaled dot-product attention with multiple attention heads.
    Includes optional causal masking for autoregressive generation.

    Args:
        d_model: Dimension of the model
        n_heads: Number of attention heads
        dropout: Dropout probability
        bias: Whether to include bias in QKV projection
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        dropout: float = 0.1,
        bias: bool = True,
    ):
        super().__init__()
        assert d_model % n_heads == 0, f"d_model ({d_model}) must be divisible by n_heads ({n_heads})"

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.scale = self.head_dim ** -0.5

        # QKV projection
        self.qkv_proj = nn.Linear(d_model, 3 * d_model, bias=bias)

        # Output projection
        self.out_proj = nn.Linear(d_model, d_model, bias=bias)

        # Dropout
        self.dropout = nn.Dropout(p=dropout)

        # Causal mask cache
        self._causal_mask = None

    def forward(
        self,
        x: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        is_causal: bool = True,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Forward pass for multi-head attention.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)
            attention_mask: Optional attention mask
            is_causal: Whether to apply causal masking
            use_cache: Whether to return cached key/value for generation

        Returns:
            Tuple of (output, attention_weights) or (output, None, present_key_value) if use_cache
        """
        batch_size, seq_len, _ = x.size()

        # Project to Q, K, V
        qkv = self.qkv_proj(x)
        qkv = qkv.reshape(batch_size, seq_len, 3, self.n_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # (3, batch_size, n_heads, seq_len, head_dim)
        q, k, v = qkv[0], qkv[1], qkv[2]

        # Scaled dot-product attention
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        # Apply causal mask
        if is_causal:
            causal_mask = self._create_causal_mask(seq_len, seq_len, q.device, q.dtype)
            attn_weights = attn_weights.masked_fill(causal_mask == 0, float('-inf'))

        # Apply attention mask if provided
        if attention_mask is not None:
            # Expand mask to match attention weights shape
            mask = attention_mask.unsqueeze(1).unsqueeze(2)  # (batch_size, 1, 1, seq_len)
            mask = mask.expand(-1, self.n_heads, seq_len, -1)
            attn_weights = attn_weights.masked_fill(mask == 0, float('-inf'))

        # Softmax and dropout
        attn_probs = F.softmax(attn_weights, dim=-1)
        attn_probs = self.dropout(attn_probs)

        # Apply attention to values
        attn_output = torch.matmul(attn_probs, v)

        # Reshape output
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(batch_size, seq_len, self.d_model)

        # Output projection
        output = self.out_proj(attn_output)

        if use_cache:
            return output, (k, v)
        return output, attn_probs

    def _create_causal_mask(
        self,
        seq_len_q: int,
        seq_len_k: int,
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        """Create causal mask for masked attention."""
        if self._causal_mask is not None:
            return self._causal_mask

        # Create causal mask (lower triangular)
        mask = torch.triu(
            torch.ones(seq_len_q, seq_len_k, device=device, dtype=dtype),
            diagonal=1
        ).bool()

        return mask


class MultiHeadCrossAttention(nn.Module):
    """
    Multi-Head Cross-Attention mechanism.

    Used in encoder-decoder architectures where query comes from one sequence
    and key/value come from another sequence.

    Args:
        d_model: Dimension of the model
        n_heads: Number of attention heads
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        dropout: float = 0.1,
    ):
        super().__init__()
        assert d_model % n_heads == 0

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.scale = self.head_dim ** -0.5

        # Query projection (from decoder)
        self.q_proj = nn.Linear(d_model, d_model)

        # Key and value projection (from encoder)
        self.kv_proj = nn.Linear(d_model, 2 * d_model)

        # Output projection
        self.out_proj = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(p=dropout)

    def forward(
        self,
        query: torch.Tensor,
        key_value: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass for cross-attention.

        Args:
            query: Query tensor from decoder (batch_size, query_len, d_model)
            key_value: Key/value tensor from encoder (batch_size, kv_len, d_model)
            attention_mask: Optional attention mask for key/value

        Returns:
            Output tensor (batch_size, query_len, d_model)
        """
        batch_size, query_len, _ = query.size()
        kv_len = key_value.size(1)

        # Project query, key, value
        q = self.q_proj(query)
        kv = self.kv_proj(key_value)

        q = q.reshape(batch_size, query_len, self.n_heads, self.head_dim).permute(0, 2, 1, 3)
        kv = kv.reshape(batch_size, kv_len, 2, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        # Scaled dot-product attention
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        # Apply attention mask if provided
        if attention_mask is not None:
            mask = attention_mask.unsqueeze(1).unsqueeze(2)
            attn_weights = attn_weights.masked_fill(mask == 0, float('-inf'))

        attn_probs = F.softmax(attn_weights, dim=-1)
        attn_probs = self.dropout(attn_probs)

        # Apply attention to values
        attn_output = torch.matmul(attn_probs, v)
        attn_output = attn_output.transpose(1, 2).contiguous().reshape(batch_size, query_len, self.d_model)

        return self.out_proj(attn_output)


class GroupedQueryAttention(nn.Module):
    """
    Grouped Query Attention (GQA).

    Uses fewer key/value heads than query heads, reducing computation
    while maintaining quality. Used in models like LLaMA 2.

    Args:
        d_model: Dimension of the model
        n_heads: Number of query heads
        n_kv_heads: Number of key/value heads
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        n_kv_heads: int,
        dropout: float = 0.1,
    ):
        super().__init__()
        assert n_heads % n_kv_heads == 0
        assert d_model % n_heads == 0

        self.d_model = d_model
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.head_dim = d_model // n_heads
        self.scale = self.head_dim ** -0.5

        # Grouped QKV projection
        self.q_proj = nn.Linear(d_model, n_heads * self.head_dim)
        self.kv_proj = nn.Linear(d_model, 2 * n_kv_heads * self.head_dim)

        self.out_proj = nn.Linear(n_heads * self.head_dim, d_model)
        self.dropout = nn.Dropout(p=dropout)

    def forward(
        self,
        x: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        is_causal: bool = True,
    ) -> Tuple[torch.Tensor, None]:
        """Forward pass for grouped query attention."""
        batch_size, seq_len, _ = x.size()

        # Project Q, K, V
        q = self.q_proj(x).reshape(batch_size, seq_len, self.n_heads, self.head_dim)
        kv = self.kv_proj(x).reshape(batch_size, seq_len, 2, self.n_kv_heads, self.head_dim)
        kv = kv.permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        # Repeat K/V for query heads
        n_repeat = self.n_heads // self.n_kv_heads
        k = k.repeat_interleave(n_repeat, dim=1)
        v = v.repeat_interleave(n_repeat, dim=1)

        # Reshape for attention
        q = q.permute(0, 2, 1, 3)
        k = k.permute(0, 2, 1, 3)
        v = v.permute(0, 2, 1, 3)

        # Scaled dot-product attention
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        if is_causal:
            causal_mask = torch.triu(
                torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool),
                diagonal=1
            )
            attn_weights = attn_weights.masked_fill(causal_mask, float('-inf'))

        if attention_mask is not None:
            attn_weights = attn_weights.masked_fill(attention_mask == 0, float('-inf'))

        attn_probs = F.softmax(attn_weights, dim=-1)
        attn_probs = self.dropout(attn_probs)

        attn_output = torch.matmul(attn_probs, v)
        attn_output = attn_output.transpose(1, 2).contiguous().reshape(batch_size, seq_len, self.d_model)

        return self.out_proj(attn_output), None


def create_attention(
    attention_type: str,
    d_model: int,
    n_heads: int,
    dropout: float = 0.1,
    **kwargs
) -> nn.Module:
    """
    Factory function to create attention module.

    Args:
        attention_type: Type of attention ('multihead', 'cross', 'grouped')
        d_model: Dimension of the model
        n_heads: Number of attention heads
        dropout: Dropout probability

    Returns:
        Attention module
    """
    if attention_type == "multihead":
        return MultiHeadAttention(d_model, n_heads, dropout)
    elif attention_type == "cross":
        return MultiHeadCrossAttention(d_model, n_heads, dropout)
    elif attention_type == "grouped":
        n_kv_heads = kwargs.get('n_kv_heads', n_heads // 4)
        return GroupedQueryAttention(d_model, n_heads, n_kv_heads, dropout)
    else:
        raise ValueError(f"Unknown attention type: {attention_type}")
