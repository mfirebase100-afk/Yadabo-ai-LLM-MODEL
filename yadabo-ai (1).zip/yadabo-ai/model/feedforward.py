"""
Yadabo AI - Feed-Forward Network
Implementation of position-wise feed-forward networks
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Callable


class FeedForward(nn.Module):
    """
    Position-wise Feed-Forward Network.

    Implements the FFN layer from the Transformer paper:
    FFN(x) = max(0, xW1 + b1)W2 + b2

    Can be configured with different activation functions and
    optional SwiGLU activation.

    Args:
        d_model: Input and output dimension
        d_ff: Hidden dimension
        dropout: Dropout probability
        activation: Activation function ('gelu', 'relu', 'swiglu')
        bias: Whether to use bias in linear layers
    """

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        dropout: float = 0.1,
        activation: str = "gelu",
        bias: bool = True,
    ):
        super().__init__()
        self.d_model = d_model
        self.d_ff = d_ff
        self.activation = activation

        # First linear layer
        self.w1 = nn.Linear(d_model, d_ff, bias=bias)

        # Second linear layer
        self.w2 = nn.Linear(d_ff, d_model, bias=bias)

        # Optional gate layer for SwiGLU
        self.use_swiglu = activation == "swiglu"
        if self.use_swiglu:
            self.w3 = nn.Linear(d_model, d_ff, bias=bias)

        # Dropout
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through feed-forward network.

        Args:
            x: Input tensor of shape (batch_size, seq_len, d_model)

        Returns:
            Output tensor of shape (batch_size, seq_len, d_model)
        """
        if self.use_swiglu:
            # SwiGLU activation
            # FFN_SwiGLU(x) = (SiLU(xW1) * (xW2)) W3
            # For simplicity, we use: FFN_SwiGLU(x) = (silu(xW1) * xW3) W2
            x1 = self.w1(x)
            x3 = self.w3(x) if hasattr(self, 'w3') else x
            x = F.silu(x1) * x3
        else:
            # Standard FFN with activation
            x = self.w1(x)
            x = self._activate(x)

        x = self.dropout(x)
        x = self.w2(x)

        return x

    def _activate(self, x: torch.Tensor) -> torch.Tensor:
        """Apply activation function."""
        if self.activation == "gelu":
            return F.gelu(x)
        elif self.activation == "relu":
            return F.relu(x)
        elif self.activation == "silu":
            return F.silu(x)
        elif self.activation == "tanh":
            return F.tanhshrink(x)
        else:
            return x


class GatedConv1d(nn.Module):
    """
    Gated Convolutional Feed-Forward Network.

    Alternative to standard FFN using convolutions.
    Good for sequence modeling tasks.

    Args:
        d_model: Input and output dimension
        d_ff: Hidden dimension
        kernel_size: Convolution kernel size
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        kernel_size: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__()

        # Gated convolution
        self.conv = nn.Conv1d(
            d_model,
            2 * d_ff,
            kernel_size,
            padding=kernel_size // 2,
        )

        # Output projection
        self.proj = nn.Linear(d_ff, d_model)

        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through gated convolution FFN."""
        # Reshape for conv1d: (batch, seq, d_model) -> (batch, d_model, seq)
        x = x.transpose(1, 2)

        # Gated convolution
        x = self.conv(x)
        x, gate = x.chunk(2, dim=1)
        x = F.gelu(x) * torch.sigmoid(gate)

        # Reshape back: (batch, d_model, seq) -> (batch, seq, d_ff)
        x = x.transpose(1, 2)

        x = self.dropout(x)
        x = self.proj(x)

        return x


class SparseFeedForward(nn.Module):
    """
    Sparse Feed-Forward Network (MoE-style).

    Implements sparse mixture-of-experts style FFN with configurable
    sparsity and experts.

    Args:
        d_model: Input and output dimension
        d_ff: Hidden dimension per expert
        n_experts: Number of experts
        top_k: Number of experts to activate per token
        dropout: Dropout probability
    """

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        n_experts: int = 8,
        top_k: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.n_experts = n_experts
        self.top_k = top_k

        # Router network
        self.router = nn.Linear(d_model, n_experts, bias=False)

        # Expert FFNs
        self.experts = nn.ModuleList([
            FeedForward(d_model, d_ff, dropout, bias=False)
            for _ in range(n_experts)
        ])

        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with sparse expert activation."""
        batch_size, seq_len, d_model = x.size()

        # Reshape for routing
        x_flat = x.view(-1, d_model)

        # Get router logits and select top-k experts
        logits = self.router(x_flat)
        weights, expert_indices = logits.topk(self.top_k, dim=-1)

        # Normalize weights
        weights = F.softmax(weights, dim=-1)

        # Initialize output
        output = torch.zeros_like(x_flat)

        # Process each expert
        for i in range(self.top_k):
            expert_idx = expert_indices[:, i]
            expert_weight = weights[:, i]

            # Group tokens by expert
            for exp_id in range(self.n_experts):
                mask = (expert_idx == exp_id)
                if mask.any():
                    expert_input = x_flat[mask]
                    expert_output = self.experts[exp_id](expert_input)
                    output[mask] += expert_output * expert_weight[mask].unsqueeze(-1)

        return self.dropout(output.view(batch_size, seq_len, d_model))


def create_feedforward(
    ff_type: str,
    d_model: int,
    d_ff: int,
    dropout: float = 0.1,
    **kwargs
) -> nn.Module:
    """
    Factory function to create feed-forward network.

    Args:
        ff_type: Type of FFN ('standard', 'gated_conv', 'sparse')
        d_model: Dimension of the model
        d_ff: Hidden dimension
        dropout: Dropout probability

    Returns:
        Feed-forward module
    """
    if ff_type == "standard":
        activation = kwargs.get('activation', 'gelu')
        return FeedForward(d_model, d_ff, dropout, activation)
    elif ff_type == "gated_conv":
        kernel_size = kwargs.get('kernel_size', 3)
        return GatedConv1d(d_model, d_ff, kernel_size, dropout)
    elif ff_type == "sparse":
        n_experts = kwargs.get('n_experts', 8)
        top_k = kwargs.get('top_k', 2)
        return SparseFeedForward(d_model, d_ff, n_experts, top_k, dropout)
    else:
        raise ValueError(f"Unknown feedforward type: {ff_type}")
