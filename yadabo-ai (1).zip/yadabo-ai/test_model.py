"""
Yadabo AI - Test Script
اختبار النموذج الأساسي
"""

import torch
from model import TransformerConfig, TransformerLM

print("="*60)
print("🎯 Yadabo AI - اختبار النموذج")
print("="*60)

# إنشاء النموذج
config = TransformerConfig.small_arabic_english()
model = TransformerLM(config)
model.eval()

print(f"\n✅ تم إنشاء النموذج بنجاح!")
print(f"📊 عدد المعاملات: {sum(p.numel() for p in model.parameters()):,}")
print(f"📐 الأبعاد: d_model={config.d_model}, layers={config.n_layers}, heads={config.n_heads}")

# تجربة بسيطة
print("\n" + "-"*60)
print("🔬 اختبار forward pass (بدون تدريب):")
print("-"*60)

input_ids = torch.randint(0, config.vocab_size, (1, 20))
print(f"📝 إدخال (رموز عشوائية): {input_ids.shape}")

with torch.no_grad():
    output = model(input_ids)
    print(f"📤 ناتج (logits): {output.shape}")
    print(f"   - أبعاد المصفوفة: batch=1, seq=20, vocab={config.vocab_size}")

# تحويل النواتج إلى احتمالات
probs = torch.softmax(output, dim=-1)
print(f"\n📈 معلومات النواتج:")
print(f"   - أعلى احتمالية: {probs.max().item():.4f}")
print(f"   - أدنى احتمالية: {probs.min().item():.6f}")

print("\n" + "="*60)
print("⚠️ ملاحظة مهمة:")
print("="*60)
print("""
النموذج الحالي يحتوي على أوزان عشوائية!
❌ لا يفهم العربية أو الإنجليزية
❌ لا يعرف أي شيء عن البرمجة أو الرياضيات
❌ لا يمكنه المحادثة أو الإجابة على الأسئلة

للحصول على نموذج "ذكي"، يجب:
1. جمع بيانات تدريب ضخمة
2. تشغيل التدريب لآلاف الساعات على GPU
3. Fine-tuning على مهام محددة
""")
