"""
Yadabo AI - Training Callbacks
Callback system for extending training behavior
"""

import os
import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from pathlib import Path

import torch


class Callback(ABC):
    """
    Base class for training callbacks.

    Callbacks allow you to extend the training loop without modifying
    the trainer code. Override specific methods to hook into training.
    """

    def on_train_begin(self, trainer):
        """Called at the beginning of training."""
        pass

    def on_train_end(self, trainer):
        """Called at the end of training."""
        pass

    def on_epoch_begin(self, trainer, epoch: int):
        """Called at the beginning of each epoch."""
        pass

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Called at the end of each epoch."""
        pass

    def on_step_end(self, trainer, step: int):
        """Called at the end of each training step."""
        pass

    def on_batch_begin(self, trainer, batch: Dict[str, Any]):
        """Called at the beginning of each batch."""
        pass

    def on_batch_end(self, trainer, batch: Dict[str, Any], loss: float):
        """Called at the end of each batch."""
        pass

    def on_checkpoint_save(self, trainer, checkpoint_path: str):
        """Called after saving a checkpoint."""
        pass


class CheckpointCallback(Callback):
    """
    Callback for automatic checkpoint management.

    Handles:
    - Periodic checkpoint saving
    - Best model tracking
    - Checkpoint cleanup
    """

    def __init__(
        self,
        save_total_limit: int = 5,
        save_best_only: bool = False,
        monitor: str = "eval_loss",
        mode: str = "min",
    ):
        self.save_total_limit = save_total_limit
        self.save_best_only = save_best_only
        self.monitor = monitor
        self.mode = mode
        self.checkpoints: List[str] = []
        self.best_metric = float('inf') if mode == "min" else float('-inf')

    def on_checkpoint_save(self, trainer, checkpoint_path: str):
        """Save checkpoint and manage old checkpoints."""
        self.checkpoints.append(checkpoint_path)

        # Remove old checkpoints
        if len(self.checkpoints) > self.save_total_limit:
            old_checkpoint = self.checkpoints.pop(0)
            if os.path.exists(old_checkpoint):
                os.remove(old_checkpoint)

    def should_save(self, metrics: Dict[str, float]) -> bool:
        """Check if current metrics warrant saving."""
        if not self.save_best_only:
            return True

        current = metrics.get(self.monitor)
        if current is None:
            return True

        if self.mode == "min":
            return current < self.best_metric
        else:
            return current > self.best_metric


class LoggingCallback(Callback):
    """
    Callback for logging training metrics.

    Handles:
    - Console logging
    - File logging
    - Custom metric formatting
    """

    def __init__(
        self,
        log_level: int = logging.INFO,
        log_format: Optional[str] = None,
    ):
        self.logger = logging.getLogger(__class__.__name__)
        self.logger.setLevel(log_level)
        self.log_format = log_format or "%(asctime)s - %(levelname)s - %(message)s"

    def on_train_begin(self, trainer):
        """Log training start."""
        self.logger.info("=" * 50)
        self.logger.info("Training Starting")
        self.logger.info("=" * 50)

    def on_train_end(self, trainer):
        """Log training end."""
        self.logger.info("=" * 50)
        self.logger.info("Training Completed")
        self.logger.info(f"Total steps: {trainer.global_step}")
        self.logger.info("=" * 50)

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Log epoch results."""
        metrics_str = ", ".join(f"{k}: {v:.4f}" for k, v in metrics.items())
        self.logger.info(f"Epoch {epoch} - {metrics_str}")

    def on_step_end(self, trainer, step: int):
        """Log step progress."""
        if step % 100 == 0:
            lr = trainer.scheduler.get_last_lr()[0]
            self.logger.debug(f"Step {step} - LR: {lr:.2e}")


class EarlyStoppingCallback(Callback):
    """
    Callback for early stopping based on metrics.

    Stops training when a metric stops improving.
    """

    def __init__(
        self,
        monitor: str = "eval_loss",
        patience: int = 3,
        min_delta: float = 0.0,
        mode: str = "min",
    ):
        self.monitor = monitor
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.best_value = None
        self.wait = 0
        self.stopped_epoch = 0

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Check if training should stop."""
        current = metrics.get(self.monitor)
        if current is None:
            return

        if self.best_value is None:
            self.best_value = current
            return

        # Check for improvement
        improved = False
        if self.mode == "min":
            improved = current < (self.best_value - self.min_delta)
        else:
            improved = current > (self.best_value + self.min_delta)

        if improved:
            self.best_value = current
            self.wait = 0
        else:
            self.wait += 1
            if self.wait >= self.patience:
                self.stopped_epoch = epoch
                trainer.global_step = trainer.config.max_steps  # Signal to stop


class TensorBoardCallback(Callback):
    """
    Callback for TensorBoard logging.

    Logs scalars, histograms, and text summaries.
    """

    def __init__(self, log_dir: str):
        from torch.utils.tensorboard import SummaryWriter
        self.writer = SummaryWriter(log_dir=log_dir)

    def on_step_end(self, trainer, step: int):
        """Log scalar metrics."""
        lr = trainer.scheduler.get_last_lr()[0]
        self.writer.add_scalar("train/learning_rate", lr, step)

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Log epoch metrics."""
        for key, value in metrics.items():
            self.writer.add_scalar(key, value, epoch)

    def on_train_end(self, trainer):
        """Close writer."""
        self.writer.close()


class WandBCallback(Callback):
    """
    Callback for Weights & Biases logging.

    Requires wandb package to be installed.
    """

    def __init__(
        self,
        project_name: str,
        run_name: Optional[str] = None,
        config: Optional[Dict] = None,
    ):
        try:
            import wandb
            self.wandb = wandb
        except ImportError:
            raise ImportError("wandb package required: pip install wandb")

        self.wandb.init(
            project=project_name,
            name=run_name,
            config=config,
        )

    def on_step_end(self, trainer, step: int):
        """Log metrics."""
        lr = trainer.scheduler.get_last_lr()[0]
        self.wandb.log({"learning_rate": lr, "step": step})

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Log epoch metrics."""
        self.wandb.log(metrics, step=epoch)

    def on_train_end(self, trainer):
        """Finish wandb run."""
        self.wandb.finish()


class MetricsCallback(Callback):
    """
    Callback for tracking and storing metrics.

    Stores metrics in memory and optionally to file.
    """

    def __init__(
        self,
        output_dir: Optional[str] = None,
        save_frequency: int = 100,
    ):
        self.metrics: List[Dict[str, float]] = []
        self.output_dir = output_dir
        self.save_frequency = save_frequency

        if output_dir:
            Path(output_dir).mkdir(parents=True, exist_ok=True)

    def on_epoch_end(self, trainer, epoch: int, metrics: Dict[str, float]):
        """Store epoch metrics."""
        metrics["epoch"] = epoch
        metrics["global_step"] = trainer.global_step
        self.metrics.append(metrics)

        # Save periodically
        if len(self.metrics) % self.save_frequency == 0:
            self._save_metrics()

    def _save_metrics(self):
        """Save metrics to file."""
        if self.output_dir:
            path = os.path.join(self.output_dir, "metrics.json")
            with open(path, 'w') as f:
                json.dump(self.metrics, f, indent=2)

    def get_metrics(self) -> List[Dict[str, float]]:
        """Get all stored metrics."""
        return self.metrics

    def get_best(self, metric: str, mode: str = "min") -> Optional[Dict[str, float]]:
        """Get best value for a metric."""
        if not self.metrics:
            return None

        values = [(m.get(metric, float('inf')), m) for m in self.metrics]
        if mode == "min":
            return min(values, key=lambda x: x[0])[1]
        else:
            return max(values, key=lambda x: x[0])[1]


class GradientCallback(Callback):
    """
    Callback for gradient analysis and logging.

    Tracks gradient norms and optionally clips or modifies gradients.
    """

    def __init__(
        self,
        log_frequency: int = 100,
        clip_value: Optional[float] = None,
    ):
        self.log_frequency = log_frequency
        self.clip_value = clip_value

    def on_batch_end(self, trainer, batch: Dict[str, Any], loss: float):
        """Analyze and optionally clip gradients."""
        if trainer.global_step % self.log_frequency != 0:
            return

        total_norm = 0.0
        for p in trainer.model.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        total_norm = total_norm ** 0.5

        # Log gradient norm
        logging.getLogger(__name__).debug(
            f"Gradient norm: {total_norm:.4f}"
        )

        # Clip gradients
        if self.clip_value and total_norm > self.clip_value:
            torch.nn.utils.clip_grad_norm_(
                trainer.model.parameters(),
                self.clip_value
            )


def create_callbacks(
    callback_names: List[str],
    **kwargs
) -> List[Callback]:
    """
    Factory function to create callbacks by name.

    Args:
        callback_names: List of callback names to create
        **kwargs: Additional arguments for callbacks

    Returns:
        List of callback instances
    """
    callbacks = []

    for name in callback_names:
        if name == "checkpoint":
            callbacks.append(CheckpointCallback(**kwargs.get("checkpoint", {})))
        elif name == "logging":
            callbacks.append(LoggingCallback(**kwargs.get("logging", {})))
        elif name == "early_stopping":
            callbacks.append(EarlyStoppingCallback(**kwargs.get("early_stopping", {})))
        elif name == "tensorboard":
            callbacks.append(TensorBoardCallback(**kwargs.get("tensorboard", {})))
        elif name == "wandb":
            callbacks.append(WandBCallback(**kwargs.get("wandb", {})))
        elif name == "metrics":
            callbacks.append(MetricsCallback(**kwargs.get("metrics", {})))
        elif name == "gradient":
            callbacks.append(GradientCallback(**kwargs.get("gradient", {})))
        else:
            logging.getLogger(__name__).warning(f"Unknown callback: {name}")

    return callbacks
