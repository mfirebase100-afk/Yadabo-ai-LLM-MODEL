"""
Yadabo AI - Optimizer Implementations
Custom optimizer implementations with extended features
"""

import math
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.optimizer import Optimizer
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass


class AdamW(optim.AdamW):
    """
    AdamW optimizer with weight decay.

    Implements the AdamW algorithm from the paper
    "Decoupled Weight Decay Regularization".
    """

    def __init__(
        self,
        params,
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01,
        amsgrad: bool = False,
    ):
        super().__init__(
            params,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
        )


class Adam(optim.Adam):
    """
    Adam optimizer with improved stability.
    """

    def __init__(
        self,
        params,
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.0,
        amsgrad: bool = False,
    ):
        super().__init__(
            params,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
        )


class Lion(Optimizer):
    """
    Lion optimizer - Discoveries and Technical Report.

    A simple optimizer that uses the sign operation for weight updates.
    Often achieves good results with smaller batch sizes.

    Reference: https://arxiv.org/abs/2302.06675
    """

    def __init__(
        self,
        params,
        lr: float = 1e-4,
        betas: tuple = (0.9, 0.99),
        weight_decay: float = 0.0,
    ):
        defaults = dict(
            lr=lr,
            betas=betas,
            weight_decay=weight_decay,
        )
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure: Optional[Callable] = None):
        """Perform a single optimization step."""
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad
                if not grad.is_contiguous():
                    grad = grad.contiguous()

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['exp_avg'] = torch.zeros_like(p)
                    state['exp_avg_sq'] = torch.zeros_like(p)

                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                beta1, beta2 = group['betas']

                # Update biased first moment estimate
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)

                # Update biased second raw moment estimate
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                # Compute the update
                update = torch.sign(exp_avg)
                if group['weight_decay'] > 0:
                    update.add_(p, alpha=group['weight_decay'])

                # Apply the update
                p.add_(update, alpha=-group['lr'])

        return loss


class SophiaG(Optimizer):
    """
    Sophia optimizer - Scalable Hessian-Aware Momentum.

    A second-order optimizer that uses a stochastic estimate of the
    Hessian diagonal to perform adaptive updates.

    Reference: https://arxiv.org/abs/2305.14342
    """

    def __init__(
        self,
        params,
        lr: float = 1e-4,
        betas: tuple = (0.9, 0.999),
        rho: float = 0.04,
        weight_decay: float = 1e-3,
        eps: float = 1e-8,
    ):
        defaults = dict(
            lr=lr,
            betas=betas,
            rho=rho,
            weight_decay=weight_decay,
            eps=eps,
        )
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure: Optional[Callable] = None):
        """Perform a single optimization step."""
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad
                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['exp_avg'] = torch.zeros_like(p)
                    state['exp_avg_sq'] = torch.zeros_like(p)
                    state['hessian_diag'] = torch.zeros_like(p)

                exp_avg, exp_avg_sq, hessian_diag = (
                    state['exp_avg'],
                    state['exp_avg_sq'],
                    state['hessian_diag'],
                )
                beta1, beta2 = group['betas']

                # Update biased first moment estimate
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)

                # Update biased second raw moment estimate
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                # Update Hessian estimate
                hessian_diag.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                # Compute Sophia update
                bias_correction1 = 1 - beta1 ** (state['step'])
                bias_correction2 = 1 - beta2 ** (state['step'])

                step_size = group['lr'] / bias_correction1

                # Clipped update
                denom = (exp_avg_sq.sqrt() / math.sqrt(bias_correction2)) + group['eps']
                update = exp_avg / denom
                update = torch.clamp(update, max=group['rho'])

                if group['weight_decay'] > 0:
                    update.add_(p, alpha=-group['weight_decay'])

                p.add_(update, alpha=-step_size)

        return loss


class LAMB(Optimizer):
    """
    LAMB optimizer - Large Batch Training for BERT.

    A layerwise adaptive optimizer that works well for large batch training.

    Reference: https://arxiv.org/abs/1904.00962
    """

    def __init__(
        self,
        params,
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-6,
        weight_decay: float = 0.0,
        max_grad_norm: float = 1.0,
    ):
        defaults = dict(
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            max_grad_norm=max_grad_norm,
        )
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure: Optional[Callable] = None):
        """Perform a single optimization step."""
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad
                if not grad.is_contiguous():
                    grad = grad.clone().contiguous()

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['exp_avg'] = torch.zeros_like(p)
                    state['exp_avg_sq'] = torch.zeros_like(p)

                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                beta1, beta2 = group['betas']

                # Update biased first moment estimate
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)

                # Update biased second raw moment estimate
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                # Bias correction
                bias_correction1 = 1 - beta1 ** state['step']
                bias_correction2 = 1 - beta2 ** state['step']

                # Gradient clipping
                grad_norm = torch.norm(grad)
                if grad_norm > group['max_grad_norm']:
                    grad = grad * group['max_grad_norm'] / grad_norm

                # LAMB update
                exp_avg_corrected = exp_avg / bias_correction1
                exp_avg_sq_corrected = exp_avg_sq / bias_correction2

                adam_step = exp_avg_corrected / (exp_avg_sq_corrected.sqrt() + group['eps'])

                # Weight decay
                if group['weight_decay'] > 0:
                    adam_step.add_(p, alpha=group['weight_decay'])

                # Layerwise adaptation
                weight_norm = torch.norm(p)
                adam_norm = torch.norm(adam_step)

                trust_ratio = weight_norm / (adam_norm + group['eps'])
                trust_ratio = min(trust_ratio / bias_correction1, 1.0)

                p.add_(adam_step, alpha=-group['lr'] * trust_ratio)

        return loss


def create_optimizer(
    model: nn.Module,
    optimizer_type: str = "adamw",
    learning_rate: float = 1e-4,
    weight_decay: float = 0.01,
    beta1: float = 0.9,
    beta2: float = 0.999,
    eps: float = 1e-8,
    **kwargs
) -> Optimizer:
    """
    Create an optimizer for the model.

    Args:
        model: Model to optimize
        optimizer_type: Type of optimizer ('adamw', 'adam', 'lion', 'sophia', 'lamb')
        learning_rate: Learning rate
        weight_decay: Weight decay coefficient
        beta1: First moment decay
        beta2: Second moment decay
        eps: Epsilon for numerical stability

    Returns:
        Optimizer instance
    """
    # Separate parameters with and without weight decay
    no_decay = ['bias', 'LayerNorm', 'layernorm', 'norm']
    optimizer_grouped_parameters = [
        {
            'params': [p for n, p in model.named_parameters()
                       if not any(nd in n for nd in no_decay)],
            'weight_decay': weight_decay,
        },
        {
            'params': [p for n, p in model.named_parameters()
                       if any(nd in n for nd in no_decay)],
            'weight_decay': 0.0,
        },
    ]

    if optimizer_type.lower() == "adamw":
        return AdamW(
            optimizer_grouped_parameters,
            lr=learning_rate,
            betas=(beta1, beta2),
            eps=eps,
        )
    elif optimizer_type.lower() == "adam":
        return Adam(
            optimizer_grouped_parameters,
            lr=learning_rate,
            betas=(beta1, beta2),
            eps=eps,
        )
    elif optimizer_type.lower() == "lion":
        return Lion(
            optimizer_grouped_parameters,
            lr=learning_rate,
            betas=(beta1, beta2),
            weight_decay=weight_decay,
        )
    elif optimizer_type.lower() == "sophia":
        rho = kwargs.get('rho', 0.04)
        return SophiaG(
            optimizer_grouped_parameters,
            lr=learning_rate,
            betas=(beta1, beta2),
            rho=rho,
            weight_decay=weight_decay,
        )
    elif optimizer_type.lower() == "lamb":
        return LAMB(
            optimizer_grouped_parameters,
            lr=learning_rate,
            betas=(beta1, beta2),
            eps=eps,
            weight_decay=weight_decay,
        )
    else:
        raise ValueError(f"Unknown optimizer type: {optimizer_type}")


class OptimizerFactory:
    """
    Factory for creating and managing optimizers.

    Supports learning rate scheduling and parameter groups.
    """

    def __init__(
        self,
        model: nn.Module,
        optimizer_type: str = "adamw",
        learning_rate: float = 1e-4,
        weight_decay: float = 0.01,
        **kwargs
    ):
        self.model = model
        self.optimizer_type = optimizer_type
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.kwargs = kwargs
        self.optimizer = None

    def create(self) -> Optimizer:
        """Create and return the optimizer."""
        self.optimizer = create_optimizer(
            self.model,
            self.optimizer_type,
            self.learning_rate,
            self.weight_decay,
            **self.kwargs
        )
        return self.optimizer

    def get_lr(self) -> float:
        """Get current learning rate."""
        if self.optimizer is None:
            return self.learning_rate
        return self.optimizer.param_groups[0]['lr']

    def set_lr(self, lr: float):
        """Set learning rate for all parameter groups."""
        if self.optimizer is None:
            raise RuntimeError("Optimizer not created yet")
        for group in self.optimizer.param_groups:
            group['lr'] = lr

    def scale_lr(self, scale: float):
        """Scale learning rate by a factor."""
        self.set_lr(self.get_lr() * scale)

    def state_dict(self) -> dict:
        """Get optimizer state dict."""
        if self.optimizer is None:
            raise RuntimeError("Optimizer not created yet")
        return self.optimizer.state_dict()

    def load_state_dict(self, state_dict: dict):
        """Load optimizer state dict."""
        if self.optimizer is None:
            raise RuntimeError("Optimizer not created yet")
        self.optimizer.load_state_dict(state_dict)
