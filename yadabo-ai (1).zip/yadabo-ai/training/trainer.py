"""
Yadabo AI - Trainer Implementation
Main training loop with support for distributed training
"""

import os
import time
import math
import logging
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Callable
from pathlib import Path

import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from .optimizer import create_optimizer
from .scheduler import create_scheduler
from .callbacks import Callback, CheckpointCallback, LoggingCallback


@dataclass
class TrainerConfig:
    """Configuration for the trainer."""
    # Model
    output_dir: str = "./output"
    save_steps: int = 1000
    eval_steps: int = 1000

    # Training
    max_steps: int = 100000
    num_epochs: Optional[int] = None
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0

    # Optimizer
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    beta1: float = 0.9
    beta2: float = 0.999
    eps: float = 1e-8
    optimizer_type: str = "adamw"

    # Scheduler
    scheduler_type: str = "cosine"
    warmup_steps: int = 1000
    min_lr: float = 0.0

    # Logging
    log_steps: int = 10
    tensorboard: bool = True

    # Distributed
    local_rank: int = -1
    gradient_checkpointing: bool = False

    # Resume
    resume_from_checkpoint: Optional[str] = None

    def __post_init__(self):
        """Validate configuration."""
        if self.gradient_accumulation_steps < 1:
            raise ValueError("gradient_accumulation_steps must be >= 1")


class Trainer:
    """
    Main trainer class for Yadabo AI models.

    Handles the complete training loop including:
    - Forward and backward passes
    - Gradient accumulation
    - Optimizer and scheduler updates
    - Checkpointing
    - Logging and evaluation
    - Distributed training support

    Args:
        model: The model to train
        config: Training configuration
        train_dataloader: Training data loader
        eval_dataloader: Optional evaluation data loader
        callbacks: List of training callbacks
    """

    def __init__(
        self,
        model: nn.Module,
        config: TrainerConfig,
        train_dataloader: DataLoader,
        eval_dataloader: Optional[DataLoader] = None,
        callbacks: Optional[List[Callback]] = None,
    ):
        self.model = model
        self.config = config
        self.train_dataloader = train_dataloader
        self.eval_dataloader = eval_dataloader
        self.callbacks = callbacks or []

        # Training state
        self.global_step = 0
        self.epoch = 0
        self.best_eval_loss = float('inf')

        # Initialize
        self._setup_training()
        self._setup_logging()

    def _setup_training(self):
        """Setup training components."""
        # Device setup
        self.device = torch.device(
            f"cuda:{self.config.local_rank}"
            if torch.cuda.is_available() and self.config.local_rank >= 0
            else "cuda" if torch.cuda.is_available()
            else "cpu"
        )

        # Move model to device
        self.model.to(self.device)

        # Optimizer
        self.optimizer = create_optimizer(
            self.model,
            optimizer_type=self.config.optimizer_type,
            learning_rate=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            beta1=self.config.beta1,
            beta2=self.config.beta2,
            eps=self.config.eps,
        )

        # Scheduler
        num_training_steps = self.config.max_steps or (
            len(self.train_dataloader) * self.config.num_epochs
        )

        self.scheduler = create_scheduler(
            self.optimizer,
            scheduler_type=self.config.scheduler_type,
            num_warmup_steps=self.config.warmup_steps,
            num_training_steps=num_training_steps,
            min_lr=self.config.min_lr,
        )

        # Gradient checkpointing
        if self.config.gradient_checkpointing:
            self.model.enable_gradient_checkpointing()

        # Distributed training
        self.is_distributed = self.config.local_rank >= 0
        if self.is_distributed:
            self._setup_distributed()

        # Resume from checkpoint
        if self.config.resume_from_checkpoint:
            self._load_checkpoint(self.config.resume_from_checkpoint)

    def _setup_distributed(self):
        """Setup distributed training."""
        if not dist.is_initialized():
            dist.init_process_group(backend='nccl')

        # Set device for this rank
        torch.cuda.set_device(self.config.local_rank)
        self.model = nn.parallel.DistributedDataParallel(
            self.model,
            device_ids=[self.config.local_rank],
            output_device=self.config.local_rank,
        )

    def _setup_logging(self):
        """Setup logging components."""
        # Create output directory
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)

        # Tensorboard
        if self.config.tensorboard and self.config.local_rank <= 0:
            self.writer = SummaryWriter(log_dir=os.path.join(self.config.output_dir, "logs"))
        else:
            self.writer = None

        # Console logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(self.config.output_dir, "training.log")),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def train(self):
        """
        Main training loop.
        """
        self.logger.info(f"Starting training for {self.config.max_steps} steps")
        self.logger.info(f"Model: {self.model.module if hasattr(self.model, 'module') else self.model}")

        # Callbacks: on_train_begin
        self._trigger_callbacks("on_train_begin")

        # Training loop
        while self.global_step < self.config.max_steps:
            self.epoch += 1
            self._train_epoch()

        # Callbacks: on_train_end
        self._trigger_callbacks("on_train_end")

        # Close tensorboard
        if self.writer:
            self.writer.close()

        self.logger.info("Training completed!")

    def _train_epoch(self):
        """Train for one epoch."""
        self.model.train()

        epoch_loss = 0.0
        num_batches = 0

        for batch in self.train_dataloader:
            # Move batch to device
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                     for k, v in batch.items()}

            # Forward pass
            loss, logits = self.model(**batch)

            # Scale loss for gradient accumulation
            loss = loss / self.config.gradient_accumulation_steps

            # Backward pass
            loss.backward()

            # Update metrics
            epoch_loss += loss.item() * self.config.gradient_accumulation_steps
            num_batches += 1

            # Gradient accumulation
            if (self.global_step + 1) % self.config.gradient_accumulation_steps == 0:
                # Gradient clipping
                if self.config.max_grad_norm > 0:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config.max_grad_norm
                    )

                # Optimizer step
                self.optimizer.step()
                self.scheduler.step()
                self.optimizer.zero_grad()

                self.global_step += 1

                # Logging
                if self.global_step % self.config.log_steps == 0:
                    self._log_metrics(epoch_loss / num_batches, num_batches)

                # Evaluation
                if self.eval_dataloader and self.global_step % self.config.eval_steps == 0:
                    eval_loss = self._evaluate()
                    self.model.train()

                    # Check for improvement
                    if eval_loss < self.best_eval_loss:
                        self.best_eval_loss = eval_loss
                        self._save_checkpoint("best")

                # Checkpointing
                if self.global_step % self.config.save_steps == 0:
                    self._save_checkpoint(f"step_{self.global_step}")

                # Callbacks
                self._trigger_callbacks("on_step_end", step=self.global_step)

                # Check max steps
                if self.global_step >= self.config.max_steps:
                    break

        self.logger.info(f"Epoch {self.epoch} completed. Avg loss: {epoch_loss / num_batches:.4f}")

    @torch.no_grad()
    def _evaluate(self) -> float:
        """Evaluate the model."""
        self.logger.info("Running evaluation...")
        self.model.eval()

        total_loss = 0.0
        num_batches = 0

        for batch in self.eval_dataloader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                     for k, v in batch.items()}

            loss, _ = self.model(**batch)
            total_loss += loss.item()
            num_batches += 1

        avg_loss = total_loss / num_batches
        perplexity = math.exp(avg_loss)

        self.logger.info(f"Eval loss: {avg_loss:.4f}, Perplexity: {perplexity:.2f}")

        # Log to tensorboard
        if self.writer:
            self.writer.add_scalar("eval/loss", avg_loss, self.global_step)
            self.writer.add_scalar("eval/perplexity", perplexity, self.global_step)

        return avg_loss

    def _log_metrics(self, loss: float, num_batches: int):
        """Log training metrics."""
        lr = self.scheduler.get_last_lr()[0]
        metrics = {
            "train/loss": loss,
            "train/perplexity": math.exp(loss),
            "train/learning_rate": lr,
            "train/global_step": self.global_step,
        }

        # Log to console
        self.logger.info(
            f"Step {self.global_step} | "
            f"Loss: {loss:.4f} | "
            f"Perplexity: {math.exp(loss):.2f} | "
            f"LR: {lr:.2e}"
        )

        # Log to tensorboard
        if self.writer:
            for key, value in metrics.items():
                self.writer.add_scalar(key, value, self.global_step)

    def _save_checkpoint(self, name: str):
        """Save model checkpoint."""
        if self.is_distributed and self.config.local_rank > 0:
            return

        checkpoint_path = os.path.join(self.config.output_dir, f"checkpoint_{name}.pt")

        model_state = (
            self.model.module.state_dict()
            if hasattr(self.model, 'module')
            else self.model.state_dict()
        )

        checkpoint = {
            "model_state_dict": model_state,
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "global_step": self.global_step,
            "epoch": self.epoch,
            "config": self.config.__dict__,
        }

        torch.save(checkpoint, checkpoint_path)
        self.logger.info(f"Checkpoint saved to {checkpoint_path}")

        # Callbacks
        self._trigger_callbacks("on_checkpoint_save", checkpoint_path=checkpoint_path)

    def _load_checkpoint(self, checkpoint_path: str):
        """Load model checkpoint."""
        self.logger.info(f"Loading checkpoint from {checkpoint_path}")

        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        model_state = (
            self.model.module.state_dict()
            if hasattr(self.model, 'module')
            else self.model.state_dict()
        )

        model_state.update(checkpoint["model_state_dict"])
        self.model.load_state_dict(model_state)

        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        self.global_step = checkpoint["global_step"]
        self.epoch = checkpoint["epoch"]

        self.logger.info(f"Checkpoint loaded. Resuming from step {self.global_step}")

    def _trigger_callbacks(self, method_name: str, **kwargs):
        """Trigger callback methods."""
        for callback in self.callbacks:
            if hasattr(callback, method_name):
                method = getattr(callback, method_name)
                method(trainer=self, **kwargs)

    def generate(
        self,
        prompt: str,
        tokenizer,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
    ) -> str:
        """
        Generate text using the trained model.

        Args:
            prompt: Input prompt
            tokenizer: Tokenizer to use
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_k: Top-k filtering
            top_p: Nucleus sampling threshold

        Returns:
            Generated text
        """
        self.model.eval()

        # Tokenize prompt
        input_ids = torch.tensor(
            [tokenizer.encode(prompt)],
            device=self.device
        )

        # Generate
        with torch.no_grad():
            output_ids = self.model.module.generate(
                input_ids,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
            )

        # Decode
        generated_text = tokenizer.decode(output_ids[0].tolist())

        return generated_text


def create_trainer(
    model: nn.Module,
    train_dataloader: DataLoader,
    config: TrainerConfig,
    eval_dataloader: Optional[DataLoader] = None,
) -> Trainer:
    """
    Factory function to create a trainer.

    Args:
        model: Model to train
        train_dataloader: Training data loader
        config: Training configuration
        eval_dataloader: Optional evaluation data loader

    Returns:
        Trainer instance
    """
    # Add default callbacks
    callbacks = [
        CheckpointCallback(),
        LoggingCallback(),
    ]

    return Trainer(
        model=model,
        config=config,
        train_dataloader=train_dataloader,
        eval_dataloader=eval_dataloader,
        callbacks=callbacks,
    )
