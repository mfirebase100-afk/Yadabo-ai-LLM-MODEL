"""
Yadabo AI - Learning Rate Schedulers
Learning rate scheduling implementations
"""

import math
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR, CosineAnnealingLR, StepLR
from typing import Optional, Callable, Union
from dataclasses import dataclass


@dataclass
class SchedulerConfig:
    """Configuration for learning rate scheduler."""
    scheduler_type: str = "cosine"
    warmup_steps: int = 1000
    max_steps: int = 100000
    min_lr: float = 0.0
    warmup_ratio: float = 0.1


def get_cosine_schedule_with_warmup(
    optimizer: optim.Optimizer,
    num_warmup_steps: int,
    num_training_steps: int,
    min_lr_ratio: float = 0.0,
    last_epoch: int = -1,
) -> LambdaLR:
    """
    Create a schedule with a learning rate that decreases following the
    values of the cosine function between the initial lr set in the optimizer
    to 0, after a warmup period during which it increases linearly
    between 0 and the initial lr set in the optimizer.

    Args:
        optimizer: The optimizer for which to schedule the learning rate
        num_warmup_steps: The number of steps for the warmup phase
        num_training_steps: The total number of training steps
        min_lr_ratio: The minimum learning rate ratio after annealing
        last_epoch: The index of the last epoch when resuming training

    Returns:
        LambdaLR scheduler
    """

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            # Linear warmup
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(max(1, num_training_steps - num_warmup_steps))
        return max(min_lr_ratio, 0.5 * (1.0 + math.cos(math.pi * progress)))

    return LambdaLR(optimizer, lr_lambda, last_epoch)


def get_linear_schedule_with_warmup(
    optimizer: optim.Optimizer,
    num_warmup_steps: int,
    num_training_steps: int,
    last_epoch: int = -1,
) -> LambdaLR:
    """
    Create a schedule with a learning rate that decreases linearly from the
    initial lr set in the optimizer to min_lr, after a warmup period during
    which it increases linearly from 0 to initial lr.

    Args:
        optimizer: The optimizer for which to schedule the learning rate
        num_warmup_steps: The number of steps for the warmup phase
        num_training_steps: The total number of training steps
        last_epoch: The index of the last epoch when resuming training

    Returns:
        LambdaLR scheduler
    """

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            # Linear warmup
            return float(current_step) / float(max(1, num_warmup_steps))
        # Linear decay
        return max(
            0.0,
            float(num_training_steps - current_step) / float(max(1, num_training_steps - num_warmup_steps))
        )

    return LambdaLR(optimizer, lr_lambda, last_epoch)


def get_polynomial_schedule_with_warmup(
    optimizer: optim.Optimizer,
    num_warmup_steps: int,
    num_training_steps: int,
    lr_end: float = 0.0,
    power: float = 1.0,
    last_epoch: int = -1,
) -> LambdaLR:
    """
    Create a schedule with a learning rate that decreases as a polynomial
    decay from the initial lr set in the optimizer to end_lr defined by
    lr_end, after a warmup period during which it increases linearly
    from 0 to initial lr.

    Args:
        optimizer: The optimizer for which to schedule the learning rate
        num_warmup_steps: The number of steps for the warmup phase
        num_training_steps: The total number of training steps
        lr_end: The end learning rate
        power: Power of polynomial decay
        last_epoch: The index of the last epoch when resuming training

    Returns:
        LambdaLR scheduler
    """

    lr_init = optimizer.defaults['lr']

    assert lr_init > lr_end, f"lr_end ({lr_end}) must be less than lr_init ({lr_init})"

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            # Linear warmup
            return float(current_step) / float(max(1.0, num_warmup_steps))

        elif current_step >= num_training_steps:
            # Return lr_end
            return lr_end / lr_init

        else:
            # Polynomial decay
            decay_ratio = (current_step - num_warmup_steps) / (num_training_steps - num_warmup_steps)
            return (lr_init - lr_end) * pow(1 - decay_ratio, power) + lr_end / lr_init

    return LambdaLR(optimizer, lr_lambda, last_epoch)


def get_constant_schedule_with_warmup(
    optimizer: optim.Optimizer,
    num_warmup_steps: int,
    last_epoch: int = -1,
) -> LambdaLR:
    """
    Create a schedule with a learning rate that is constant during warmup
    and then constant after warmup.

    Args:
        optimizer: The optimizer for which to schedule the learning rate
        num_warmup_steps: The number of steps for the warmup phase
        last_epoch: The index of the last epoch when resuming training

    Returns:
        LambdaLR scheduler
    """

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1.0, num_warmup_steps))
        return 1.0

    return LambdaLR(optimizer, lr_lambda, last_epoch)


def get_exponential_schedule_with_warmup(
    optimizer: optim.Optimizer,
    num_warmup_steps: int,
    gamma: float = 0.95,
    last_epoch: int = -1,
) -> LambdaLR:
    """
    Create a schedule with a learning rate that is exponentially decayed
    after warmup.

    Args:
        optimizer: The optimizer for which to schedule the learning rate
        num_warmup_steps: The number of steps for the warmup phase
        gamma: The decay factor
        last_epoch: The index of the last epoch when resuming training

    Returns:
        LambdaLR scheduler
    """

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1.0, num_warmup_steps))
        return pow(gamma, (current_step - num_warmup_steps))

    return LambdaLR(optimizer, lr_lambda, last_epoch)


class CosineAnnealingLR:
    """
    Custom cosine annealing scheduler with warmup.
    """

    def __init__(
        self,
        optimizer: optim.Optimizer,
        T_max: int,
        eta_min: float = 0.0,
        warmup_steps: int = 0,
        last_epoch: int = -1,
    ):
        self.optimizer = optimizer
        self.T_max = T_max
        self.eta_min = eta_min
        self.warmup_steps = warmup_steps
        self.base_lrs = [group['lr'] for group in optimizer.param_groups]
        self.last_epoch = last_epoch

    def step(self):
        """Perform a single learning rate update."""
        self.last_epoch += 1

        for i, param_group in enumerate(self.param_groups):
            if self.last_epoch < self.warmup_steps:
                # Linear warmup
                param_group['lr'] = self.base_lrs[i] * self.last_epoch / self.warmup_steps
            else:
                # Cosine annealing
                progress = (self.last_epoch - self.warmup_steps) / (self.T_max - self.warmup_steps)
                param_group['lr'] = self.eta_min + (self.base_lrs[i] - self.eta_min) * 0.5 * (
                    1.0 + math.cos(math.pi * progress)
                )

    @property
    def param_groups(self):
        return self.optimizer.param_groups

    def get_lr(self):
        """Get current learning rates."""
        return [group['lr'] for group in self.optimizer.param_groups]


class LinearWarmupCosineLR:
    """
    Linear warmup followed by cosine annealing.

    Combines the benefits of linear warmup and cosine annealing
    for smoother learning rate transitions.
    """

    def __init__(
        self,
        optimizer: optim.Optimizer,
        max_steps: int,
        warmup_steps: int,
        min_lr: float = 0.0,
        warmup_start_lr: float = 0.0,
        last_epoch: int = -1,
    ):
        self.optimizer = optimizer
        self.max_steps = max_steps
        self.warmup_steps = warmup_steps
        self.min_lr = min_lr
        self.warmup_start_lr = warmup_start_lr
        self.base_lrs = [group['lr'] for group in optimizer.param_groups]
        self.last_epoch = last_epoch

    def step(self):
        """Perform a single learning rate update."""
        self.last_epoch += 1
        self._update_lr()

    def _update_lr(self):
        """Update learning rates based on schedule."""
        for i, param_group in enumerate(self.optimizer.param_groups):
            base_lr = self.base_lrs[i]

            if self.last_epoch < self.warmup_steps:
                # Linear warmup
                lr = self.warmup_start_lr + (base_lr - self.warmup_start_lr) * self.last_epoch / self.warmup_steps
            else:
                # Cosine annealing
                progress = (self.last_epoch - self.warmup_steps) / (self.max_steps - self.warmup_steps)
                progress = min(progress, 1.0)
                lr = self.min_lr + (base_lr - self.min_lr) * 0.5 * (1.0 + math.cos(math.pi * progress))

            param_group['lr'] = lr

    def get_lr(self):
        """Get current learning rates."""
        return [group['lr'] for group in self.optimizer.param_groups]


def create_scheduler(
    optimizer: optim.Optimizer,
    scheduler_type: str = "cosine",
    num_warmup_steps: int = 1000,
    num_training_steps: int = 100000,
    min_lr: float = 0.0,
    **kwargs
) -> LambdaLR:
    """
    Create a learning rate scheduler.

    Args:
        optimizer: Optimizer to schedule
        scheduler_type: Type of scheduler ('cosine', 'linear', 'polynomial', 'constant', 'exponential')
        num_warmup_steps: Number of warmup steps
        num_training_steps: Total number of training steps
        min_lr: Minimum learning rate
        **kwargs: Additional arguments

    Returns:
        Learning rate scheduler
    """
    scheduler_type = scheduler_type.lower()

    if scheduler_type == "cosine":
        return get_cosine_schedule_with_warmup(
            optimizer,
            num_warmup_steps,
            num_training_steps,
            min_lr_ratio=min_lr / optimizer.defaults['lr'],
        )
    elif scheduler_type == "linear":
        return get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps,
            num_training_steps,
        )
    elif scheduler_type == "polynomial":
        power = kwargs.get('power', 1.0)
        return get_polynomial_schedule_with_warmup(
            optimizer,
            num_warmup_steps,
            num_training_steps,
            lr_end=min_lr,
            power=power,
        )
    elif scheduler_type == "constant":
        return get_constant_schedule_with_warmup(optimizer, num_warmup_steps)
    elif scheduler_type == "exponential":
        gamma = kwargs.get('gamma', 0.95)
        return get_exponential_schedule_with_warmup(
            optimizer,
            num_warmup_steps,
            gamma=gamma,
        )
    else:
        raise ValueError(f"Unknown scheduler type: {scheduler_type}")


class SchedulerFactory:
    """
    Factory for creating and managing learning rate schedulers.
    """

    def __init__(
        self,
        optimizer: optim.Optimizer,
        scheduler_type: str = "cosine",
        num_warmup_steps: int = 1000,
        num_training_steps: int = 100000,
        min_lr: float = 0.0,
        **kwargs
    ):
        self.optimizer = optimizer
        self.scheduler_type = scheduler_type
        self.num_warmup_steps = num_warmup_steps
        self.num_training_steps = num_training_steps
        self.min_lr = min_lr
        self.kwargs = kwargs
        self.scheduler = None

    def create(self):
        """Create and return the scheduler."""
        self.scheduler = create_scheduler(
            self.optimizer,
            self.scheduler_type,
            self.num_warmup_steps,
            self.num_training_steps,
            self.min_lr,
            **self.kwargs
        )
        return self.scheduler

    def step(self):
        """Perform a scheduler step."""
        if self.scheduler is None:
            raise RuntimeError("Scheduler not created yet")
        self.scheduler.step()

    def get_last_lr(self):
        """Get last learning rate."""
        if self.scheduler is None:
            raise RuntimeError("Scheduler not created yet")
        return self.scheduler.get_last_lr()

    def state_dict(self):
        """Get scheduler state dict."""
        if self.scheduler is None:
            raise RuntimeError("Scheduler not created yet")
        return self.scheduler.state_dict()

    def load_state_dict(self, state_dict):
        """Load scheduler state dict."""
        if self.scheduler is None:
            raise RuntimeError("Scheduler not created yet")
        self.scheduler.load_state_dict(state_dict)
